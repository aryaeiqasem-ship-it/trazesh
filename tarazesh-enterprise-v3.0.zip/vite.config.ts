import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react()],
    build: {
      rollupOptions: {
        // این کتابخانه‌ها از طریق importmap در HTML مدیریت می‌شوند و نباید بیلد شوند
        external: ['mammoth', 'pdfjs-dist'],
      },
    },
    // Security Fix: Do NOT expose API_KEY here. It is now handled by the server proxy.
    server: {
      port: 3000,
      proxy: {
        '/api': {
          target: 'http://localhost:3001',
          changeOrigin: true,
          secure: false,
        }
      }
    }
  };
});