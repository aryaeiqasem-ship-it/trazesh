
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import jwt from 'jsonwebtoken';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'COMMERCIAL_STRICT_SECRET_2024';

// --- Infrastructure ---
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: true, credentials: true }));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(cookieParser());

// Serve static uploads
app.use('/uploads', express.static(UPLOAD_DIR));

// --- API Routes ---
app.post('/api/auth/login', (req, res) => {
    const { identifier, role, name } = req.body;
    const userPayload = { 
        id: identifier || 'guest_id', 
        role: role || 'STUDENT', 
        name: name || 'System User' 
    };
    const token = jwt.sign(userPayload, JWT_SECRET, { expiresIn: '7d' });
    res.cookie('auth_token', token, { 
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 
    });
    res.json({ user: userPayload, token });
});

app.get('/api/health', (req, res) => res.json({ status: 'active', version: '2.8.0-pro' }));

// --- Serving Frontend ---
const distPath = path.join(__dirname, 'dist');
// Serve built frontend files
app.use(express.static(distPath));

// Important: Handle SPA routing by redirecting all non-API calls to index.html
app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
        const indexPath = path.join(distPath, 'index.html');
        if (fs.existsSync(indexPath)) {
            res.sendFile(indexPath);
        } else {
            res.status(404).send('Frontend not built yet. Please run npm run build.');
        }
    }
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CORE] Enterprise Server is running on port ${PORT}`);
    console.log(`[CORE] Security Protocols Initialized.`);
});
