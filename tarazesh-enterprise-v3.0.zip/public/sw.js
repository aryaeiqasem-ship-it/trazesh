
const CACHE_NAME = 'enterprise-lms-static-v3';
const DATA_CACHE_NAME = 'enterprise-lms-data-v1';

const APP_SHELL = [
  '/',
  '/index.html',
  '/manifest.json',
  'https://cdn.tailwindcss.com',
  'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css',
  'https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'
];

// Critical API Paths to cache for offline access
const CRITICAL_API_PATHS = [
  '/api/exams',
  '/api/assignments',
  '/api/questions',
  '/api/users',
  '/api/classes'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Pre-caching offline shell');
      return cache.addAll(APP_SHELL);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME && key !== DATA_CACHE_NAME) {
            console.log('[SW] Removing old cache', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);

  // 1. Data Caching Strategy: Network First (for critical API data)
  if (url.pathname.startsWith('/api/') && e.request.method === 'GET') {
    const isCritical = CRITICAL_API_PATHS.some(path => url.pathname.includes(path));
    
    if (isCritical) {
      e.respondWith(
        fetch(e.request)
          .then((response) => {
            // If network is OK, clone response to cache
            if (response.status === 200) {
              const cacheCopy = response.clone();
              caches.open(DATA_CACHE_NAME).then((cache) => {
                cache.put(e.request, cacheCopy);
              });
            }
            return response;
          })
          .catch(() => {
            // If network fails (Offline), try the cache
            return caches.match(e.request);
          })
      );
      return;
    }
  }

  // 2. Static Assets Strategy: Stale-While-Revalidate
  e.respondWith(
    caches.match(e.request).then((cachedResponse) => {
      const fetchPromise = fetch(e.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const cacheCopy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(e.request, cacheCopy);
            });
          }
          return networkResponse;
        })
        .catch(() => {
            // Silent catch for offline static assets
        });

      return cachedResponse || fetchPromise;
    })
  );
});
