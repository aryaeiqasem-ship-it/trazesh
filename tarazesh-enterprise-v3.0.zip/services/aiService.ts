
import { GoogleGenAI, Type } from "@google/genai";
import { Question, QuestionType, ExamResult, Exam } from "../types";

const isOnline = () => navigator.onLine && !!process.env.API_KEY;

/**
 * تولید سوالات هوشمند با سرعت بهینه شده (Optimized for Speed)
 */
export const generateAIQuestions = async (
  params: {
    topic?: string;
    count: number;
    types: QuestionType[];
    customPrompt?: string;
    sourceText?: string;
    difficulty: 'easy' | 'medium' | 'hard' | 'mixed';
    fileData?: { data: string; mimeType: string };
  }
): Promise<Question[]> => {
    if (!isOnline()) return [];

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // تقلیل دستورات برای افزایش سرعت پردازش مدل
        const systemInstruction = `طراح سوال آزمون. خروجی فقط آرایه JSON معتبر.
        MULTIPLE_CHOICE: correctAnswer 0-3.
        TRUE_FALSE: correctAnswer boolean.
        DESCRIPTIVE: correctAnswer string.
        بدون توضیحات اضافی.`;

        // بهینه‌سازی متن ورودی (محدود کردن طول متن منبع برای سرعت بیشتر)
        const truncatedSource = params.sourceText ? params.sourceText.substring(0, 8000) : '';

        const promptText = `تعداد ${params.count} سوال ${params.types.join('/')} با سختی ${params.difficulty} تولید کن.
        موضوع: ${params.topic || 'آموزشی'}
        ${truncatedSource ? `منبع: ${truncatedSource}` : ''}
        ${params.customPrompt ? `نکته: ${params.customPrompt}` : ''}`;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: [{
                role: 'user',
                parts: [
                    { text: promptText },
                    ...(params.fileData ? [{
                        inlineData: {
                            data: params.fileData.data,
                            mimeType: params.fileData.mimeType
                        }
                    }] : [])
                ]
            }],
            config: { 
                systemInstruction,
                responseMimeType: 'application/json',
                responseSchema: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      text: { type: Type.STRING },
                      type: { type: Type.STRING, enum: Object.values(QuestionType) },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctAnswer: { type: Type.STRING }, 
                      points: { type: Type.NUMBER },
                      difficulty: { type: Type.STRING, enum: ['easy', 'medium', 'hard'] }
                    },
                    required: ["text", "type", "correctAnswer", "points", "difficulty"]
                  }
                },
                temperature: 0.1 // کمترین تاخیر و بیشترین دقت ساختاری
            }
        });

        const text = response.text;
        if (!text) return [];

        const rawData = JSON.parse(text);
        return rawData.map((q: any) => {
            let correctedAns = q.correctAnswer;
            if (q.type === QuestionType.MULTIPLE_CHOICE) correctedAns = parseInt(q.correctAnswer) || 0;
            if (q.type === QuestionType.TRUE_FALSE) correctedAns = String(q.correctAnswer).toLowerCase() === 'true';

            return {
                ...q,
                correctAnswer: correctedAns,
                points: q.points || 1,
                id: `ai_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`
            };
        });
    } catch (e) {
        console.error("AI Fast Gen Error:", e);
        return [];
    }
};

/**
 * تصحیح هوشمند پاسخ‌های تشریحی با سرعت بالا
 */
export const gradeDescriptiveAnswer = async (
  questionText: string,
  studentAnswer: string,
  maxPoints: number,
  referenceAnswer: string
): Promise<{ score: number; feedback: string }> => {
  if (!isOnline()) return { score: 0, feedback: "آفلاین" };

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{
          role: 'user',
          parts: [{ text: `Q: ${questionText}\nRef: ${referenceAnswer}\nAns: ${studentAnswer}\nMax: ${maxPoints}` }]
      }],
      config: { 
        systemInstruction: "نمره‌دهی سریع در قالب JSON: {score: number, feedback: string}",
        responseMimeType: "application/json",
        temperature: 0.1
      }
    });

    const result = JSON.parse(response.text || '{"score": 0, "feedback": ""}');
    return {
      score: Math.min(Math.max(result.score || 0, 0), maxPoints),
      feedback: result.feedback || ""
    };
  } catch (e) {
    return { score: 0, feedback: "خطای تحلیل." };
  }
};

export const generateLearningPath = async (
  results: ExamResult[],
  exams: Exam[]
): Promise<any> => {
  if (!isOnline() || results.length === 0) return null;
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const perf = results.map(r => ({ t: exams.find(e => e.id === r.examId)?.title, s: r.score, m: r.maxScore }));
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ role: 'user', parts: [{ text: JSON.stringify(perf) }] }],
      config: { 
        systemInstruction: "تحلیل سریع مسیر یادگیری در قالب JSON شامل analysis, strengths (array), weaknesses (array), roadmap (array of {step, title, description})",
        responseMimeType: "application/json",
        temperature: 0.2
      }
    });
    return JSON.parse(response.text || 'null');
  } catch (e) { return null; }
};
