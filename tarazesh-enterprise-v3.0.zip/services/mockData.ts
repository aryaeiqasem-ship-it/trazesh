
import { User, UserRole, Exam, QuestionType, ExamResult, Question, Course, Message, ScheduleItem, SubscriptionPlan, Assignment, AssignmentSubmission, Resource, ExamType, ShopItem, LicenseRecord, SalesRecord } from '../types';

export const MOCK_USERS: User[] = [
  { id: 'dev_01', name: 'توسعه‌دهنده سیستم (Developer)', role: UserRole.DEVELOPER, username: 'dev', password: 'dev' },
  { id: 'super_01', name: 'مدیر ارشد سازمان (Super Admin)', role: UserRole.SUPER_ADMIN, username: 'superadmin', password: 'superadmin' },
  { id: '1', name: 'مدیر مدرسه البرز', role: UserRole.ADMIN, username: 'admin', password: 'admin' },
  { id: '2', name: 'استاد رضایی', role: UserRole.TEACHER, username: 'teacher', password: 'teacher' },
  { 
    id: '3', 
    name: 'علی محمدی', 
    role: UserRole.STUDENT, 
    studentId: '990101', 
    password: '123', 
    grade: '12', 
    class: 'A',
    major: 'ریاضی',
    gamification: {
      xp: 2450,
      level: 5,
      nextLevelXp: 3000,
      badges: [
        { id: 'b1', title: 'شروع قدرتمند', description: 'کسب اولین نمره کامل', icon: 'star', type: 'gold', unlockedAt: '1402/07/01', isLocked: false },
        { id: 'b2', title: 'تلاشگر برنزی', description: 'شرکت در ۵ آزمون متوالی', icon: 'medal', type: 'bronze', unlockedAt: '1402/08/15', isLocked: false },
        { id: 'b3', title: 'استاد ریاضی', description: 'نمره بالای ۱۸ در درس ریاضی', icon: 'trophy', type: 'silver', unlockedAt: '1402/09/20', isLocked: false },
      ],
      purchasedItems: []
    }
  },
  { 
    id: 'parent_1', 
    name: 'محمد محمدی (ولی علی)', 
    role: UserRole.PARENT, 
    username: 'parent', 
    password: '123', 
    childId: '3' 
  }
];

export const MOCK_LICENSES: LicenseRecord[] = [
  { id: 'L-001', orgName: 'مدرسه ماندگار البرز', key: 'EDUP-ALB-X982-2024', type: 'ENTERPRISE', issueDate: '1402/10/01', expiryDate: '1403/10/01', maxUsers: 1500, status: 'ACTIVE', price: 45000000 },
  { id: 'L-002', orgName: 'مجتمع آموزشی فجر', key: 'EDUP-FJR-K122-2024', type: 'PRO', issueDate: '1402/11/15', expiryDate: '1403/11/15', maxUsers: 500, status: 'ACTIVE', price: 18000000 },
  { id: 'L-003', orgName: 'موسسه علمی خوارزمی', key: 'EDUP-KHW-Q111-2023', type: 'TRIAL', issueDate: '1402/05/01', expiryDate: '1402/06/01', maxUsers: 50, status: 'EXPIRED', price: 0 },
];

export const MOCK_SALES: SalesRecord[] = [
  { id: 'S-101', orgName: 'مدرسه ماندگار البرز', amount: 45000000, date: '1402/10/01', plan: 'Enterprise Annual' },
  { id: 'S-102', orgName: 'مجتمع آموزشی فجر', amount: 18000000, date: '1402/11/15', plan: 'Pro Annual' },
  { id: 'S-103', orgName: 'آموزشگاه پیام', amount: 5500000, date: '1403/01/20', plan: 'Pro Monthly' },
];

export const SHOP_ITEMS: ShopItem[] = [
  { id: 'item_1', title: 'کارت وقت اضافه', description: '۱۰ دقیقه زمان بیشتر برای آزمون بعدی', costXp: 500, type: 'booster', icon: 'clock' },
  { id: 'item_2', title: 'تم طلایی پنل', description: 'تغییر ظاهر داشبورد به رنگ طلایی متالیک', costXp: 1200, type: 'cosmetic', icon: 'palette' },
  { id: 'item_3', title: 'کارت شانس مجدد', description: 'امکان شرکت مجدد در یک آزمون آزمایشی', costXp: 800, type: 'privilege', icon: 'refresh-ccw' },
  { id: 'item_4', title: 'تغییر آواتار VIP', description: 'دسترسی به آواتارهای متحرک اختصاصی', costXp: 2000, type: 'cosmetic', icon: 'user' },
];

export const MOCK_COURSES: Course[] = [
  { id: 'c1', title: 'ریاضیات گسسته', code: 'MATH-121', category: 'SPECIALIZED', grade: '12', major: 'ریاضی' },
  { id: 'c2', title: 'فیزیک مکانیک', code: 'PHYS-112', category: 'PODMANI', grade: '12', major: 'ریاضی' },
];

export const MOCK_QUESTIONS: Question[] = [
  {
    id: 'q1',
    text: 'تعداد یال‌های یک گراف کامل ۵ رأسی چقدر است؟',
    type: QuestionType.MULTIPLE_CHOICE,
    options: ['۵', '۱۰', '۱۵', '۲۰'],
    correctAnswer: 1, 
    difficulty: 'medium',
    points: 5,
    tags: ['ریاضیات گسسته', 'گراف'],
    grade: '12',
    major: 'ریاضی'
  }
];

export const MOCK_EXAMS: Exam[] = [
  {
    id: 'exam_1',
    title: 'ریاضیات گسسته - میان‌ترم',
    description: 'فصل گراف و نظریه اعداد',
    durationMinutes: 45,
    createdBy: '2',
    status: 'active',
    type: ExamType.OFFICIAL,
    startDate: new Date().toISOString(),
    forClass: 'A',
    questions: [MOCK_QUESTIONS[0]],
    securityLevel: 'standard'
  }
];

export const MOCK_RESULTS: ExamResult[] = [
    { id: 'res_1', examId: 'exam_1', studentId: '3', answers: {}, score: 18, maxScore: 20, status: 'passed', submittedAt: new Date().toISOString(), cheatingAttempts: 0 }
];
export const MOCK_MESSAGES: Message[] = [];
export const MOCK_SCHEDULE: ScheduleItem[] = [];
export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  { id: 'plan_basic', name: 'پایه (Basic)', price: 0, features: ['مدیریت تا ۵۰ دانش‌آموز'], isPopular: false },
  { id: 'plan_pro', name: 'حرفه‌ای (Pro)', price: 490000, features: ['دانش‌آموز نامحدود'], isPopular: true },
  { id: 'plan_enterprise', name: 'سازمانی (Enterprise)', price: 1900000, features: ['دسترسی کامل'], isPopular: false }
];
export const MOCK_ASSIGNMENTS: Assignment[] = [];
export const MOCK_SUBMISSIONS: AssignmentSubmission[] = [];
export const MOCK_RESOURCES: Resource[] = [];
