
import { User, Badge, NotificationType } from '../types';
import { storageService } from './storageService';

export const gamificationService = {
  // Calculate Level based on XP: Level = floor(sqrt(XP / 100))
  calculateLevel: (xp: number) => {
    const level = Math.floor(Math.sqrt(xp / 100)) || 1;
    const nextLevelXp = Math.pow(level + 1, 2) * 100;
    return { level, nextLevelXp };
  },

  awardXP: (userId: string, amount: number, reason: string): { leveledUp: boolean, newLevel: number, newBadges: Badge[] } => {
    const users = storageService.getUsers();
    const userIndex = users.findIndex(u => u.id === userId);
    
    const newBadges: Badge[] = [];
    if (userIndex === -1) return { leveledUp: false, newLevel: 1, newBadges: [] };

    const user = users[userIndex];
    if (!user.gamification) {
        user.gamification = { xp: 0, level: 1, nextLevelXp: 400, badges: [] };
    }

    const oldLevel = user.gamification.level;
    user.gamification.xp += amount;
    
    const { level, nextLevelXp } = gamificationService.calculateLevel(user.gamification.xp);
    user.gamification.level = level;
    user.gamification.nextLevelXp = nextLevelXp;

    const leveledUp = level > oldLevel;
    
    // Check for "Active Student" Badge
    if (user.gamification.xp >= 3000 && !user.gamification.badges.some(b => b.id === 'active_student')) {
        const badge: Badge = {
            id: 'active_student',
            title: 'دانش‌آموز فعال',
            description: 'کسب بیش از ۳۰۰۰ امتیاز تجربه',
            icon: 'zap',
            type: 'gold',
            isLocked: false,
            unlockedAt: new Date().toISOString()
        };
        user.gamification.badges.push(badge);
        newBadges.push(badge);
    }

    // Check for "Level 5 Master" Badge
    if (level >= 5 && !user.gamification.badges.some(b => b.id === 'master_5')) {
        const badge: Badge = {
            id: 'master_5',
            title: 'پیشرو در یادگیری',
            description: 'رسیدن به سطح ۵ آموزشی',
            icon: 'award',
            type: 'platinum',
            isLocked: false,
            unlockedAt: new Date().toISOString()
        };
        user.gamification.badges.push(badge);
        newBadges.push(badge);
    }

    users[userIndex] = user;
    storageService.saveUsers(users);
    localStorage.setItem('current_user', JSON.stringify(user));

    return { leveledUp, newLevel: level, newBadges };
  },

  awardIPC: (userId: string, amount: number, reason: string) => {
    const users = storageService.getUsers();
    const idx = users.findIndex(u => u.id === userId);
    if (idx === -1) return null;

    const user = users[idx];
    if (!user.gamification) {
        user.gamification = { xp: 0, ipc: 0, level: 1, nextLevelXp: 400, badges: [] };
    }
    
    user.gamification.ipc = (user.gamification.ipc || 0) + amount;
    
    storageService.saveUsers(users);
    storageService.addNotification({
        userId,
        type: NotificationType.GAMIFICATION,
        title: 'امتیاز IPC جدید',
        message: `شما ${amount} امتیاز IPC بابت "${reason}" دریافت کردید.`
    });
    
    return user;
  },

  grantBadge: (userId: string, title: string, description: string, type: Badge['type'] = 'gold') => {
    const users = storageService.getUsers();
    const idx = users.findIndex(u => u.id === userId);
    if (idx === -1) return null;

    const user = users[idx];
    if (!user.gamification) {
        user.gamification = { xp: 0, level: 1, nextLevelXp: 400, badges: [] };
    }

    const newBadge: Badge = {
        id: `badge_${Date.now()}`,
        title,
        description,
        icon: 'star',
        type,
        isLocked: false,
        unlockedAt: new Date().toISOString()
    };

    user.gamification.badges.push(newBadge);
    storageService.saveUsers(users);
    localStorage.setItem('current_user', JSON.stringify(user));
    
    storageService.addNotification({
        userId,
        type: NotificationType.GAMIFICATION,
        title: 'نشان افتخار جدید',
        message: `تبریک! شما نشان "${title}" را کسب کردید.`
    });

    return newBadge;
  },

  checkPerfectScoreBadge: (userId: string) => {
    const users = storageService.getUsers();
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) return null;
    const user = users[userIndex];

    if (user.gamification && !user.gamification.badges.some(b => b.id === 'perfect_score')) {
        const badge: Badge = {
            id: 'perfect_score',
            title: 'نمره کامل',
            description: 'کسب نمره کامل در یک آزمون',
            icon: 'trophy',
            type: 'gold',
            isLocked: false,
            unlockedAt: new Date().toISOString()
        };
        user.gamification.badges.push(badge);
        users[userIndex] = user;
        storageService.saveUsers(users);
        localStorage.setItem('current_user', JSON.stringify(user));
        return badge;
    }
    return null;
  }
};
