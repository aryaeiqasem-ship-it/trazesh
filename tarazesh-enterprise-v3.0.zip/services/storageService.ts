
import { User, Course, Exam, Question, ExamResult, SystemSettings, Major, Grade, ClassEntity, Message, ScheduleItem, AttendanceRecord, Assignment, AssignmentSubmission, Resource, Notification, NotificationType, Quote, LicenseRecord, SalesRecord, LiveExamSession, ChatGroup, ExamType, UserRole, PasswordResetRequest, QuestionType } from '../types';
import { MOCK_USERS, MOCK_COURSES, MOCK_EXAMS, MOCK_QUESTIONS, MOCK_RESULTS, MOCK_MESSAGES, MOCK_SCHEDULE, MOCK_ASSIGNMENTS, MOCK_SUBMISSIONS, MOCK_RESOURCES, MOCK_LICENSES, MOCK_SALES } from './mockData';
import { gamificationService } from './gamificationService';

const getLocal = (key: string, defaultVal: any) => {
    try {
        const s = localStorage.getItem(key);
        if (!s || s === '[]' || s === '{}') return defaultVal;
        return JSON.parse(s);
    } catch { return defaultVal; }
};

const saveLocal = (key: string, val: any) => {
    localStorage.setItem(key, JSON.stringify(val));
};

export const storageService = {
  initializeFromServer: async (): Promise<boolean> => {
    try {
      const response = await fetch('/api/health').catch(() => null);
      return !!(response && response.ok);
    } catch (e) { return false; }
  },

  getUsers: (): User[] => getLocal('users', MOCK_USERS),
  saveUsers: (users: User[]) => saveLocal('users', users),
  
  getCurrentUser: (): User | null => {
    const s = localStorage.getItem('current_user');
    return s ? JSON.parse(s) : null;
  },

  getMessages: (): Message[] => getLocal('messages', MOCK_MESSAGES),
  saveMessages: (m: Message[]) => saveLocal('messages', m),
  
  getGroups: (): ChatGroup[] => getLocal('chat_groups', []),
  saveGroups: (groups: ChatGroup[]) => saveLocal('chat_groups', groups),

  getExams: (): Exam[] => getLocal('exams', MOCK_EXAMS),
  saveExams: (exams: Exam[]) => saveLocal('exams', exams),
  getResults: (): ExamResult[] => getLocal('results', MOCK_RESULTS),
  saveResults: (results: ExamResult[]) => saveLocal('results', results),
  
  getQuestions: (): Question[] => getLocal('questions', MOCK_QUESTIONS),
  saveQuestions: (questions: Question[]) => saveLocal('questions', questions),
  
  getCourses: (): Course[] => getLocal('courses', MOCK_COURSES),
  saveCourses: (courses: Course[]) => saveLocal('courses', courses),

  getSettings: (): SystemSettings => getLocal('app_settings', {
      instituteName: 'سامانه مرکزی ترازش هوشمند',
      branding: { 
        primaryColor: '#0088cc', 
        quotes: [
          { id: '1', text: 'آموزش پلی است میان رویاها و واقعیت.', author: 'ترازش' },
          { id: '2', text: 'هوش مصنوعی در خدمت ارتقای دانش.', author: 'هسته مرکزی' }
        ] 
      },
      license: { plan: 'ENTERPRISE', expiryDate: '1405/01/01', status: 'ACTIVE' }
  }),
  saveSettings: (data: SystemSettings) => saveLocal('app_settings', data),
  getClasses: (): ClassEntity[] => getLocal('classes', []),
  saveClasses: (classes: ClassEntity[]) => saveLocal('classes', classes),
  
  getNotifications: (): Notification[] => getLocal('notifications', []),
  saveNotifications: (notifs: Notification[]) => saveLocal('notifications', notifs),
  addNotification: (notif: { userId: string, type: NotificationType, title: string, message: string }) => {
      const current = storageService.getNotifications();
      const newNotif: Notification = { 
          ...notif, 
          id: `n_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`, 
          timestamp: new Date().toISOString(), 
          isRead: false 
      };
      saveLocal('notifications', [newNotif, ...current]);
  },
  
  markAsRead: (id: string) => {
    const notifs = storageService.getNotifications();
    const updated = notifs.map(n => n.id === id ? { ...n, isRead: true } : n);
    storageService.saveNotifications(updated);
  },

  markAllAsRead: (userId: string) => {
    const notifs = storageService.getNotifications();
    const updated = notifs.map(n => n.userId === userId ? { ...n, isRead: true } : n);
    storageService.saveNotifications(updated);
  },
  
  getLiveSessions: (examId?: string): LiveExamSession[] => {
    const all = getLocal('live_exam_sessions', []);
    return examId ? all.filter((s: any) => s.examId === examId) : all;
  },
  updateLiveSession: (session: LiveExamSession) => {
    const all = getLocal('live_exam_sessions', []);
    const filtered = all.filter((s: any) => !(s.examId === session.examId && s.studentId === session.studentId));
    saveLocal('live_exam_sessions', [session, ...filtered]);
  },

  getSchedule: (): ScheduleItem[] => getLocal('system_schedule', MOCK_SCHEDULE),
  saveSchedule: (items: ScheduleItem[]) => saveLocal('system_schedule', items),

  getTeacherNotes: (teacherId: string): string => getLocal(`notes_${teacherId}`, ''),
  saveTeacherNotes: (teacherId: string, note: string) => saveLocal(`notes_${teacherId}`, note),

  saveUser: async (userData: Partial<User>) => {
    const users = storageService.getUsers();
    let target: any = null;
    const updated = users.map(u => {
      if (u.id === userData.id || (userData.studentId && u.studentId === userData.studentId)) {
        target = { ...u, ...userData }; return target;
      }
      return u;
    });
    if (!target) { target = { ...userData, id: `u_${Date.now()}` }; updated.push(target); }
    storageService.saveUsers(updated);
    return { ok: true, user: target };
  },
  
  getAttendance: (): AttendanceRecord[] => getLocal('attendance', []),
  saveAttendance: (a: AttendanceRecord[]) => saveLocal('attendance', a),
  
  getStudentAttendanceDetails: (studentId: string) => {
    const attendance = storageService.getAttendance();
    const classes = storageService.getClasses();
    return attendance
      .filter(rec => 
        rec.presentStudentIds.includes(studentId) || 
        rec.lateStudentIds.includes(studentId) || 
        rec.absentStudentIds.includes(studentId)
      )
      .map(rec => {
        const cls = classes.find(c => c.id === rec.classId);
        let status: 'present' | 'absent' | 'late' = 'absent';
        if (rec.presentStudentIds.includes(studentId)) status = 'present';
        else if (rec.lateStudentIds.includes(studentId)) status = 'late';
        return {
          date: rec.date,
          className: cls?.title || 'نامشخص',
          status
        };
      });
  },
  
  getAssignments: (): Assignment[] => getLocal('assignments', MOCK_ASSIGNMENTS),
  saveAssignments: (a: Assignment[]) => saveLocal('assignments', a),
  getSubmissions: (): AssignmentSubmission[] => getLocal('submissions', MOCK_SUBMISSIONS),
  saveSubmissions: (s: AssignmentSubmission[]) => saveLocal('submissions', s),
  getResources: (): Resource[] => getLocal('resources', MOCK_RESOURCES),
  saveResources: (r: Resource[]) => saveLocal('resources', r),

  requestPasswordReset: (identifier: string): PasswordResetRequest => {
    const users = storageService.getUsers();
    const user = users.find(u => u.studentId === identifier || u.username === identifier);
    if (!user) throw new Error('کاربر یافت نشد.');
    const requests = getLocal('password_resets', []);
    const newReq: PasswordResetRequest = {
        id: `rst_${Date.now()}`,
        userId: user.id,
        userName: user.name,
        studentId: user.studentId || user.username || 'unknown',
        timestamp: new Date().toISOString(),
        status: 'pending'
    };
    saveLocal('password_resets', [newReq, ...requests]);
    return newReq;
  },

  getPendingResets: (): PasswordResetRequest[] => getLocal('password_resets', []).filter((r: any) => r.status === 'pending'),

  approveReset: (requestId: string, newPass: string) => {
    const requests = getLocal('password_resets', []);
    const req = requests.find((r: any) => r.id === requestId);
    if (!req) return;
    const users = storageService.getUsers();
    const updatedUsers = users.map(u => u.id === req.userId ? { ...u, password: newPass } : u);
    storageService.saveUsers(updatedUsers);
    const updatedReqs = requests.map((r: any) => r.id === requestId ? { ...r, status: 'approved' } : r);
    saveLocal('password_resets', updatedReqs);
    storageService.addNotification({ userId: req.userId, type: NotificationType.SYSTEM, title: 'رمز عبور تغییر یافت', message: `رمز عبور جدید شما توسط مدرس تایید و فعال شد.` });
  },

  fetchUsers: async (page: number, limit: number, search: string, role: string) => {
    const allUsers = storageService.getUsers();
    const filtered = allUsers.filter(u => {
        const matchesSearch = !search || u.name.toLowerCase().includes(search.toLowerCase()) || (u.studentId && u.studentId.includes(search)) || (u.username && u.username.includes(search));
        return matchesSearch && (role === 'ALL' || u.role === role);
    });
    return { data: filtered.slice((page - 1) * limit, page * limit), pages: Math.ceil(filtered.length / limit) };
  },

  deleteUser: async (id: string) => {
    storageService.saveUsers(storageService.getUsers().filter(u => u.id !== id));
    return { ok: true };
  },

  uploadFile: async (f: File) => ({ url: "blob:edu-resource-" + Date.now() }),
  getMajors: (): Major[] => getLocal('majors', []),
  saveMajors: (m: Major[]) => saveLocal('majors', m),
  getGrades: (): Grade[] => getLocal('grades', []),
  saveGrades: (g: Grade[]) => saveLocal('grades', g),

  submitExamToServer: async (examId: string, answers: Record<string, any>, studentId: string, questions: Question[]) => {
    let score = 0;
    let maxScore = 0;
    questions.forEach(q => {
      maxScore += q.points;
      const studentAns = answers[q.id];
      if (q.type === QuestionType.MULTIPLE_CHOICE) {
        if (Number(studentAns) === Number(q.correctAnswer)) score += q.points;
      } else if (q.type === QuestionType.TRUE_FALSE) {
        if (studentAns === q.correctAnswer) score += q.points;
      }
    });

    const exam = storageService.getExams().find(e => e.id === examId);
    const earnedXp = (exam?.rewardXp || 0) + (score > (maxScore / 2) ? 50 : 0);

    const result: ExamResult = {
        id: `res_${Date.now()}`,
        examId,
        studentId,
        answers,
        score,
        maxScore,
        earnedXp,
        submittedAt: new Date().toISOString(),
        status: (score / (maxScore || 1)) >= 0.5 ? 'passed' : 'failed',
        cheatingAttempts: 0
    };

    const results = storageService.getResults();
    storageService.saveResults([...results, result]);

    const { newBadges } = gamificationService.awardXP(studentId, earnedXp, `اتمام آزمون ${exam?.title}`);
    const perfectBadge = (score === maxScore) ? gamificationService.checkPerfectScoreBadge(studentId) : null;
    
    const finalBadges = [...newBadges];
    if (perfectBadge) finalBadges.push(perfectBadge);

    return { ...result, newBadges: finalBadges };
  },

  generatePracticeQuestions: (major: string, grade: string, count: number): Question[] => {
    const allQ = storageService.getQuestions();
    const filtered = allQ.filter(q => q.major === major && q.grade === grade);
    return filtered.sort(() => 0.5 - Math.random()).slice(0, count);
  },

  activateLicense: (key: string) => {
    if (key.startsWith('EDUP-') && key.length > 10) {
        const settings = storageService.getSettings();
        settings.license = {
            ...settings.license,
            activationKey: key,
            status: 'ACTIVE' as const,
            plan: key.includes('ENT') ? 'ENTERPRISE' : 'PRO'
        };
        storageService.saveSettings(settings);
        return { success: true, message: 'سیستم با موفقیت فعال شد.' };
    }
    return { success: false, message: 'کد فعال‌سازی نامعتبر است.' };
  },

  createGroup: (name: string, createdBy: string, memberIds: string[]): ChatGroup => {
    const groups = storageService.getGroups();
    const newGroup: ChatGroup = {
        id: `grp_${Date.now()}`,
        name,
        createdBy,
        memberIds: [...memberIds, createdBy],
        type: 'custom'
    };
    storageService.saveGroups([...groups, newGroup]);
    return newGroup;
  },

  deleteConversation: (userId: string, targetId: string, isGroup: boolean) => {
    const messages = storageService.getMessages();
    const updated = messages.filter(m => {
      if (isGroup) return m.groupId !== targetId;
      return !((m.senderId === userId && m.receiverId === targetId) || (m.senderId === targetId && m.receiverId === userId));
    });
    storageService.saveMessages(updated);
    return updated;
  },

  getLicenses: (): LicenseRecord[] => getLocal('licenses', MOCK_LICENSES),
  saveLicenses: (lics: LicenseRecord[]) => saveLocal('licenses', lics),
  getLicensesInUse: () => getLocal('licenses', MOCK_LICENSES),
  getSales: (): SalesRecord[] => getLocal('sales', MOCK_SALES),
  saveSales: (sales: SalesRecord[]) => saveLocal('sales', sales),

  verifyBlockchainHash: (hash: string) => {
    return {
        verified: true,
        node: 'NODE-TRZ-X9',
        timestamp: new Date().toISOString(),
        hash
    };
  }
};
