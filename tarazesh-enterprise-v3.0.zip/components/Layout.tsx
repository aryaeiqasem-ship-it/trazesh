
import React, { useState, useEffect, useRef } from 'react';
import { User, UserRole } from '../types';
import { 
  LogOut, LayoutDashboard, BookOpen, Users, BarChart3, Settings, ShieldCheck,
  Moon, Sun, School, Calendar, FileText, ClipboardList, Library, 
  Trophy, Award, Home, Menu, X, PieChart, Database, BookMarked, FolderOpen,
  Layers, GraduationCap, Briefcase, Bell, Search, Sparkles, Wifi, WifiOff, Activity,
  ShoppingBag, Eye, MessageSquare, ClipboardCheck, MessageCircle, Terminal, ChevronDown, ChevronRight,
  UserCircle, Crown, DollarSign, Heart, Compass, LayoutPanelLeft, ListChecks, Hash, Zap, Globe, CalendarDays
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { storageService } from '../services/storageService';
import { motion, AnimatePresence } from 'framer-motion';
import NotificationCenter from './NotificationCenter';
import BrandLogo from './BrandLogo';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  currentView: string;
  onNavigate: (view: string, data?: any) => void;
  devModeActive?: boolean;
  superModeActive?: boolean;
}

const NavItem = ({ 
  icon: Icon, 
  label, 
  view, 
  currentView, 
  onNavigate, 
  setIsMobileMenuOpen 
}: { 
  icon: any, 
  label: string, 
  view: string, 
  currentView: string,
  onNavigate: (view: string) => void,
  setIsMobileMenuOpen: (open: boolean) => void 
}) => {
  const isActive = currentView === view;
  return (
    <button 
      onClick={() => { onNavigate(view); setIsMobileMenuOpen(false); }}
      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 group relative mb-0.5 ${
        isActive 
          ? 'bg-primary-600 text-white shadow-[0_8px_20px_-5px_rgba(0,136,204,0.4)]' 
          : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'
      }`}
    >
      <div className={`shrink-0 transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`}>
        <Icon size={18} strokeWidth={isActive ? 2.5 : 2} />
      </div>
      <span className={`text-[13px] flex-1 text-right truncate transition-all ${isActive ? 'font-black' : 'font-bold'}`}>
        {label}
      </span>
    </button>
  );
};

const SectionLabel = ({ children }: { children?: React.ReactNode }) => (
  <p className="px-4 mt-3 mb-1 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">{children}</p>
);

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, currentView, onNavigate, devModeActive = false, superModeActive = false }) => {
  const { theme, toggleTheme } = useTheme();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;
    const updateCount = () => {
      const count = storageService.getNotifications().filter(n => n.userId === user.id && !n.isRead).length;
      setUnreadCount(count);
    };
    updateCount();
    const interval = setInterval(updateCount, 5000);
    return () => clearInterval(interval);
  }, [user]);

  if (!user) return <div className="min-h-screen flex items-center justify-center bg-slate-50">{children}</div>;

  return (
    <div className="min-h-screen flex bg-[#f8fafc] dark:bg-slate-950 transition-colors duration-500" dir="rtl">
      {/* Mobile Backdrop */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] md:hidden"
          />
        )}
      </AnimatePresence>

      <aside className={`fixed inset-y-0 right-0 z-[70] w-64 transition-transform duration-500 ease-out md:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-white/5 flex flex-col shadow-2xl overflow-hidden">
          <div className="p-5 flex items-center gap-3 border-b border-slate-50 dark:border-white/5">
            <div className="shrink-0"><BrandLogo size={36} /></div>
            <div className="min-w-0">
               <h1 className="font-black text-[16px] text-slate-800 dark:text-white leading-tight truncate tracking-tighter">ترازش هوشمند</h1>
               <div className="flex items-center gap-1.5 mt-0.5">
                  <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Enterprise v3.0</span>
               </div>
            </div>
          </div>

          <nav className="flex-1 px-3 py-4 overflow-y-auto no-scrollbar">
            <NavItem icon={MessageCircle} label="ارتباطات" view="messenger" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
            
            {user.role === UserRole.STUDENT && (
              <>
                <SectionLabel>هنرجو</SectionLabel>
                <NavItem icon={Home} label="داشبورد" view="student_home" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Compass} label="مسیر یادگیری" view="student_learning_path" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={BookOpen} label="آزمون‌ها" view="student_exams" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={BarChart3} label="نتایج" view="student_results" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={ClipboardList} label="تکالیف" view="student_assignments" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Trophy} label="افتخارات" view="student_achievements" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={ShoppingBag} label="بازارچه" view="student_market" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={FolderOpen} label="منابع" view="student_resources" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Settings} label="تنظیمات" view="student_settings" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </>
            )}

            {user.role === UserRole.TEACHER && (
              <>
                <SectionLabel>مدرس</SectionLabel>
                <NavItem icon={LayoutDashboard} label="داشبورد" view="teacher_dashboard" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={BookOpen} label="طراحی آزمون" view="teacher_exams" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Database} label="بانک سوالات" view="teacher_question_bank" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={ListChecks} label="حضور و غیاب" view="teacher_classes" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={FileText} label="تکالیف" view="teacher_assignments" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Users} label="دانش‌آموزان" view="teacher_students" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Library} label="منابع" view="teacher_resources" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={PieChart} label="گزارشات" view="teacher_reports" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={CalendarDays} label="برنامه" view="teacher_schedule" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Settings} label="تنظیمات" view="teacher_settings" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </>
            )}

            {user.role === UserRole.ADMIN && (
              <>
                <SectionLabel>مدیریت</SectionLabel>
                <NavItem icon={LayoutDashboard} label="میز مدیریت" view="admin_dashboard" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Users} label="کاربران" view="admin_users" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={GraduationCap} label="ساختار" view="admin_education_structure" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={School} label="کلاس‌ها" view="admin_classes" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={BookMarked} label="دروس" view="admin_courses" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={PieChart} label="گزارشات" view="admin_reports" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={Settings} label="تنظیمات" view="admin_settings" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </>
            )}

            {user.role === UserRole.PARENT && (
              <>
                <SectionLabel>والدین</SectionLabel>
                <NavItem icon={Users} label="داشبورد فرزند" view="parent_dashboard" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
                <NavItem icon={BarChart3} label="نمرات" view="student_results" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </>
            )}

            {devModeActive && (
              <>
                <SectionLabel>توسعه</SectionLabel>
                <NavItem icon={Terminal} label="کنسول" view="developer_dashboard" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
              </>
            )}

            {superModeActive && (
               <>
                 <SectionLabel>استراتژیک</SectionLabel>
                 <NavItem icon={Crown} label="مدیریت کلان" view="super_admin_dashboard" currentView={currentView} onNavigate={onNavigate} setIsMobileMenuOpen={setIsMobileMenuOpen} />
               </>
            )}
          </nav>

          <div className="p-3 border-t border-slate-50 dark:border-white/5 space-y-1">
            <button 
              onClick={toggleTheme}
              className="w-full flex items-center justify-between px-4 py-2 rounded-xl bg-slate-50 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 transition-all"
            >
               <span className="text-[11px] font-black">{theme === 'dark' ? 'روز' : 'شب'}</span>
               {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button 
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-all group"
            >
              <LogOut size={18} className="group-hover:-translate-x-1 transition-transform" />
              <span className="text-[13px] font-black">خروج</span>
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 md:mr-64 min-h-screen flex flex-col relative">
        <header className="sticky top-0 z-40 h-16 px-6 md:px-8 flex items-center justify-between bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl border-b border-slate-200 dark:border-white/5">
           <div className="flex items-center gap-4">
              <button onClick={() => setIsMobileMenuOpen(true)} className="md:hidden p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-all">
                <Menu size={20} />
              </button>
              <div className="hidden md:block text-right">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">خوش آمدید</p>
                 <h2 className="text-xs font-black text-slate-800 dark:text-white mt-1">{user.name}</h2>
              </div>
           </div>

           <div className="flex items-center gap-3">
              {/* Notification Center Trigger */}
              <div className="relative" ref={notifRef}>
                <button 
                  onClick={() => setIsNotificationsOpen(!isNotificationsOpen)} 
                  className={`p-2 rounded-xl transition-all relative border ${isNotificationsOpen ? 'bg-primary-600 text-white border-primary-600' : 'bg-white dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'}`}
                >
                  <Bell size={18} />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -left-1 w-4 h-4 bg-rose-600 text-white text-[9px] font-black flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900">
                      {unreadCount}
                    </span>
                  )}
                </button>
                <AnimatePresence>
                  {isNotificationsOpen && (
                    <NotificationCenter user={user} onClose={() => setIsNotificationsOpen(false)} />
                  )}
                </AnimatePresence>
              </div>

              <div className="h-8 w-[1px] bg-slate-200 dark:bg-white/10 hidden sm:block mx-1"></div>
              
              <div className="flex items-center gap-2 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                 <div className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-900/30 flex items-center justify-center font-black text-primary-600 overflow-hidden border border-primary-100 dark:border-primary-800">
                    {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : user.name.charAt(0)}
                 </div>
                 <div className="hidden lg:block ml-1 text-right">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter leading-none">{user.role}</p>
                 </div>
              </div>
           </div>
        </header>

        <div className="flex-1 p-5 md:p-8 lg:p-10">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
        
        <footer className="p-6 text-center border-t border-slate-100 dark:border-white/5 opacity-40">
           <p className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.4em]">Tarazesh Intelligent Network &copy; 2024</p>
        </footer>
      </main>
    </div>
  );
};

export default Layout;
