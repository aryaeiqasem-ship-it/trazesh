
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Camera, Loader2, Scan, AlertCircle, CheckCircle2 } from 'lucide-react';

interface Props {
  onSuccess: () => void;
  onCancel: () => void;
  userName: string;
}

const ProctoringCheck: React.FC<Props> = ({ onSuccess, onCancel, userName }) => {
  const [status, setStatus] = useState<'request' | 'scanning' | 'verifying' | 'success'>('request');
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(s);
      if (videoRef.current) videoRef.current.srcObject = s;
      setStatus('scanning');
      
      // Simulate Scanning Process
      setTimeout(() => setStatus('verifying'), 3000);
      setTimeout(() => {
        setStatus('success');
        setTimeout(() => {
           s.getTracks().forEach(t => t.stop());
           onSuccess();
        }, 1500);
      }, 5000);
    } catch (err) {
      alert("دسترسی به دوربین برای تایید هویت الزامی است.");
    }
  };

  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach(t => t.stop());
    };
  }, [stream]);

  return (
    <div className="fixed inset-0 z-[10002] bg-slate-950/90 backdrop-blur-2xl flex items-center justify-center p-4 font-sans" dir="rtl">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }}
        className="max-w-lg w-full bg-slate-900 border border-white/10 rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(0,136,204,0.2)]"
      >
        <div className="p-10 space-y-8">
          <div className="text-center space-y-4">
             <div className="w-20 h-20 bg-primary-500/10 rounded-3xl flex items-center justify-center text-primary-500 mx-auto border border-primary-500/30">
                <ShieldCheck size={40} />
             </div>
             <h2 className="text-2xl font-black text-white uppercase tracking-tight">پروتکل امنیتی سطح ۱</h2>
             <p className="text-slate-400 font-bold text-sm leading-relaxed">جهت شروع آزمون، تطابق چهره شما با پروفایل کاربری <b>{userName}</b> الزامی است.</p>
          </div>

          <div className="relative aspect-square max-w-[280px] mx-auto rounded-[2.5rem] overflow-hidden bg-black border-4 border-slate-800 shadow-2xl">
             {status === 'request' ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 text-slate-500">
                   <Camera size={64} className="opacity-20" />
                   <button onClick={startCamera} className="bg-primary-600 hover:bg-primary-500 text-white px-8 py-3 rounded-2xl font-black text-xs transition-all">فعال‌سازی اسکنر چهره</button>
                </div>
             ) : (
                <>
                   <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover grayscale opacity-60" />
                   
                   {/* Scanning Overlay */}
                   <AnimatePresence>
                      {status === 'scanning' && (
                        <motion.div 
                          initial={{ top: 0 }} 
                          animate={{ top: '100%' }} 
                          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                          className="absolute left-0 right-0 h-1 bg-primary-500 shadow-[0_0_20px_#0ea5e9] z-10" 
                        />
                      )}
                   </AnimatePresence>

                   <div className="absolute inset-0 border-[40px] border-black/40 pointer-events-none"></div>
                   <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <Scan size={180} className={`text-primary-500/30 transition-all ${status === 'verifying' ? 'scale-110 opacity-100' : ''}`} strokeWidth={0.5} />
                   </div>

                   {status === 'verifying' && (
                      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm flex flex-col items-center justify-center gap-4 text-white">
                         <Loader2 className="animate-spin text-primary-500" size={48} />
                         <span className="text-xs font-black uppercase tracking-[0.3em] animate-pulse">Verifying Identity...</span>
                      </div>
                   )}

                   {status === 'success' && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 bg-emerald-500 flex flex-col items-center justify-center gap-4 text-slate-950">
                         <CheckCircle2 size={80} />
                         <span className="text-xl font-black uppercase">Identity Verified</span>
                      </motion.div>
                   )}
                </>
             )}
          </div>

          <div className="flex gap-3">
             <button onClick={onCancel} className="flex-1 py-4 text-slate-500 font-black text-xs uppercase tracking-widest hover:text-white transition-colors">لغو عملیات</button>
             <div className="flex-[2] flex items-center justify-center gap-2 text-[10px] font-bold text-slate-600 bg-white/5 rounded-2xl border border-white/5">
                <AlertCircle size={14} /> اسکنر به صورت خودکار فعال است
             </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProctoringCheck;
