
import React from 'react';

interface LogoProps {
  size?: number;
  className?: string;
  light?: boolean;
}

const BrandLogo: React.FC<LogoProps> = ({ size = 48, className = "", light = false }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} drop-shadow-xl`}
    >
      {/* Hexagonal Shield Background */}
      <path 
        d="M50 5L89 27.5V72.5L50 95L11 72.5V27.5L50 5Z" 
        fill={light ? "white" : "url(#logoGradient)"} 
        fillOpacity={light ? "0.2" : "1"}
        stroke={light ? "white" : "#0088cc"}
        strokeWidth="2"
      />
      
      {/* Stylized 'T' and Scales Concept */}
      <path 
        d="M35 35H65" 
        stroke={light ? "white" : "#BAE6FD"} 
        strokeWidth="6" 
        strokeLinecap="round" 
      />
      <path 
        d="M50 35V70" 
        stroke={light ? "white" : "#BAE6FD"} 
        strokeWidth="6" 
        strokeLinecap="round" 
      />
      <path 
        d="M30 70H70" 
        stroke={light ? "white" : "#38BDF8"} 
        strokeWidth="6" 
        strokeLinecap="round" 
      />
      
      {/* Network Nodes (Circles) */}
      <circle cx="30" cy="70" r="5" fill={light ? "white" : "#0EA5E9"} />
      <circle cx="70" cy="70" r="5" fill={light ? "white" : "#0EA5E9"} />
      <circle cx="50" cy="35" r="5" fill={light ? "white" : "#BAE6FD"} />
      
      {/* Gradients */}
      <defs>
        <linearGradient id="logoGradient" x1="11" y1="5" x2="89" y2="95" gradientUnits="userSpaceOnUse">
          <stop stopColor="#0C4A6E" />
          <stop offset="1" stopColor="#0088cc" />
        </linearGradient>
      </defs>
    </svg>
  );
};

export default BrandLogo;
