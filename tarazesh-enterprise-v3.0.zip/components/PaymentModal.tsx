
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CreditCard, Lock, CheckCircle2, Loader2, ShieldCheck, Calendar, Hash } from 'lucide-react';
import Modal from './Modal';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  amount: number | string;
  itemName: string;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSuccess, amount, itemName }) => {
  const [step, setStep] = useState<'form' | 'processing' | 'success'>('form');
  const [cardData, setCardData] = useState({ number: '', expiry: '', cvc: '', name: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    setTimeout(() => setStep('success'), 2500);
    setTimeout(() => {
      onSuccess();
      onClose();
      setStep('form');
    }, 4500);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="درگاه پرداخت امن ترازش" maxWidth="max-w-md">
      <div className="p-8 text-right" dir="rtl">
        <AnimatePresence mode="wait">
          {step === 'form' && (
            <motion.form 
              key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onSubmit={handleSubmit} className="space-y-6"
            >
              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-700 flex justify-between items-center">
                 <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase">مبلغ قابل پرداخت</p>
                    <p className="text-xl font-black text-primary-600">{amount.toLocaleString()} <span className="text-xs">تومان</span></p>
                 </div>
                 <div className="text-left">
                    <p className="text-[10px] font-black text-slate-400 uppercase">سرویس</p>
                    <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{itemName}</p>
                 </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                   <label className="text-[10px] font-black text-slate-400 uppercase mr-2">شماره کارت</label>
                   <div className="relative">
                      <input required className="w-full p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl font-mono text-center tracking-[0.3em] outline-none focus:ring-2 focus:ring-primary-500" placeholder="xxxx xxxx xxxx xxxx" value={cardData.number} onChange={e => setCardData({...cardData, number: e.target.value})} />
                      <CreditCard className="absolute left-4 top-4 text-slate-300" size={20} />
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase mr-2">تاریخ انقضا</label>
                      <input required className="w-full p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl font-mono text-center outline-none focus:ring-2 focus:ring-primary-500" placeholder="00/00" value={cardData.expiry} onChange={e => setCardData({...cardData, expiry: e.target.value})} />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase mr-2">CVV2</label>
                      <input required className="w-full p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl font-mono text-center outline-none focus:ring-2 focus:ring-primary-500" placeholder="***" value={cardData.cvc} onChange={e => setCardData({...cardData, cvc: e.target.value})} />
                   </div>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 bg-emerald-50 dark:bg-emerald-900/10 rounded-xl text-[10px] text-emerald-600 font-bold">
                 <ShieldCheck size={14} />
                 تراکنش شما توسط پروتکل SSL و استاندارد PCI رمزنگاری می‌شود.
              </div>

              <button type="submit" className="w-full py-4 bg-primary-600 text-white rounded-2xl font-black shadow-xl shadow-primary-600/20 hover:bg-primary-700 transition-all flex items-center justify-center gap-2">
                 <Lock size={18} /> پرداخت و تایید نهایی
              </button>
            </motion.form>
          )}

          {step === 'processing' && (
            <motion.div 
              key="proc" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
              className="py-20 text-center space-y-6"
            >
               <div className="relative w-20 h-20 mx-auto">
                  <div className="absolute inset-0 border-4 border-primary-500/20 rounded-full"></div>
                  <div className="absolute inset-0 border-4 border-primary-500 rounded-full border-t-transparent animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center text-primary-500"><CreditCard size={32} /></div>
               </div>
               <h3 className="text-xl font-black text-slate-800 dark:text-white">در حال ارتباط با بانک...</h3>
               <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Encrypting Transaction Data</p>
            </motion.div>
          )}

          {step === 'success' && (
            <motion.div 
              key="succ" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="py-16 text-center space-y-6"
            >
               <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xl">
                  <CheckCircle2 size={48} />
               </div>
               <div className="space-y-2">
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white">تراکنش موفقیت‌آمیز بود</h3>
                  <p className="text-sm text-slate-500 font-bold">سرویس مورد نظر بلافاصله برای شما فعال شد.</p>
               </div>
               <div className="bg-slate-50 dark:bg-white/5 p-4 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 font-mono text-[10px] text-slate-400">
                  REF_ID: {Math.random().toString(36).substring(2, 12).toUpperCase()}
               </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Modal>
  );
};

export default PaymentModal;
