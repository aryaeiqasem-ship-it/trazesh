
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Award, ShieldCheck, GraduationCap, School, Globe, QrCode, Diamond, CheckCircle2, Server, Database } from 'lucide-react';
import BrandLogo from './BrandLogo';
import { storageService } from '../services/storageService';

interface Props {
  userName: string;
  examTitle: string;
  score: number;
  date: string;
  securityHash: string;
}

const DigitalCertificate: React.FC<Props> = ({ userName, examTitle, score, date, securityHash }) => {
  const [isVerifying, setIsVerifying] = useState(true);
  const [verifyData, setVerifyData] = useState<any>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
        const data = storageService.verifyBlockchainHash(securityHash);
        setVerifyData(data);
        setIsVerifying(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, [securityHash]);

  return (
    <div className="w-full max-w-4xl aspect-[1.414/1] bg-white border-[16px] border-slate-900 p-12 relative overflow-hidden shadow-2xl font-sans" dir="rtl">
      {/* Background Ornaments */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary-500/5 rounded-full -mr-32 -mt-32 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/5 rounded-full -ml-32 -mb-32 blur-3xl"></div>
      
      {/* Border Decoration */}
      <div className="absolute inset-4 border-2 border-slate-100 pointer-events-none"></div>
      <div className="absolute inset-8 border border-slate-900/5 pointer-events-none"></div>

      <div className="relative h-full border-4 border-double border-slate-200 p-12 flex flex-col items-center text-center">
        
        {/* Header */}
        <div className="flex justify-between items-start w-full mb-8">
           <div className="text-right">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Serial Number</p>
              <p className="text-xs font-mono font-bold text-slate-800 uppercase">{securityHash.substring(0, 12)}</p>
           </div>
           <BrandLogo size={70} />
           <div className="text-left">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Issue Date</p>
              <p className="text-xs font-bold text-slate-800">{date}</p>
           </div>
        </div>

        <div className="space-y-6 flex-1">
           <div className="flex flex-col items-center gap-2">
              <div className="bg-amber-500 text-slate-950 p-3 rounded-2xl shadow-xl mb-2">
                 <Award size={40} strokeWidth={2.5} />
              </div>
              <h1 className="text-4xl font-black text-slate-900 tracking-tighter">گواهینامه شایستگی آموزشی</h1>
              <div className="h-1 w-32 bg-amber-500 rounded-full"></div>
           </div>

           <p className="text-lg font-bold text-slate-500 mt-6">این گواهی با کمال افتخار به هنرجوی گرامی</p>
           <h2 className="text-5xl font-black text-primary-600 my-4 tracking-tight">{userName}</h2>
           <p className="text-base font-bold text-slate-600 leading-relaxed max-w-2xl">
              به پاس تلاش‌های مستمر و کسب موفقیت در ارزیابی تخصصی <br/>
              <span className="text-slate-900 font-black">« {examTitle} »</span> <br/>
              با کسب تراز نمره <span className="text-emerald-600 font-black">{score} از ۲۰</span> اعطا می‌گردد.
           </p>
        </div>

        {/* Verification Hub (Live Preview) */}
        <div className="w-full bg-slate-50 rounded-3xl p-4 mb-8 border border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isVerifying ? 'bg-amber-100 text-amber-600 animate-pulse' : 'bg-emerald-100 text-emerald-600'}`}>
                    {isVerifying ? <Database size={20}/> : <ShieldCheck size={20}/>}
                </div>
                <div className="text-right">
                    <p className="text-[9px] font-black text-slate-400 uppercase">Blockchain Verification Status</p>
                    <p className="text-xs font-black text-slate-700">
                        {isVerifying ? 'در حال استعلام از گره‌های شبکه...' : 'تایید شده در دفتر کل توزیع شده (Mainnet)'}
                    </p>
                </div>
            </div>
            {verifyData && (
                <div className="text-left font-mono text-[9px] text-slate-400">
                    ID: {verifyData.node} <br/>
                    TS: {verifyData.timestamp.substring(0, 19)}
                </div>
            )}
        </div>

        {/* Footer */}
        <div className="w-full mt-auto flex justify-between items-end">
           <div className="text-right space-y-4">
              <div className="space-y-1">
                <p className="text-[10px] font-black text-slate-400 uppercase">Authorized Signature</p>
                <div className="w-32 h-12 border-b border-slate-200"></div>
                <p className="text-xs font-black">واحد آموزش ترازش اینترپرایز</p>
              </div>
           </div>

           <div className="flex flex-col items-center gap-2">
              <div className="p-2 border-2 border-slate-900/10 rounded-xl">
                 <QrCode size={54} className="text-slate-800" />
              </div>
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Scan to verify credential</p>
           </div>

           <div className="text-left space-y-4">
              <div className="flex items-center gap-3 text-emerald-600">
                 <Server size={28} />
                 <div className="text-left">
                    <p className="text-[8px] font-black uppercase tracking-widest text-slate-400">Ledger Index</p>
                    <p className="text-[10px] font-black uppercase">Block Verified</p>
                 </div>
              </div>
           </div>
        </div>

        {/* Holographic Seal */}
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-500 rounded-full opacity-10 blur-2xl"></div>
      </div>
    </div>
  );
};

export default DigitalCertificate;
