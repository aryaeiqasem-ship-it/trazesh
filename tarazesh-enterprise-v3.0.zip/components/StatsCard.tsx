
import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  colorClass: string; // e.g., 'text-blue-600'
  bgClass: string; // e.g., 'bg-blue-50'
  onClick?: () => void;
  className?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ 
  label, 
  value, 
  icon: Icon, 
  colorClass, 
  bgClass, 
  onClick,
  className = ''
}) => {
  return (
    <div 
      onClick={onClick}
      className={`bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center transition-all hover:-translate-y-0.5 ${onClick ? 'cursor-pointer hover:shadow-md' : ''} ${className}`}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${bgClass} ${colorClass} ml-3.5 shrink-0 shadow-inner`}>
        <Icon size={24} />
      </div>
      <div className="min-w-0">
        <p className="text-slate-500 dark:text-slate-400 text-[11px] font-bold mb-0.5 uppercase tracking-tighter truncate">{label}</p>
        <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight leading-none">{value}</h3>
      </div>
    </div>
  );
};

export default StatsCard;
