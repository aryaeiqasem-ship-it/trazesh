
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, BellOff, CheckCircle2, AlertCircle, FileText, 
  MessageSquare, Clock, X, CheckCheck, Target, Sparkles 
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { Notification, NotificationType, User } from '../types';

interface NotificationCenterProps {
  user: User;
  onClose: () => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ user, onClose }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const loadNotifs = () => {
      const all = storageService.getNotifications();
      setNotifications(all.filter(n => n.userId === user.id));
    };
    loadNotifs();
    const interval = setInterval(loadNotifs, 5000);
    return () => clearInterval(interval);
  }, [user.id]);

  const markRead = (id: string) => {
    storageService.markAsRead(id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllRead = () => {
    storageService.markAllAsRead(user.id);
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case NotificationType.EXAM_RESULT: return <Target className="text-emerald-500" size={18} />;
      case NotificationType.ASSIGNMENT: return <FileText className="text-indigo-500" size={18} />;
      case NotificationType.MESSAGE: return <MessageSquare className="text-primary-500" size={18} />;
      default: return <Sparkles className="text-amber-500" size={18} />;
    }
  };

  const formatTime = (iso: string) => {
    const date = new Date(iso);
    return date.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 10, scale: 0.95 }}
      className="absolute top-full left-0 mt-4 w-80 md:w-96 glass-panel rounded-3xl shadow-2xl border border-white/20 dark:border-white/5 overflow-hidden z-50"
    >
      <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white/50 dark:bg-slate-900/50">
        <div className="flex items-center gap-2">
          <Bell size={18} className="text-primary-500" />
          <h3 className="font-black text-sm text-slate-800 dark:text-white">اعلان‌های هوشمند</h3>
        </div>
        <button onClick={markAllRead} className="text-[10px] font-black text-primary-600 hover:text-primary-700 flex items-center gap-1">
          <CheckCheck size={14} /> خواندن همه
        </button>
      </div>

      <div className="max-h-[400px] overflow-y-auto custom-scrollbar p-2 space-y-2 bg-slate-50/30 dark:bg-slate-950/30">
        {notifications.length === 0 ? (
          <div className="py-12 text-center space-y-3 opacity-40">
             <BellOff size={48} className="mx-auto text-slate-300" />
             <p className="text-xs font-bold text-slate-500">هیچ اعلان جدیدی یافت نشد</p>
          </div>
        ) : (
          notifications.map((notif) => (
            <div 
              key={notif.id}
              onClick={() => markRead(notif.id)}
              className={`p-4 rounded-2xl transition-all cursor-pointer border flex gap-4 ${
                notif.isRead 
                  ? 'bg-white/40 dark:bg-slate-800/20 border-transparent opacity-60' 
                  : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 shadow-sm hover:scale-[1.01]'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${notif.isRead ? 'bg-slate-100 dark:bg-slate-800' : 'bg-slate-50 dark:bg-slate-700'}`}>
                {getIcon(notif.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start mb-1">
                  <h4 className={`text-xs font-black truncate ${notif.isRead ? 'text-slate-500' : 'text-slate-800 dark:text-slate-100'}`}>
                    {notif.title}
                  </h4>
                  <span className="text-[9px] font-bold text-slate-400 shrink-0">{formatTime(notif.timestamp)}</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-bold line-clamp-2">
                  {notif.message}
                </p>
              </div>
              {!notif.isRead && <div className="w-2 h-2 rounded-full bg-primary-500 mt-1 shrink-0 shadow-[0_0_8px_#0ea5e9]"></div>}
            </div>
          ))
        )}
      </div>
      
      <div className="p-3 bg-slate-50 dark:bg-slate-900/80 text-center border-t dark:border-slate-800">
         <button onClick={onClose} className="text-[10px] font-black text-slate-400 hover:text-slate-600 transition-colors uppercase tracking-widest">بستن پنل</button>
      </div>
    </motion.div>
  );
};

export default NotificationCenter;
