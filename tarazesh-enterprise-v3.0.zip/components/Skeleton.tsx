
import React from 'react';

interface SkeletonProps {
  className?: string;
}

export const Skeleton: React.FC<SkeletonProps> = ({ className = "" }) => {
  return (
    <div className={`animate-pulse bg-slate-200 dark:bg-slate-800 rounded-lg ${className}`}></div>
  );
};

export const CardSkeleton = () => (
  <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
    <div className="flex justify-between">
      <Skeleton className="w-12 h-12 rounded-2xl" />
      <Skeleton className="w-20 h-4 rounded-full" />
    </div>
    <Skeleton className="w-3/4 h-6" />
    <Skeleton className="w-full h-10" />
    <div className="flex justify-between mt-6">
      <Skeleton className="w-16 h-4" />
      <Skeleton className="w-24 h-8 rounded-xl" />
    </div>
  </div>
);
