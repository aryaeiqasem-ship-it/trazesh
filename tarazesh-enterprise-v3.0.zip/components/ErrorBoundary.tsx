
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCcw } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

/**
 * مدیریت خطاهای بحرانی فرانت‌اند با معماری کلاس
 */
// Fix: Explicitly extending Component to ensure inheritance of state, props, and setState is properly recognized by TypeScript
class ErrorBoundary extends Component<Props, State> {
  // Fix: Initializing state as a class property for better property check satisfaction
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  constructor(props: Props) {
    super(props);
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('System Critical Failure:', error, errorInfo);
    // Fix: setState is now correctly recognized as inherited from standard React Component
    this.setState({ errorInfo });
  }

  public render(): ReactNode {
    // Fix: state and props are now correctly recognized as inherited from standard React Component
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6 text-right font-sans" dir="rtl">
          <div className="max-w-2xl w-full bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl p-10 border border-red-100 dark:border-red-900/30">
            <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 rounded-3xl flex items-center justify-center mb-6 mx-auto">
              <AlertTriangle size={48} className="text-red-500" />
            </div>
            <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100 mb-2 text-center">اختلال در لایه عملیاتی</h1>
            <p className="text-slate-500 dark:text-slate-400 mb-8 text-center leading-relaxed font-bold">
              یک خطای غیرمنتظره در اجرای سامانه رخ داده است.
            </p>
            
            <div className="bg-slate-900 p-6 rounded-2xl mb-8 font-mono text-[11px] text-emerald-400 overflow-auto max-h-48 text-left shadow-inner" dir="ltr">
               <p className="text-rose-400 font-bold mb-2">{this.state.error?.toString()}</p>
               <pre className="opacity-60 whitespace-pre-wrap">
                  {this.state.errorInfo?.componentStack}
               </pre>
            </div>

            <div className="flex gap-4">
              <button onClick={() => window.location.href = '/'} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl font-black hover:bg-slate-200 transition-all">خانه</button>
              <button onClick={() => window.location.reload()} className="flex-[2] py-4 bg-primary-600 text-white rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-primary-700 transition-all shadow-xl">
                <RefreshCcw size={20} /> تلاش مجدد
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
