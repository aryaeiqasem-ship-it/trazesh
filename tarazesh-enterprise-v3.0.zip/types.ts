
export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN',
  DEVELOPER = 'DEVELOPER',
  PARENT = 'PARENT',
  SUPER_ADMIN = 'SUPER_ADMIN'
}

export interface PasswordResetRequest {
  id: string;
  userId: string;
  userName: string;
  studentId: string;
  timestamp: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  type: 'gold' | 'silver' | 'bronze' | 'platinum';
  unlockedAt: string;
  isLocked: boolean;
}

export interface DisciplinaryRecord {
  id: string;
  type: 'positive' | 'negative';
  title: string;
  description: string;
  date: string;
  points: number;
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  customRoleId?: string;
  studentId?: string;
  childId?: string;
  username?: string;
  password?: string;
  email?: string;
  phoneNumber?: string;
  avatar?: string;
  grade?: string;
  class?: string;
  major?: string; 
  academicYear?: string;
  isPremium?: boolean;
  subscriptionTier?: 'BASIC' | 'PRO' | 'ENTERPRISE';
  disciplinaryRecords?: DisciplinaryRecord[];
  gamification?: {
    xp: number;
    ipc?: number; 
    level: number;
    nextLevelXp: number;
    badges: Badge[];
    purchasedItems?: string[];
  };
}

export interface Message {
  id: string;
  senderId: string;
  receiverId?: string; 
  groupId?: string;    
  text: string;
  createdAt: string;
  isRead: boolean;
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentType?: 'image' | 'file' | 'pdf';
}

export interface ChatGroup {
  id: string;
  name: string;
  memberIds: string[];
  createdBy: string;
  avatar?: string;
  type: 'class' | 'custom';
}

export interface LicenseRecord {
  id: string;
  orgName: string;
  key: string;
  type: 'TRIAL' | 'PRO' | 'ENTERPRISE';
  issueDate: string;
  expiryDate: string;
  maxUsers: number;
  status: 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  price: number;
}

export interface SalesRecord {
  id: string;
  orgName: string;
  amount: number;
  date: string;
  plan: string;
}

export enum QuestionType {
  MULTIPLE_CHOICE = 'MULTIPLE_CHOICE',
  TRUE_FALSE = 'TRUE_FALSE',
  DESCRIPTIVE = 'DESCRIPTIVE'
}

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  correctAnswer: any;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
  tags?: string[];
  grade?: string;
  major?: string;
  courseId?: string;
  image?: string;
  sectionId?: string;
}

export interface ExamSection {
  id: string;
  title: string;
  description?: string;
  order: number;
}

export enum ExamType {
  OFFICIAL = 'OFFICIAL',
  PRACTICE = 'PRACTICE'
}

export interface Exam {
  id: string;
  title: string;
  description: string;
  durationMinutes: number;
  createdBy: string;
  status: 'active' | 'archived' | 'draft';
  type: ExamType;
  startDate: string;
  forClass: string;
  questions: Question[];
  sections?: ExamSection[];
  lockBrowser?: boolean;
  randomizeQuestions?: boolean;
  showResultImmediately?: boolean;
  allowReview?: boolean;
  securityLevel: 'low' | 'standard' | 'high' | 'military';
  rewardXp?: number; 
  requireFaceId?: boolean; 
}

export interface ExamResult {
  id: string;
  examId: string;
  studentId: string;
  answers: Record<string, any>; 
  score: number;
  maxScore: number;
  earnedXp?: number; 
  submittedAt: string;
  status: 'passed' | 'failed';
  cheatingAttempts: number;
  proctoringLogs?: string[];
  appealStatus?: 'none' | 'pending' | 'reviewed';
  appealMessage?: string;
  teacherResponse?: string;
  feedback?: string;
}

export interface LiveExamSession {
  examId: string;
  studentId: string;
  studentName: string;
  startTime: string;
  lastHeartbeat: string;
  progress: number; 
  alerts: string[];
  status: 'online' | 'disconnected' | 'submitted';
}

export interface Course { 
  id: string; 
  title: string; 
  code?: string; 
  category: 'GENERAL' | 'PODMANI' | 'SPECIALIZED' | string; 
  grade?: string; 
  major?: string; 
  description?: string;
}

export interface Assignment { 
  id: string; 
  title: string; 
  description: string; 
  dueDate: string; 
  classId: string; 
  attachmentUrl?: string;
  createdBy?: string;
  rewardXp?: number; 
}

export interface AssignmentSubmission { 
  id: string; 
  assignmentId: string; 
  studentId: string; 
  submittedAt: string; 
  grade?: number; 
  status: 'pending' | 'graded'; 
  textResponse?: string;
  fileUrl?: string;
  feedback?: string;
  earnedXp?: number;
}

export interface ClassEntity { 
  id: string; 
  title: string; 
  grade: string; 
  major: string; 
  teacherIds: string[]; 
  courseIds: string[]; 
}

export interface ShopItem {
  id: string;
  title: string;
  description: string;
  costXp: number;
  type: 'booster' | 'cosmetic' | 'privilege';
  icon: string;
}

export interface Major {
  id: string;
  title: string;
}

export interface Grade {
  id: string;
  title: string;
}

export type ChatMessage = Message;

export interface ScheduleItem {
  id: string;
  day: string;
  startTime: string;
  endTime: string;
  courseTitle: string;
  teacherName: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  features: string[];
  isPopular: boolean;
}

export interface Resource {
  id: string;
  title: string;
  description?: string;
  type: 'pdf' | 'video' | 'image' | 'link';
  url: string;
  classId: string;
  addedBy: string;
  dateAdded: string;
}

export interface Quote {
  id: string;
  text: string;
  author?: string;
}

export enum NotificationType {
  EXAM_RESULT = 'EXAM_RESULT',
  ASSIGNMENT = 'ASSIGNMENT',
  MESSAGE = 'MESSAGE',
  GAMIFICATION = 'GAMIFICATION',
  SYSTEM = 'SYSTEM'
}

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface AttendanceRecord {
  id: string;
  classId: string;
  courseId?: string;
  date: string;
  presentStudentIds: string[];
  absentStudentIds: string[];
  lateStudentIds: string[];
}

export interface SystemSettings {
  instituteName: string;
  branding: {
    primaryColor: string;
    logoUrl?: string;
    welcomeMessage?: string;
    quotes: Quote[];
  };
  allowPublicRegistration?: boolean;
  license: {
    plan: string;
    expiryDate: string;
    maxUsers?: number;
    status: 'ACTIVE' | 'EXPIRED' | 'REVOKED';
    activationKey?: string;
  };
}

export type Permission = string;

export interface CustomRole {
  id: string;
  name: string;
  permissions: Permission[];
}
