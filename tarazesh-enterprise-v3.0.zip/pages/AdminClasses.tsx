
import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { ClassEntity, Major, User, Course, UserRole, Grade } from '../types';
import { 
  Search, Plus, Edit, Trash2, School, Save, CheckSquare, Square, 
  Users, BookOpen, Layers, GraduationCap, ChevronLeft, MoreVertical,
  Target, Activity, Filter, X, ArrowUpRight, BookMarked, UserCheck, 
  Settings2, Hash, CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const AdminClasses: React.FC = () => {
  const [classes, setClasses] = useState<ClassEntity[]>(() => storageService.getClasses());
  const [majors] = useState<Major[]>(() => storageService.getMajors());
  const [grades] = useState<Grade[]>(() => storageService.getGrades());
  const [teachers] = useState<User[]>(() => storageService.getUsers().filter(u => u.role === UserRole.TEACHER));
  const [allCourses] = useState<Course[]>(() => storageService.getCourses());

  const [searchTerm, setSearchTerm] = useState('');
  const [filterMajor, setFilterMajor] = useState('all');
  const [filterGrade, setFilterGrade] = useState('all');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const toast = useToast();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassEntity | null>(null);
  const [formData, setFormData] = useState<Partial<ClassEntity>>({ 
    title: '', grade: '', major: '', teacherIds: [], courseIds: [] 
  });

  const filteredClasses = useMemo(() => {
    return classes.filter(cls => {
      const matchSearch = cls.title.toLowerCase().includes(searchTerm.toLowerCase());
      const matchMajor = filterMajor === 'all' || cls.major === filterMajor;
      const matchGrade = filterGrade === 'all' || cls.grade === filterGrade;
      return matchSearch && matchMajor && matchGrade;
    });
  }, [classes, searchTerm, filterMajor, filterGrade]);

  const handleOpenModal = (cls?: ClassEntity) => {
    if (cls) {
      setEditingClass(cls);
      setFormData({ ...cls });
    } else {
      setEditingClass(null);
      setFormData({ title: '', grade: '', major: '', teacherIds: [], courseIds: [] });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.title || !formData.grade || !formData.major) {
      toast.error('لطفاً فیلدهای الزامی (نام، پایه و رشته) را پر کنید.');
      return;
    }

    const newClass: ClassEntity = {
      id: editingClass ? editingClass.id : `cls_${Date.now()}`,
      title: formData.title!,
      grade: formData.grade!,
      major: formData.major!,
      teacherIds: formData.teacherIds || [],
      courseIds: formData.courseIds || []
    };

    const updated = editingClass 
      ? classes.map(c => c.id === editingClass.id ? newClass : c)
      : [newClass, ...classes];

    setClasses(updated);
    storageService.saveClasses(updated);
    toast.success(editingClass ? 'اطلاعات کلاس با موفقیت بروزرسانی شد.' : 'کلاس جدید با موفقیت ایجاد شد.');
    setIsModalOpen(false);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const updated = classes.filter(c => c.id !== deleteId);
    setClasses(updated);
    storageService.saveClasses(updated);
    toast.info('کلاس از حافظه سیستم حذف شد.');
    setDeleteId(null);
  };

  const toggleSelection = (listName: 'teacherIds' | 'courseIds', id: string) => {
    const current = [...(formData[listName] || [])];
    const index = current.indexOf(id);
    if (index > -1) current.splice(index, 1);
    else current.push(id);
    setFormData({ ...formData, [listName]: current });
  };

  return (
    <div className="space-y-8 pb-32">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-5">
           <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-3xl flex items-center justify-center text-primary-600 shadow-inner">
             <School size={36} />
           </div>
           <div>
              <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight">مدیریت واحدهای آموزشی</h1>
              <p className="text-sm text-slate-500 font-bold mt-1">تعریف کلاس‌ها، تخصیص اساتید و چیدمان دروس نیم‌سال</p>
           </div>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-4 rounded-2xl flex items-center gap-3 shadow-2xl shadow-primary-500/30 font-black transition-all hover:scale-105 active:scale-95">
          <Plus size={24} /> تعریف کلاس جدید
        </button>
      </div>

      {/* Advanced Filters */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative md:col-span-2">
           <input 
             type="text" 
             placeholder="جستجوی نام یا شناسه کلاس..." 
             className="w-full pl-4 pr-12 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-primary-500 transition-all"
             value={searchTerm}
             onChange={e => setSearchTerm(e.target.value)}
           />
           <Search className="absolute right-4 top-4.5 text-slate-400" size={22} />
        </div>
        <div className="relative">
          <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-black outline-none border-none text-slate-900 dark:text-white appearance-none cursor-pointer" value={filterGrade} onChange={e => setFilterGrade(e.target.value)}>
             <option value="all">همه پایه‌های تحصیلی</option>
             {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
          </select>
          <GraduationCap className="absolute left-4 top-4.5 text-slate-400 pointer-events-none" size={18} />
        </div>
        <div className="relative">
          <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-black outline-none border-none text-slate-900 dark:text-white appearance-none cursor-pointer" value={filterMajor} onChange={e => setFilterMajor(e.target.value)}>
             <option value="all">همه رشته‌های فعال</option>
             {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
          </select>
          <Layers className="absolute left-4 top-4.5 text-slate-400 pointer-events-none" size={18} />
        </div>
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence mode="popLayout">
          {filteredClasses.map(cls => {
            const classTeachers = teachers.filter(t => cls.teacherIds.includes(t.id));
            const classCourses = allCourses.filter(c => cls.courseIds.includes(c.id));
            
            return (
              <motion.div 
                key={cls.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-2xl transition-all group relative overflow-hidden"
              >
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-400 to-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                 
                 <div className="flex justify-between items-start mb-8">
                    <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-3xl flex items-center justify-center text-primary-600 shadow-inner group-hover:scale-110 transition-transform duration-500">
                       <Users size={32} />
                    </div>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300">
                       <button onClick={() => handleOpenModal(cls)} className="p-3 bg-blue-50 dark:bg-blue-900/30 text-blue-600 rounded-2xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"><Edit size={18}/></button>
                       <button onClick={() => setDeleteId(cls.id)} className="p-3 bg-rose-50 dark:bg-rose-900/30 text-rose-600 rounded-2xl hover:bg-rose-600 hover:text-white transition-all shadow-sm"><Trash2 size={18}/></button>
                    </div>
                 </div>

                 <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2 tracking-tight group-hover:text-primary-600 transition-colors">{cls.title}</h3>
                 
                 <div className="flex flex-wrap gap-2 mb-8">
                    <span className="text-[10px] font-black bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-4 py-1.5 rounded-full uppercase tracking-tighter">رشته {cls.major}</span>
                    <span className="text-[10px] font-black bg-slate-100 dark:bg-slate-800 text-slate-500 px-4 py-1.5 rounded-full uppercase tracking-tighter">پایه {cls.grade}</span>
                 </div>

                 <div className="space-y-4 pt-6 border-t border-slate-50 dark:border-slate-800">
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-2">
                          <UserCheck size={14} className="text-slate-400" />
                          <span className="text-[10px] font-bold text-slate-400 uppercase">کادر آموزشی:</span>
                       </div>
                       <div className="flex -space-x-2 space-x-reverse">
                          {classTeachers.slice(0, 3).map(t => (
                             <div key={t.id} className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white dark:border-slate-900 flex items-center justify-center text-[10px] font-black text-slate-600" title={t.name}>
                                {t.avatar ? <img src={t.avatar} className="w-full h-full rounded-full object-cover" /> : t.name.charAt(0)}
                             </div>
                          ))}
                          {classTeachers.length > 3 && <div className="w-8 h-8 rounded-full bg-slate-900 text-white border-2 border-white flex items-center justify-center text-[8px] font-black">+{classTeachers.length - 3}</div>}
                          {classTeachers.length === 0 && <span className="text-[10px] font-bold text-rose-400">بدون استاد</span>}
                       </div>
                    </div>

                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-2">
                          <BookMarked size={14} className="text-slate-400" />
                          <span className="text-[10px] font-bold text-slate-400 uppercase">واحدهای درسی:</span>
                       </div>
                       <span className="text-xs font-black text-slate-700 dark:text-slate-300">{classCourses.length} درس فعال</span>
                    </div>
                 </div>

                 <button onClick={() => handleOpenModal(cls)} className="w-full mt-8 py-3.5 bg-slate-50 dark:bg-slate-800 hover:bg-primary-600 hover:text-white text-slate-500 dark:text-slate-400 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">تغییر چیدمان و اساتید</button>
              </motion.div>
            )
          })}
        </AnimatePresence>
        {filteredClasses.length === 0 && (
          <div className="col-span-full py-40 text-center border-2 border-dashed rounded-[3rem] border-slate-200 dark:border-slate-800">
             <School size={80} className="mx-auto text-slate-100 dark:text-slate-800 mb-6" />
             <p className="text-slate-400 font-black text-2xl">کلاسی با مشخصات مورد نظر یافت نشد.</p>
          </div>
        )}
      </div>

      {/* Class Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingClass ? 'ویرایش تخصصی کلاس' : 'پیکربندی کلاس جدید'} maxWidth="max-w-5xl">
        <div className="p-8 space-y-10">
           {/* Section 1: Basic Info */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                 <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><Hash size={14}/> نام یا کد شناسایی کلاس</label>
                 <input className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="مثال: ریاضی ۱۰۱ - گروه الف" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><GraduationCap size={14}/> پایه هدف</label>
                    <select className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.grade} onChange={e => setFormData({...formData, grade: e.target.value})}>
                       <option value="">انتخاب...</option>
                       {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
                    </select>
                 </div>
                 <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><Layers size={14}/> رشته تحصیلی</label>
                    <select className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.major} onChange={e => setFormData({...formData, major: e.target.value})}>
                       <option value="">انتخاب...</option>
                       {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                    </select>
                 </div>
              </div>
           </div>

           {/* Section 2: Assignment Hub */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-10 border-t border-slate-100 dark:border-slate-800 pt-10">
              {/* Teacher Assignment */}
              <div className="space-y-5">
                 <div className="flex justify-between items-center px-2">
                    <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 flex items-center gap-2 uppercase"><UserCheck size={18} className="text-primary-500" /> تخصیص اساتید</h4>
                    <span className="text-[10px] font-black text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">{formData.teacherIds?.length} استاد منتخب</span>
                 </div>
                 <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-[2rem] border border-slate-100 dark:border-slate-700 h-64 overflow-y-auto custom-scrollbar space-y-2">
                    {teachers.map(t => {
                       const isSelected = formData.teacherIds?.includes(t.id);
                       return (
                          <button 
                            key={t.id} 
                            onClick={() => toggleSelection('teacherIds', t.id)}
                            className={`w-full p-3 rounded-xl flex items-center justify-between transition-all ${isSelected ? 'bg-primary-600 text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'}`}
                          >
                             <div className="flex items-center gap-3">
                                {isSelected ? <CheckCircle2 size={16} /> : <div className="w-4 h-4 rounded-full border-2 border-slate-200" />}
                                <span className="text-xs font-bold">{t.name}</span>
                             </div>
                             <span className="text-[9px] opacity-60 font-black uppercase">Teacher</span>
                          </button>
                       )
                    })}
                 </div>
              </div>

              {/* Course Assignment */}
              <div className="space-y-5">
                 <div className="flex justify-between items-center px-2">
                    <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 flex items-center gap-2 uppercase"><BookMarked size={18} className="text-indigo-500" /> تخصیص دروس</h4>
                    <span className="text-[10px] font-black text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">{formData.courseIds?.length} درس منتخب</span>
                 </div>
                 <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-[2rem] border border-slate-100 dark:border-slate-700 h-64 overflow-y-auto custom-scrollbar space-y-2">
                    {allCourses.filter(c => (!formData.major || c.major === formData.major) && (!formData.grade || c.grade === formData.grade)).map(c => {
                       const isSelected = formData.courseIds?.includes(c.id);
                       return (
                          <button 
                            key={c.id} 
                            onClick={() => toggleSelection('courseIds', c.id)}
                            className={`w-full p-3 rounded-xl flex items-center justify-between transition-all ${isSelected ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'}`}
                          >
                             <div className="flex items-center gap-3">
                                {isSelected ? <CheckCircle2 size={16} /> : <div className="w-4 h-4 rounded-full border-2 border-slate-200" />}
                                <span className="text-xs font-bold">{c.title}</span>
                             </div>
                             <span className="text-[9px] opacity-60 font-black uppercase">{c.code}</span>
                          </button>
                       )
                    })}
                    {allCourses.filter(c => (!formData.major || c.major === formData.major) && (!formData.grade || c.grade === formData.grade)).length === 0 && (
                      <p className="text-[10px] text-slate-400 font-bold text-center py-10 italic">ابتدا پایه و رشته کلاس را انتخاب کنید.</p>
                    )}
                 </div>
              </div>
           </div>

           <div className="flex justify-end gap-3 pt-8 border-t border-slate-100 dark:border-slate-800">
              <button onClick={() => setIsModalOpen(false)} className="px-10 py-4 text-slate-400 font-black hover:text-slate-700 transition-colors uppercase text-xs tracking-widest">انصراف</button>
              <button onClick={handleSave} className="bg-primary-600 hover:bg-primary-700 text-white px-16 py-4 rounded-2xl font-black shadow-2xl shadow-primary-500/30 transition-all flex items-center gap-3">
                 <Save size={22} /> ذخیره و ثبت نهایی در سازمان
              </button>
           </div>
        </div>
      </Modal>

      <ConfirmationModal 
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="حذف دائمی واحد آموزشی"
        description="آیا از حذف این کلاس اطمینان کامل دارید؟ تمامی رکوردهای حضور و غیاب و ارجاعات دانش‌آموزان به این واحد به صورت غیرقابل بازگشت پاک خواهد شد."
        confirmText="بله، حذف کن"
      />
    </div>
  );
};

export default AdminClasses;
