
import React, { useMemo } from 'react';
import { User, UserRole, ExamResult, AttendanceRecord } from '../types';
import { storageService } from '../services/storageService';
import { 
  Users, TrendingUp, Calendar, BookOpen, ShieldCheck, 
  Target, Activity, Award, Bell, ChevronLeft, Star, 
  AlertCircle, CheckCircle2, PieChart as PieIcon, LineChart as LineIcon
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, BarChart, Bar, Cell 
} from 'recharts';
import { motion } from 'framer-motion';

interface ParentProps {
  currentUser: User;
  onNavigate: (view: string, data?: any) => void;
}

const ParentDashboard: React.FC<ParentProps> = ({ currentUser, onNavigate }) => {
  const child = storageService.getUsers().find(u => u.id === currentUser.childId);
  const results = storageService.getResults().filter(r => r.studentId === child?.id);
  const attendance = storageService.getAttendance();

  const metrics = useMemo(() => {
    if (!child) return null;
    const allScores = results.map(r => (r.score / r.maxScore) * 20);
    const avg = allScores.length ? (allScores.reduce((a, b) => a + b, 0) / allScores.length).toFixed(2) : '0';
    
    // محاسبه درصد حضور
    let presentDays = 0;
    let totalDays = 0;
    attendance.forEach(record => {
      totalDays++;
      if (record.presentStudentIds.includes(child.id)) presentDays++;
    });
    const attendPercent = totalDays ? Math.round((presentDays / totalDays) * 100) : 100;

    return { avg, attendPercent, examsCount: results.length, level: child.gamification?.level || 1 };
  }, [child, results, attendance]);

  const chartData = results.map((r, i) => ({ 
    name: `آزمون ${i+1}`, 
    score: (r.score / r.maxScore) * 20 
  }));

  if (!child) return <div className="p-20 text-center text-slate-500">اطلاعات فرزند یافت نشد.</div>;

  return (
    <div className="space-y-8 pb-32">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
         <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-[2rem] bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center border-4 border-white dark:border-slate-800 shadow-xl overflow-hidden">
               {child.avatar ? <img src={child.avatar} className="w-full h-full object-cover" /> : <Users size={40} className="text-indigo-600" />}
            </div>
            <div>
               <h1 className="text-3xl font-black text-slate-800 dark:text-white">پیشخوان والدین: {child.name}</h1>
               <p className="text-sm text-slate-500 font-bold mt-1">گزارش وضعیت تحصیلی پایه {child.grade} - رشته {child.major}</p>
            </div>
         </div>
         <div className="flex gap-3">
            <div className="bg-emerald-50 dark:bg-emerald-900/20 px-6 py-3 rounded-2xl border border-emerald-100 dark:border-emerald-800 flex items-center gap-3">
               <ShieldCheck className="text-emerald-600" size={24} />
               <span className="text-xs font-black text-emerald-700 dark:text-emerald-400 uppercase">وضعیت: فعال و ایمن</span>
            </div>
         </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
         {[
           { label: 'معدل کل ترم', val: metrics?.avg, icon: Target, color: 'text-primary-600', bg: 'bg-primary-50' },
           { label: 'درصد حضور', val: `${metrics?.attendPercent}%`, icon: Calendar, color: 'text-emerald-600', bg: 'bg-emerald-50' },
           { label: 'سطح تحصیلی', val: metrics?.level, icon: Award, color: 'text-amber-600', bg: 'bg-amber-50' },
           { label: 'آزمون‌های طی شده', val: metrics?.examsCount, icon: BookOpen, color: 'text-indigo-600', bg: 'bg-indigo-50' }
         ].map((s, i) => (
           <div key={i} className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${s.bg} dark:bg-opacity-10 ${s.color} shadow-inner`}>
                 <s.icon size={28} />
              </div>
              <div>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{s.label}</p>
                 <p className="text-2xl font-black text-slate-800 dark:text-white">{s.val}</p>
              </div>
           </div>
         ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
         {/* Academic Trend */}
         <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex justify-between items-center mb-10">
               <h3 className="font-black text-xl flex items-center gap-3">
                  <TrendingUp size={24} className="text-primary-600" /> روند پیشرفت نمرات
               </h3>
               <button onClick={() => onNavigate('student_results')} className="text-[10px] font-black text-slate-400 uppercase hover:text-primary-600 transition-colors">مشاهده جزئیات کارنامه</button>
            </div>
            <div className="h-64">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                     <XAxis dataKey="name" hide />
                     <YAxis domain={[0, 20]} fontSize={10} tick={{fill: '#94a3b8'}} axisLine={false} />
                     <Tooltip />
                     <Area type="monotone" dataKey="score" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.1} strokeWidth={4} />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* AI Prediction */}
         <div className="lg:col-span-4 bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 p-8 opacity-10"><Activity size={120} /></div>
            <div className="relative z-10 space-y-8">
               <div className="flex items-center gap-3">
                  <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md"><LineIcon size={32} className="text-primary-400" /></div>
                  <h3 className="text-xl font-black">تحلیل هوشمند (AI Insight)</h3>
               </div>
               <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 italic text-sm leading-relaxed text-slate-300">
                  « بر اساس روندهای اخیر، پیش‌بینی می‌شود فرزند شما ترم را با معدل بالای ۱۸.۵ به اتمام برساند. نقاط قوت اصلی او در دروس اختصاصی مشاهده شده است. پیشنهاد می‌شود روی مباحث "گراف" تمرکز بیشتری داشته باشد. »
               </div>
               <div className="flex items-center justify-between pt-4">
                  <div>
                     <p className="text-[10px] font-black text-slate-500 uppercase mb-1">دقت تحلیل</p>
                     <p className="text-lg font-black text-primary-400">۹۲٪</p>
                  </div>
                  <CheckCircle2 size={32} className="text-emerald-500" />
               </div>
            </div>
         </div>
      </div>

      {/* Recent Alerts */}
      <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
         <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
            <h3 className="font-black text-xl">آخرین وقایع و اطلاعیه‌ها</h3>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">۳ مورد جدید</span>
         </div>
         <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {[
               { title: 'ثبت نمره نهایی', msg: `نمره آزمون "ریاضیات گسسته" برای ${child.name} ثبت شد (۱۸ از ۲۰).`, icon: Star, color: 'text-amber-500' },
               { title: 'تاخیر در ورود', msg: `فرزند شما در تاریخ ۱۴۰۳/۰۶/۱۵ با ۱۰ دقیقه تاخیر وارد کلاس شد.`, icon: Clock, color: 'text-rose-500' },
               { title: 'دریافت نشان افتخار', msg: `تبریک! ${child.name} نشان "استاد ریاضی" را کسب کرد.`, icon: Award, color: 'text-indigo-500' },
            ].map((alert, i) => (
               <div key={i} className="p-6 flex items-start gap-5 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <div className={`w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 ${alert.color}`}>
                     <alert.icon size={24} />
                  </div>
                  <div>
                     <h4 className="font-black text-slate-800 dark:text-white mb-1">{alert.title}</h4>
                     <p className="text-sm text-slate-500 dark:text-slate-400 font-bold leading-relaxed">{alert.msg}</p>
                  </div>
                  <button className="mr-auto p-2 text-slate-300 hover:text-primary-600"><ChevronLeft size={20}/></button>
               </div>
            ))}
         </div>
      </div>
    </div>
  );
};

const Clock = ({ size, className }: { size: number, className?: string }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
);

export default ParentDashboard;
