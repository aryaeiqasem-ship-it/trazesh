
import React, { useState } from 'react';
import { SUBSCRIPTION_PLANS } from '../services/mockData';
import { Check, Shield, Zap, Globe, CreditCard, Star, Lock, Info, X, ShieldCheck, Crown, Activity, Gem } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { storageService } from '../services/storageService';
import { useToast } from '../contexts/ToastContext';
import PaymentModal from '../components/PaymentModal';
import confetti from 'canvas-confetti';

interface Props {
  onRefreshUser?: () => void;
}

const AdminSubscription: React.FC<Props> = ({ onRefreshUser }) => {
  const toast = useToast();
  const settings = storageService.getSettings();
  const currentPlan = settings.license?.plan || 'BASIC';
  const [paymentTarget, setPaymentTarget] = useState<{name: string, price: number, planId: string} | null>(null);

  const compareFeatures = [
    { name: 'تعداد دانش‌آموز', basic: 'تا ۵۰ نفر', pro: 'تا ۱۰۰۰ نفر', enterprise: 'نامحدود' },
    { name: 'تصحیح هوشمند (AI)', basic: false, pro: true, enterprise: true },
    { name: 'تولید آزمون با هوش مصنوعی', basic: false, pro: '۱۰ آزمون/ماه', enterprise: 'نامحدود' },
    { name: 'برندینگ اختصاصی', basic: false, pro: false, enterprise: true },
    { name: 'دسترسی به API', basic: false, pro: false, enterprise: true },
    { name: 'پشتیبانی', basic: 'تیکت', pro: 'تلفنی ۲۴ ساعته', enterprise: 'مدیر حساب اختصاصی' },
    { name: 'امنیت پیشرفته (Proctoring)', basic: false, pro: true, enterprise: true },
  ];

  const handleUpgradeRequest = (plan: any) => {
    setPaymentTarget({
      name: `ارتقا به پلن ${plan.name}`,
      price: plan.price,
      planId: plan.id.replace('plan_', '').toUpperCase()
    });
  };

  const handlePaymentSuccess = () => {
    if (!paymentTarget) return;
    
    const settings = storageService.getSettings();
    settings.license = {
      ...settings.license,
      plan: paymentTarget.planId,
      status: 'ACTIVE',
      expiryDate: '1405/01/01'
    };
    
    storageService.saveSettings(settings);
    
    // Update local user state if needed
    const currentUser = storageService.getCurrentUser();
    if (currentUser) {
        currentUser.isPremium = true;
        currentUser.subscriptionTier = paymentTarget.planId as any;
        storageService.saveUser(currentUser);
    }

    if (onRefreshUser) onRefreshUser();
    
    toast.success(`پلن شما با موفقیت به ${paymentTarget.planId} ارتقا یافت! ✨`);
    confetti({ particleCount: 150, spread: 70, colors: ['#fbbf24', '#f59e0b'] });
  };

  return (
    <div className="space-y-12 pb-24 animate-fade-in">
      <div className="text-center max-w-3xl mx-auto pt-6">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-black uppercase tracking-widest mb-6 border border-indigo-100 dark:border-indigo-800"
        >
          <Crown size={14} /> طرح‌های تجاری سامانه
        </motion.div>
        <h1 className="text-4xl font-black text-slate-900 dark:text-white mb-4 tracking-tight">قدرت سامانه خود را افزایش دهید</h1>
        <p className="text-slate-500 dark:text-slate-400 text-lg leading-relaxed">
          با ارتقای سطح اشتراک، به قابلیت‌های هوش مصنوعی، برندینگ اختصاصی و ابزارهای مانیتورینگ پیشرفته دسترسی پیدا کنید.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto px-4">
        {SUBSCRIPTION_PLANS.map((plan, index) => {
          const planIdUpper = plan.id.replace('plan_', '').toUpperCase();
          const isCurrent = currentPlan === planIdUpper;
          return (
            <motion.div 
              key={plan.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative rounded-[2.5rem] p-10 border-2 flex flex-col transition-all duration-500 ${
                plan.isPopular 
                  ? 'bg-slate-900 text-white border-slate-900 shadow-[0_20px_50px_rgba(0,0,0,0.3)] scale-105 z-10' 
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white shadow-xl shadow-slate-200/50 dark:shadow-none'
              }`}
            >
              {plan.isPopular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-6 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-xl border border-white/20">
                   پیشنهاد ویژه
                </div>
              )}

              {isCurrent && (
                <div className="absolute top-4 right-4 flex items-center gap-1.5 bg-green-500 text-white px-3 py-1 rounded-full text-[10px] font-bold">
                   <Check size={12} /> پلن فعلی
                </div>
              )}

              <div className="mb-8">
                <h3 className={`text-xl font-black mb-3 ${plan.isPopular ? 'text-indigo-400' : 'text-slate-500 dark:text-slate-400'}`}>{plan.name}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-black tracking-tighter">
                     {plan.price === 0 ? 'رایگان' : plan.price.toLocaleString()}
                  </span>
                  <span className={`text-sm font-bold ${plan.isPopular ? 'text-slate-400' : 'text-slate-500'}`}>
                     {plan.price !== 0 && 'تومان / ماهانه'}
                  </span>
                </div>
              </div>

              <ul className="space-y-5 mb-10 flex-1">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-4 text-sm font-medium">
                    <div className={`mt-0.5 rounded-full p-1 ${plan.isPopular ? 'bg-indigo-500/20 text-indigo-400' : 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'}`}>
                      <Check size={14} strokeWidth={3} />
                    </div>
                    <span className={plan.isPopular ? 'text-slate-300' : 'text-slate-700 dark:text-slate-300'}>{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => handleUpgradeRequest(plan)}
                disabled={isCurrent}
                className={`w-full py-5 rounded-2xl font-black text-sm tracking-wide transition-all shadow-xl active:scale-95 disabled:opacity-50 disabled:scale-100 ${
                  plan.isPopular 
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-600/30' 
                    : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100'
                }`}
              >
                {isCurrent ? 'پلن فعلی شما' : plan.price === 0 ? 'شروع رایگان' : 'خرید و ارتقا آنی'}
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Plan Comparison Table */}
      <div className="max-w-5xl mx-auto bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
         <div className="p-8 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <h2 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-3">
               <Activity className="text-primary-500" />
               مقایسه فنی قابلیت‌ها
            </h2>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full text-right">
               <thead>
                  <tr className="text-xs text-slate-400 font-black uppercase tracking-widest bg-slate-50 dark:bg-slate-950/50">
                     <th className="px-8 py-4">قابلیت</th>
                     <th className="px-8 py-4 text-center">Basic</th>
                     <th className="px-8 py-4 text-center">Pro</th>
                     <th className="px-8 py-4 text-center">Enterprise</th>
               </tr>
               </thead>
               <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {compareFeatures.map((feat, i) => (
                     <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="px-8 py-5 text-sm font-bold text-slate-700 dark:text-slate-200">{feat.name}</td>
                        <td className="px-8 py-5 text-center text-sm">
                           {typeof feat.basic === 'boolean' 
                              ? (feat.basic ? <Check className="mx-auto text-green-500" /> : <X className="mx-auto text-slate-300" />)
                              : feat.basic}
                        </td>
                        <td className="px-8 py-5 text-center text-sm font-bold text-indigo-600 dark:text-indigo-400">
                           {typeof feat.pro === 'boolean' 
                              ? (feat.pro ? <Check className="mx-auto text-green-500" /> : <X className="mx-auto text-slate-300" />)
                              : feat.pro}
                        </td>
                        <td className="px-8 py-5 text-center text-sm font-black text-slate-900 dark:text-white">
                           {typeof feat.enterprise === 'boolean' 
                              ? (feat.enterprise ? <Check className="mx-auto text-green-500" /> : <X className="mx-auto text-slate-300" />)
                              : feat.enterprise}
                        </td>
                     </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      <PaymentModal 
        isOpen={!!paymentTarget} 
        onClose={() => setPaymentTarget(null)} 
        onSuccess={handlePaymentSuccess}
        amount={paymentTarget?.price || 0}
        itemName={paymentTarget?.name || ''}
      />
    </div>
  );
};

export default AdminSubscription;
