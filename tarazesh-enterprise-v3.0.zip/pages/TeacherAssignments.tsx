import React, { useState, useEffect, useRef } from 'react';
import { storageService } from '../services/storageService';
import { Assignment, AssignmentSubmission, ClassEntity, NotificationType } from '../types';
import { FileText, Plus, Calendar, Save, X, Download, Paperclip, Upload, Loader2, FileUp, Trash2, CheckCircle, Mic, Star, Image as ImageIcon, Zap, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';
import VoiceRecorder from '../components/VoiceRecorder';

const TeacherAssignments: React.FC = () => {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>([]);
  const [classes, setClasses] = useState<ClassEntity[]>([]);
  
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const [formData, setFormData] = useState<Partial<Assignment>>({
    title: '', description: '', dueDate: '', classId: '', attachmentUrl: '', rewardXp: 50
  });

  const [deleteId, setDeleteId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const toast = useToast();

  useEffect(() => {
    setAssignments(storageService.getAssignments());
    setSubmissions(storageService.getSubmissions());
    setClasses(storageService.getClasses());
  }, []);

  const handleSaveAssignment = async () => {
    if (!formData.title || !formData.classId || !formData.dueDate) return toast.error('لطفا فیلدهای الزامی را پر کنید.');
    
    setIsUploading(true);
    try {
      let attachmentUrl = formData.attachmentUrl;
      if (selectedFile) {
        const uploadRes = await storageService.uploadFile(selectedFile);
        attachmentUrl = uploadRes.url;
      }

      const newAsg: Assignment = {
        id: `asg_${Date.now()}`,
        title: formData.title!,
        description: formData.description || '',
        dueDate: formData.dueDate!,
        classId: formData.classId!,
        attachmentUrl: attachmentUrl,
        createdBy: '2',
        rewardXp: formData.rewardXp || 50
      };
      
      const updated = [newAsg, ...assignments];
      setAssignments(updated);
      storageService.saveAssignments(updated);

      // Notify Students
      const targetClass = classes.find(c => c.id === formData.classId);
      const allUsers = storageService.getUsers();
      const studentsInClass = allUsers.filter(u => u.class === targetClass?.title);
      studentsInClass.forEach(student => {
          storageService.addNotification({
              userId: student.id,
              type: NotificationType.ASSIGNMENT,
              title: 'تکلیف جدید ابلاغ شد',
              message: `تکلیف "${formData.title}" برای شما ثبت شده است. مهلت: ${new Date(formData.dueDate!).toLocaleDateString('fa-IR')}`
          });
      });

      setIsCreateModalOpen(false);
      resetForm();
      toast.success('تکلیف جدید با موفقیت ابلاغ شد.');
    } catch (error) {
      toast.error("خطا در بارگذاری فایل.");
    } finally {
      setIsUploading(false);
    }
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', dueDate: '', classId: '', attachmentUrl: '', rewardXp: 50 });
    setSelectedFile(null);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const updated = assignments.filter(a => a.id !== deleteId);
    setAssignments(updated);
    storageService.saveAssignments(updated);
    setDeleteId(null);
    toast.info('تکلیف حذف شد.');
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-3"><FileText className="text-primary-600" /> مدیریت تکالیف درسی</h1>
          <p className="text-sm text-slate-500 font-bold mt-1">ابلاغ پروژه‌ها، جمع‌آوری پاسخ‌ها و ارزشیابی نهایی</p>
        </div>
        <button onClick={() => setIsCreateModalOpen(true)} className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3.5 rounded-2xl flex items-center gap-2 shadow-xl font-black transition-all hover:scale-105 active:scale-95">
          <Plus size={20} /> ابلاغ تکلیف جدید
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {assignments.map(asg => {
            const classInfo = classes.find(c => c.id === asg.classId);
            const subCount = submissions.filter(s => s.assignmentId === asg.id).length;
            return (
               <div key={asg.id} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group flex flex-col h-full">
                  <div className="flex justify-between items-start mb-6">
                     <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-2xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform"><FileText size={24}/></div>
                     <button onClick={() => setDeleteId(asg.id)} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={18}/></button>
                  </div>
                  <h3 className="font-black text-xl text-slate-900 dark:text-white mb-2 leading-tight">{asg.title}</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-6">کلاس: {classInfo?.title || 'نامشخص'} • {subCount} پاسخ دریافت شده</p>
                  <div className="mt-auto pt-6 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center">
                     <span className="text-[9px] font-black bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full uppercase">در صف بررسی</span>
                     <button className="text-[10px] font-black text-primary-600 hover:underline">مشاهده لیست تحویل</button>
                  </div>
               </div>
            );
         })}
      </div>

      <Modal isOpen={isCreateModalOpen} onClose={() => !isUploading && setIsCreateModalOpen(false)} title="ابلاغ تکلیف جدید" maxWidth="max-w-3xl">
         <div className="p-8 space-y-8 text-right">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block mr-2">عنوان تکلیف</label>
                  <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-black dark:text-white" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="مثال: تحقیق فصل سوم" />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block mr-2">کلاس هدف</label>
                  <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-black dark:text-white" value={formData.classId} onChange={e => setFormData({...formData, classId: e.target.value})}>
                     <option value="">انتخاب کلاس...</option>
                     {classes.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                  </select>
               </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block mr-2">مهلت تحویل</label>
                  <input type="date" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-black dark:text-white" value={formData.dueDate} onChange={e => setFormData({...formData, dueDate: e.target.value})} />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase block mr-2">پاداش (XP)</label>
                  <input type="number" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-center text-lg outline-none text-black dark:text-white" value={formData.rewardXp} onChange={e => setFormData({...formData, rewardXp: parseInt(e.target.value)})} />
               </div>
            </div>
            <div className="space-y-2">
               <label className="text-[10px] font-black text-slate-400 uppercase block mr-2">شرح کامل تکلیف</label>
               <textarea className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-black dark:text-white" rows={4} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="توضیحات لازم را برای هنرجویان بنویسید..." />
            </div>
            <button onClick={handleSaveAssignment} disabled={isUploading} className="w-full py-5 bg-primary-600 text-white rounded-[2rem] font-black shadow-2xl flex items-center justify-center gap-3 transition-all">
               {isUploading ? <Loader2 className="animate-spin" /> : <><Save size={24}/> ابلاغ و انتشار برای هنرجویان</>}
            </button>
         </div>
      </Modal>

      <ConfirmationModal isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="حذف تکلیف" description="آیا از حذف این تکلیف و تمامی پاسخ‌های دریافت شده اطمینان دارید؟" confirmText="بله، حذف شود" />
    </div>
  );
};

export default TeacherAssignments;