import React, { useState, useEffect, useRef, useMemo } from 'react';
import { User, Message, UserRole, ChatGroup, NotificationType } from '../types';
import { storageService } from '../services/storageService';
import { 
  Send, Search, Phone, ArrowRight, 
  User as UserIcon, Check, CheckCheck, Users as GroupsIcon, 
  Trash2, MessageSquarePlus, Shield, X, Paperclip, FileText, Download, Loader2,
  UserMinus, MessageCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';
import { compressImage } from '../utils/imageUtils';

interface MessengerProps {
  currentUser: User;
  initialUserId?: string | null;
}

const Messenger: React.FC<MessengerProps> = ({ currentUser, initialUserId }) => {
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [groups, setGroups] = useState<ChatGroup[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(initialUserId || null);
  const [isGroupChat, setIsGroupChat] = useState(false);
  const [inputText, setInputText] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [mobileShowChat, setMobileShowChat] = useState(false);
  
  const onlineUsers = useMemo(() => new Set(['2', '3', 'admin', 'dev_01']), []);

  const [isUploading, setIsUploading] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<{id: string, isGroup: boolean} | null>(null);
  const [adminModerationMode, setAdminModerationMode] = useState(false);

  const [newGroupName, setNewGroupName] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const toast = useToast();
  const isAdmin = [UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.DEVELOPER].includes(currentUser.role);
  const isTeacher = currentUser.role === UserRole.TEACHER;

  useEffect(() => {
    const users = storageService.getUsers();
    setAllUsers(users);
  }, []);

  useEffect(() => {
    const allGroups = storageService.getGroups();
    if (adminModerationMode && isAdmin) {
      setGroups(allGroups);
    } else {
      setGroups(allGroups.filter(g => g.memberIds.includes(currentUser.id)));
    }
  }, [currentUser.id, adminModerationMode, isAdmin]);

  const fetchMessages = () => {
    const allMessages = storageService.getMessages();
    setMessages(allMessages);
  };

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedChatId && !isGroupChat) {
      const allMsgs = storageService.getMessages();
      const hasUnread = allMsgs.some(m => m.receiverId === currentUser.id && m.senderId === selectedChatId && !m.isRead);
      
      if (hasUnread) {
        const updated = allMsgs.map(m => 
          (m.receiverId === currentUser.id && m.senderId === selectedChatId) ? { ...m, isRead: true } : m
        );
        storageService.saveMessages(updated);
        setMessages(updated);
      }
    }
  }, [selectedChatId, isGroupChat, currentUser.id]);

  const activeChatUserIds = useMemo(() => {
    const ids = new Set<string>();
    messages.forEach(m => {
        if (m.receiverId === currentUser.id) ids.add(m.senderId);
        if (m.senderId === currentUser.id && m.receiverId) ids.add(m.receiverId);
    });
    return Array.from(ids);
  }, [messages, currentUser.id]);

  const activeUsers = useMemo(() => {
    return allUsers.filter(u => activeChatUserIds.includes(u.id) && u.id !== currentUser.id);
  }, [allUsers, activeChatUserIds, currentUser.id]);

  const scrollToBottom = () => {
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
  };

  useEffect(() => {
    if (selectedChatId) scrollToBottom();
  }, [selectedChatId, messages.length]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !pendingFile) || !selectedChatId) return;

    setIsUploading(true);
    let attachmentUrl = undefined;
    let attachmentName = undefined;
    let attachmentType: any = undefined;

    try {
        if (pendingFile) {
            const uploadRes = await storageService.uploadFile(pendingFile);
            attachmentUrl = uploadRes.url;
            attachmentName = pendingFile.name;
            const ext = pendingFile.name.split('.').pop()?.toLowerCase();
            if (['jpg', 'jpeg', 'png', 'webp'].includes(ext || '')) attachmentType = 'image';
            else if (ext === 'pdf') attachmentType = 'pdf';
            else attachmentType = 'file';
        }

        const newMessage: Message = {
          id: `msg_${Date.now()}`,
          senderId: currentUser.id,
          text: inputText,
          createdAt: new Date().toISOString(),
          isRead: false,
          attachmentUrl,
          attachmentName,
          attachmentType
        };

        if (isGroupChat) newMessage.groupId = selectedChatId;
        else newMessage.receiverId = selectedChatId;

        const allMsgs = storageService.getMessages();
        const updatedMessages = [...allMsgs, newMessage];
        storageService.saveMessages(updatedMessages);
        setMessages(updatedMessages);

        // Add Notification for Receiver
        if (!isGroupChat) {
            storageService.addNotification({
                userId: selectedChatId,
                type: NotificationType.MESSAGE,
                title: 'پیام جدید',
                message: `${currentUser.name}: ${inputText.substring(0, 30)}${inputText.length > 30 ? '...' : ''}`
            });
        }

        setInputText('');
        setPendingFile(null);
    } catch (err) {
        toast.error('خطا در ارسال پیام.');
    } finally {
        setIsUploading(false);
    }
  };

  const currentConversation = useMemo(() => {
    return messages.filter(m => {
      if (isGroupChat) return m.groupId === selectedChatId;
      return (m.senderId === currentUser.id && m.receiverId === selectedChatId) ||
             (m.senderId === selectedChatId && m.receiverId === currentUser.id);
    }).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }, [messages, selectedChatId, isGroupChat, currentUser.id]);

  const selectedTarget = isGroupChat 
    ? groups.find(g => g.id === selectedChatId) 
    : allUsers.find(u => u.id === selectedChatId);

  const isOnline = (uid: string) => onlineUsers.has(uid);

  return (
    <div className="h-[calc(100vh-140px)] flex bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 relative font-sans" dir="rtl">
      {/* Sidebar */}
      <div className={`w-full md:w-96 border-l border-slate-100 dark:border-slate-800 flex flex-col bg-slate-50 dark:bg-slate-900/50 absolute inset-0 z-10 md:relative transition-transform duration-300 ${mobileShowChat ? 'translate-x-full md:translate-x-0' : 'translate-x-0'}`}>
         <div className="p-6 border-b dark:border-slate-800 bg-white dark:bg-slate-900/80 backdrop-blur-md text-right">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tighter uppercase">پیام‌رسان</h2>
                <div className="flex gap-2">
                    {(isAdmin || isTeacher) && (
                        <button onClick={() => setAdminModerationMode(!adminModerationMode)} className={`p-2.5 rounded-2xl transition-all ${adminModerationMode ? 'bg-rose-500 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`} title="نظارت سیستمی">
                            <Shield size={18} />
                        </button>
                    )}
                    <button onClick={() => setIsCreateGroupOpen(true)} className="p-2.5 bg-primary-50 dark:bg-primary-900/20 text-primary-600 rounded-2xl hover:bg-primary-600 hover:text-white transition-all shadow-sm">
                        <MessageSquarePlus size={20} />
                    </button>
                </div>
            </div>
            <div className="relative group">
              <input 
                type="text" 
                placeholder="جستجو در شبکه..." 
                className="w-full pr-12 pl-4 py-4 bg-slate-100 dark:bg-slate-800 border-none rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-primary-500/10 transition-all shadow-inner text-right"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
              <Search size={20} className="absolute right-4 top-4 text-slate-400 group-focus-within:text-primary-500 transition-colors" />
            </div>
         </div>
         
         <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
            <div className="space-y-1">
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-3 mt-4 flex items-center gap-2 justify-end">گروه‌های آموزشی <GroupsIcon size={12}/></p>
                {groups.filter(g => g.name.includes(searchTerm)).map(group => (
                    <motion.div layout key={group.id} onClick={() => { setSelectedChatId(group.id); setIsGroupChat(true); setMobileShowChat(true); }} 
                      className={`p-4 flex items-center gap-4 cursor-pointer rounded-[1.8rem] transition-all relative overflow-hidden group ${selectedChatId === group.id ? 'bg-primary-600 text-white shadow-xl' : 'hover:bg-white dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'}`}>
                        <div className="flex-1 min-w-0 text-right">
                            <h3 className="text-[15px] font-black truncate">{group.name}</h3>
                            <p className="text-[10px] font-bold opacity-60">{group.memberIds.length} عضو</p>
                        </div>
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner ${selectedChatId === group.id ? 'bg-white/20' : 'bg-amber-100 text-amber-600'}`}>
                            <GroupsIcon size={28} />
                        </div>
                    </motion.div>
                ))}
            </div>

            <div className="space-y-1 pt-4">
                <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-3 flex items-center gap-2 justify-end">گفتگوهای اخیر <MessageCircle size={12}/></p>
                {activeUsers.filter(u => u.name.includes(searchTerm)).map(user => {
                    const online = isOnline(user.id);
                    return (
                        <motion.div layout key={user.id} onClick={() => { setSelectedChatId(user.id); setIsGroupChat(false); setMobileShowChat(true); }} 
                          className={`p-4 flex items-center gap-4 cursor-pointer rounded-[1.8rem] transition-all relative overflow-hidden group ${selectedChatId === user.id && !isGroupChat ? 'bg-primary-600 text-white shadow-xl' : 'hover:bg-white dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'}`}>
                            <div className="flex-1 min-w-0 text-right">
                                <h3 className="text-[15px] font-black truncate">{user.name}</h3>
                                <p className="text-[10px] font-bold opacity-60 uppercase tracking-tighter">{user.role}</p>
                            </div>
                            <div className="relative shrink-0">
                                <div className="w-14 h-14 rounded-2xl bg-slate-200 dark:bg-slate-700 flex items-center justify-center overflow-hidden border-2 border-white dark:border-slate-800">
                                    {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <span className="font-black text-xl text-slate-500">{user.name.charAt(0)}</span>}
                                </div>
                                <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-800 ${online ? 'bg-emerald-500 shadow-sm shadow-emerald-500/50' : 'bg-slate-400'}`} />
                            </div>
                        </motion.div>
                    );
                })}
            </div>
         </div>
      </div>

      {/* Chat Area */}
      <div className={`flex-1 flex flex-col bg-white dark:bg-slate-900 absolute inset-0 md:relative transition-transform duration-300 z-20 ${mobileShowChat ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
         {selectedTarget ? (
           <>
              <div className="p-6 border-b dark:border-slate-800 flex justify-between items-center bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl">
                 <div className="flex items-center gap-4">
                    <button onClick={() => setMobileShowChat(false)} className="md:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors"><ArrowRight size={24} className="rotate-180" /></button>
                    <div className="text-right">
                        <h3 className="font-black text-lg text-slate-900 dark:text-white leading-none">{selectedTarget.name}</h3>
                        <div className="flex items-center gap-1.5 mt-1.5 justify-end">
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-black uppercase tracking-widest">
                                {isGroupChat ? `${(selectedTarget as ChatGroup).memberIds.length} عضو` : isOnline(selectedTarget.id) ? 'آنلاین' : 'آفلاین'}
                            </p>
                            <div className={`w-1.5 h-1.5 rounded-full ${(!isGroupChat && isOnline(selectedTarget.id)) ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                        </div>
                    </div>
                    <div className="w-12 h-12 rounded-[1.2rem] bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center font-black overflow-hidden text-indigo-600 shadow-inner border-2 border-white dark:border-slate-800 shrink-0">
                       {isGroupChat ? <GroupsIcon size={24} /> : (selectedTarget as User).avatar ? <img src={(selectedTarget as User).avatar} className="w-full h-full object-cover"/> : selectedTarget.name.charAt(0)}
                    </div>
                 </div>
                 <div className="flex gap-2">
                    <button className="p-3 text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5 rounded-2xl transition-all"><Phone size={20}/></button>
                 </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-[#f8fafc] dark:bg-slate-950/80 custom-scrollbar">
                 {currentConversation.map((msg) => {
                    const isMe = msg.senderId === currentUser.id;
                    const sender = allUsers.find(u => u.id === msg.senderId) || currentUser;
                    return (
                       <motion.div key={msg.id} initial={{ opacity: 0, y: 10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} className={`flex ${isMe ? 'justify-start' : 'justify-end'}`}>
                          <div className={`flex flex-col gap-2 max-w-[85%] sm:max-w-[70%] ${isMe ? 'items-start' : 'items-end'}`}>
                             {!isMe && isGroupChat && <span className="text-[10px] font-black text-slate-400 mr-2 flex items-center gap-1 justify-end">{sender.name} <UserIcon size={10}/></span>}
                             
                             <div className={`rounded-[2rem] p-5 shadow-sm relative group text-right ${isMe ? 'bg-primary-600 text-white rounded-tr-none' : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-100 dark:border-slate-700 shadow-xl shadow-slate-200/20'}`}>
                                {msg.attachmentUrl && (
                                    <div className="mb-4 rounded-2xl overflow-hidden border-2 border-black/5 dark:border-white/5">
                                        {msg.attachmentType === 'image' ? (
                                            <img src={msg.attachmentUrl} className="max-w-full rounded-xl cursor-pointer" alt="Attachment" onClick={() => window.open(msg.attachmentUrl, '_blank')} />
                                        ) : (
                                            <div className="p-4 bg-slate-50 dark:bg-slate-900 flex items-center gap-4 text-right" dir="rtl">
                                                <div className="w-12 h-12 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center text-primary-600 shadow-md">
                                                    {msg.attachmentType === 'pdf' ? <FileText size={24} /> : <Paperclip size={24} />}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <p className="text-xs font-black truncate text-slate-800 dark:text-white">{msg.attachmentName}</p>
                                                    <p className="text-[9px] text-slate-400 font-bold uppercase mt-0.5">{msg.attachmentType}</p>
                                                </div>
                                                <a href={msg.attachmentUrl} download className="p-2 text-slate-400 hover:text-primary-600">
                                                    <Download size={18} />
                                                </a>
                                            </div>
                                        )}
                                    </div>
                                )}
                                <p className="text-sm leading-relaxed font-medium whitespace-pre-wrap">{msg.text}</p>
                                <div className="flex items-center justify-end gap-1 text-[9px] mt-2 opacity-50 font-mono">
                                   <span>{new Date(msg.createdAt).toLocaleTimeString('fa-IR', {hour:'2-digit', minute:'2-digit'})}</span>
                                   {isMe && (
                                     msg.isRead ? <CheckCheck size={14} className="text-white" /> : <Check size={14} />
                                   )}
                                </div>
                             </div>
                          </div>
                       </motion.div>
                    );
                 })}
                 <div ref={messagesEndRef} />
              </div>

              <div className="p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
                 <form onSubmit={handleSendMessage} className="flex gap-3 items-center">
                    <button type="submit" disabled={isUploading || (!inputText.trim() && !pendingFile)} 
                        className="bg-primary-600 hover:bg-primary-700 text-white w-14 h-14 flex items-center justify-center rounded-[1.5rem] disabled:opacity-50 shadow-xl transition-all hover:scale-105 active:scale-95 shrink-0"
                    >
                        {isUploading ? <Loader2 className="animate-spin" size={24} /> : <Send size={24} className="rotate-180" />}
                    </button>

                    <div className="flex-1">
                        <textarea 
                            value={inputText} 
                            onChange={(e) => setInputText(e.target.value)} 
                            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
                            placeholder="پیام خود را بنویسید..." 
                            className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-[1.5rem] px-6 py-4 outline-none font-bold text-slate-900 dark:text-white shadow-inner resize-none max-h-32 min-h-[56px] focus:ring-2 focus:ring-primary-500/20 text-right dir-rtl"
                            rows={1}
                        />
                    </div>

                    <button type="button" onClick={() => fileInputRef.current?.click()} className="p-4 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-[1.5rem] transition-all shadow-sm shrink-0">
                        <Paperclip size={24} />
                    </button>
                    <input type="file" ref={fileInputRef} className="hidden" onChange={e => {
                      const file = e.target.files?.[0];
                      if (file) setPendingFile(file);
                    }} />
                 </form>
              </div>
           </>
         ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center p-12 bg-slate-50 dark:bg-slate-950/40">
               <div className="w-32 h-32 bg-white dark:bg-slate-900 rounded-[3.5rem] shadow-2xl flex items-center justify-center mb-8 border border-slate-100 dark:border-slate-800 opacity-20">
                  <UserIcon size={64} />
               </div>
               <h3 className="text-3xl font-black mb-4 text-slate-900 dark:text-white tracking-tighter uppercase">مرکز ارتباطات سازمانی</h3>
               <p className="max-w-md font-bold text-slate-500 dark:text-slate-400 text-lg leading-relaxed italic">جهت آغاز یک گفتگوی امن در بستر شبکه داخلی سازمان، یکی از مخاطبین را از پنل سمت راست انتخاب کنید.</p>
            </div>
         )}
      </div>
    </div>
  );
};

export default Messenger;