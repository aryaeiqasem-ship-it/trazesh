
import React, { useState, useMemo, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { gamificationService } from '../services/gamificationService';
import { 
  Search, Filter, Mail, UserX, ChevronDown, Download, UserCircle, 
  Eye, Users, GraduationCap, Bookmark, Layers, FileSpreadsheet,
  Plus, Award, Zap, ShieldCheck, Check, Info, Star, Save, Trash2,
  Grid, List, MoreVertical
} from 'lucide-react';
import { UserRole, User, Major, Grade, Badge } from '../types';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from '../components/ConfirmationModal';
import Modal from '../components/Modal';
import { motion, AnimatePresence } from 'framer-motion';

interface TeacherStudentsProps {
  onNavigate: (view: string, data?: any) => void;
}

const TeacherStudents: React.FC<TeacherStudentsProps> = ({ onNavigate }) => {
  const [users, setUsers] = useState<User[]>(() => storageService.getUsers());
  const [majors, setMajors] = useState<Major[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState('ALL');
  const [selectedMajor, setSelectedMajor] = useState('ALL');
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  const [expelTarget, setExpelTarget] = useState<User | null>(null);
  const [isIpcModalOpen, setIsIpcModalOpen] = useState(false);
  const [isBadgeModalOpen, setIsBadgeModalOpen] = useState(false);
  const [targetStudent, setTargetStudent] = useState<User | null>(null);

  const [ipcAmount, setIpcAmount] = useState(10);
  const [ipcReason, setIpcReason] = useState('مشارکت فعال در مباحث کلاس');
  const [badgeTitle, setBadgeTitle] = useState('هنرجوی نمونه هفته');
  const [badgeDesc, setBadgeDesc] = useState('به دلیل انضباط تحصیلی و پاسخگویی دقیق به سوالات');
  const [badgeType, setBadgeType] = useState<Badge['type']>('gold');

  const toast = useToast();

  useEffect(() => {
    setMajors(storageService.getMajors());
    setGrades(storageService.getGrades());
  }, []);

  const allStudents = useMemo(() => users.filter(u => u.role === UserRole.STUDENT), [users]);
  const uniqueClasses = useMemo(() => [...new Set(allStudents.map(s => s.class).filter(Boolean))].sort(), [allStudents]);

  const filteredStudents = useMemo(() => {
    return allStudents.filter(s => {
      const matchesSearch = s.name.includes(searchTerm) || (s.studentId && s.studentId.includes(searchTerm));
      const matchesClass = selectedClass === 'ALL' || s.class === selectedClass;
      const matchesMajor = selectedMajor === 'ALL' || s.major === selectedMajor;
      const matchesGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
      return matchesSearch && matchesClass && matchesMajor && matchesGrade;
    });
  }, [allStudents, searchTerm, selectedClass, selectedMajor, selectedGrade]);

  const handleAddIPC = () => {
    if (!targetStudent) return;
    gamificationService.awardIPC(targetStudent.id, ipcAmount, ipcReason);
    toast.success(`تعداد ${ipcAmount} امتیاز IPC به ${targetStudent.name} اعطا شد.`);
    setIsIpcModalOpen(false);
    setUsers(storageService.getUsers());
  };

  const handleGrantBadge = () => {
    if (!targetStudent) return;
    gamificationService.grantBadge(targetStudent.id, badgeTitle, badgeDesc, badgeType);
    toast.success(`نشان "${badgeTitle}" با موفقیت به ${targetStudent.name} اعطا شد.`);
    setIsBadgeModalOpen(false);
    setUsers(storageService.getUsers());
  };

  const confirmExpel = () => {
    if (!expelTarget) return;
    const updatedUsers = users.map(u => u.id === expelTarget.id ? { ...u, class: '' } : u);
    setUsers(updatedUsers);
    storageService.saveUsers(updatedUsers);
    setExpelTarget(null);
    toast.success(`${expelTarget.name} از لیست کلاس خارج شد.`);
  };

  const handleExportExcel = () => {
    toast.info('در حال تولید فایل گزارش...');
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-3">
             <Users className="text-primary-600" size={32} />
             مدیریت و پایش دانش‌آموزان
          </h1>
          <p className="text-sm text-slate-500 font-bold mt-1">دسترسی به اطلاعات تحصیلی و اعطای جوایز بازی‌سازی</p>
        </div>
        <div className="flex gap-2">
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700 ml-2">
                <button onClick={() => setViewMode('grid')} className={`p-3 rounded-xl transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-slate-700 shadow-md text-primary-600' : 'text-slate-400'}`}><Grid size={20}/></button>
                <button onClick={() => setViewMode('list')} className={`p-3 rounded-xl transition-all ${viewMode === 'list' ? 'bg-white dark:bg-slate-700 shadow-md text-primary-600' : 'text-slate-400'}`}><List size={20}/></button>
            </div>
            <button onClick={handleExportExcel} className="px-8 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl flex items-center gap-3 text-sm font-black shadow-2xl transition-all hover:scale-105 active:scale-95">
              <FileSpreadsheet size={20} /> خروجی Excel
            </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative">
          <input type="text" placeholder="جستجوی نام یا کد..." className="w-full pl-4 pr-11 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-xs focus:ring-2 focus:ring-primary-500/20 text-slate-900 dark:text-white" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          <Search className="absolute right-4 top-4.5 text-slate-400" size={18} />
        </div>
        <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-4 rounded-2xl border border-transparent">
           <Bookmark size={16} className="text-slate-400" />
           <select value={selectedMajor} onChange={(e) => setSelectedMajor(e.target.value)} className="w-full py-4 bg-transparent border-none font-black text-xs outline-none cursor-pointer text-slate-900 dark:text-white">
              <option value="ALL">همه رشته‌ها</option>
              {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
           </select>
        </div>
        <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-4 rounded-2xl border border-transparent">
           <GraduationCap size={16} className="text-slate-400" />
           <select value={selectedGrade} onChange={(e) => setSelectedGrade(e.target.value)} className="w-full py-4 bg-transparent border-none font-black text-xs outline-none cursor-pointer text-slate-900 dark:text-white">
              <option value="ALL">همه پایه‌ها</option>
              {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
           </select>
        </div>
        <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-4 rounded-2xl border border-transparent">
           <Layers size={16} className="text-slate-400" />
           <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} className="w-full py-4 bg-transparent border-none font-black text-xs outline-none cursor-pointer text-slate-900 dark:text-white">
              <option value="ALL">همه کلاس‌ها</option>
              {uniqueClasses.map(c => <option key={c} value={c}>{c}</option>)}
           </select>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {viewMode === 'grid' ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStudents.map(student => (
                <div key={student.id} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm group hover:shadow-3xl transition-all">
                    <div className="flex items-center gap-5 mb-8">
                        <div className="w-20 h-20 rounded-[1.5rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-2xl text-slate-500 overflow-hidden border-4 border-white dark:border-slate-700 shadow-lg">
                            {student.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : student.name.charAt(0)}
                        </div>
                        <div>
                            <h3 className="font-black text-xl text-slate-800 dark:text-slate-100 leading-tight">{student.name}</h3>
                            <p className="text-[10px] text-slate-400 font-mono font-bold tracking-widest mt-1 uppercase">ID: {student.studentId}</p>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mb-6">
                        <div className="bg-emerald-50 dark:bg-emerald-900/10 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-800">
                            <p className="text-[8px] font-black text-slate-400 uppercase mb-1">XP Points</p>
                            <p className="text-xl font-black text-emerald-600">{student.gamification?.xp || 0}</p>
                        </div>
                        <div className="bg-primary-50 dark:bg-primary-900/10 p-4 rounded-2xl border border-primary-100 dark:border-primary-800">
                            <p className="text-[8px] font-black text-slate-400 uppercase mb-1">IPC Score</p>
                            <p className="text-xl font-black text-primary-600">{student.gamification?.ipc || 0}</p>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-8">
                        <button onClick={() => { setTargetStudent(student); setIsIpcModalOpen(true); }} className="flex-1 py-3 bg-primary-50 dark:bg-primary-900/30 text-primary-600 rounded-xl font-black text-[10px] flex items-center justify-center gap-1.5 hover:bg-primary-600 hover:text-white transition-all">
                            <Zap size={14}/> اعطای IPC
                        </button>
                        <button onClick={() => { setTargetStudent(student); setIsBadgeModalOpen(true); }} className="flex-1 py-3 bg-amber-50 dark:bg-amber-900/30 text-amber-600 rounded-xl font-black text-[10px] flex items-center justify-center gap-1.5 hover:bg-amber-600 hover:text-white transition-all">
                            <Award size={14}/> اعطای نشان
                        </button>
                    </div>
                    <div className="flex gap-2 pt-4 border-t border-slate-50 dark:border-slate-800">
                        <button onClick={() => onNavigate('messenger', student.id)} className="flex-1 py-4 bg-indigo-50 dark:bg-indigo-900/30 hover:bg-indigo-600 text-indigo-700 hover:text-white rounded-2xl transition-all flex items-center justify-center gap-2 font-black text-xs shadow-sm">
                            <Mail size={16} /> پیام
                        </button>
                        <button onClick={() => setExpelTarget(student)} className="p-4 bg-rose-50 dark:bg-rose-900/30 hover:bg-rose-500 text-rose-500 hover:text-white rounded-2xl transition-all">
                            <UserX size={18} />
                        </button>
                    </div>
                </div>
            ))}
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
             <table className="w-full text-right">
                <thead>
                   <tr className="bg-slate-50 dark:bg-slate-800 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                      <th className="px-8 py-5">نام هنرجو</th>
                      <th className="px-8 py-5 text-center">کد شناسایی</th>
                      <th className="px-8 py-5 text-center">کلاس / پایه</th>
                      <th className="px-8 py-5 text-center">امتیازات</th>
                      <th className="px-8 py-5 text-center">عملیات مدیریت</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                   {filteredStudents.map(student => (
                      <tr key={student.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors group">
                         <td className="px-8 py-4">
                            <div className="flex items-center gap-3">
                               <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-slate-500 overflow-hidden border shadow-sm">
                                  {student.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : student.name.charAt(0)}
                               </div>
                               <span className="font-black text-sm text-slate-800 dark:text-slate-100">{student.name}</span>
                            </div>
                         </td>
                         <td className="px-8 py-4 text-center font-mono text-xs text-slate-500">{student.studentId}</td>
                         <td className="px-8 py-4 text-center">
                            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400">{student.class} | پایه {student.grade}</span>
                         </td>
                         <td className="px-8 py-4 text-center">
                            <div className="flex items-center justify-center gap-3">
                               <div className="flex items-center gap-1 text-emerald-600"><Zap size={12}/> <span className="text-xs font-black">{student.gamification?.xp}</span></div>
                               <div className="flex items-center gap-1 text-primary-600"><Star size={12}/> <span className="text-xs font-black">{student.gamification?.ipc}</span></div>
                            </div>
                         </td>
                         <td className="px-8 py-4">
                            <div className="flex justify-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                               <button onClick={() => { setTargetStudent(student); setIsIpcModalOpen(true); }} className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg" title="اعطای IPC"><Zap size={16}/></button>
                               <button onClick={() => onNavigate('messenger', student.id)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg" title="ارسال پیام"><Mail size={16}/></button>
                               <button onClick={() => setExpelTarget(student)} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg" title="حذف از کلاس"><UserX size={16}/></button>
                            </div>
                         </td>
                      </tr>
                   ))}
                </tbody>
             </table>
          </motion.div>
        )}
      </AnimatePresence>

      {/* IPC and Badge Modals same as before */}
      <Modal isOpen={isIpcModalOpen} onClose={() => setIsIpcModalOpen(false)} title={`اعطای امتیاز IPC به ${targetStudent?.name}`} maxWidth="max-w-md">
         <div className="p-8 space-y-6">
            <div className="bg-primary-50 p-6 rounded-[2rem] border border-primary-100 flex items-center gap-4">
               <Zap className="text-primary-600" size={32} />
               <p className="text-sm font-bold text-primary-900 leading-relaxed">امتیاز IPC شاخص مشارکت فعال دانش‌آموز است.</p>
            </div>
            <div className="space-y-4">
               <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 mr-2">تعداد امتیاز</label>
                  <input type="number" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-black text-center text-3xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={ipcAmount} onChange={e => setIpcAmount(parseInt(e.target.value))} />
               </div>
               <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 mr-2">علت اعطای امتیاز</label>
                  <textarea className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-bold text-sm outline-none focus:ring-2 focus:ring-primary-500 h-24 text-slate-900 dark:text-white" value={ipcReason} onChange={e => setIpcReason(e.target.value)} />
               </div>
            </div>
            <button onClick={handleAddIPC} className="w-full py-4 bg-primary-600 text-white font-black rounded-2xl shadow-xl flex items-center justify-center gap-2 hover:bg-primary-700 transition-all">
               <Check size={20} /> ثبت امتیاز IPC
            </button>
         </div>
      </Modal>

      <Modal isOpen={isBadgeModalOpen} onClose={() => setIsBadgeModalOpen(false)} title={`اعطای نشان افتخار به ${targetStudent?.name}`} maxWidth="max-w-md">
         <div className="p-8 space-y-6">
            <div className="flex flex-col items-center gap-4 mb-8">
               <div className={`w-20 h-20 rounded-[1.5rem] flex items-center justify-center shadow-xl border-4 border-white ${badgeType === 'gold' ? 'bg-amber-400' : badgeType === 'silver' ? 'bg-slate-300' : 'bg-orange-600'}`}>
                  <Star size={40} className="text-white" fill="currentColor" />
               </div>
               <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                  {['gold', 'silver', 'bronze', 'platinum'].map((t: any) => (
                     <button key={t} onClick={() => setBadgeType(t)} className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${badgeType === t ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400'}`}>{t}</button>
                  ))}
               </div>
            </div>
            <div className="space-y-4">
               <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 mr-2">عنوان نشان</label>
                  <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={badgeTitle} onChange={e => setBadgeTitle(e.target.value)} />
               </div>
               <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 mr-2">توضیحات</label>
                  <textarea className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-bold text-sm outline-none focus:ring-2 focus:ring-primary-500 h-24 text-slate-900 dark:text-white" value={badgeDesc} onChange={e => setBadgeDesc(e.target.value)} />
               </div>
            </div>
            <button onClick={handleGrantBadge} className="w-full py-4 bg-amber-500 text-white font-black rounded-2xl shadow-xl flex items-center justify-center gap-2 hover:bg-amber-600 transition-all">
               <Save size={20} /> اعطای نشان افتخار
            </button>
         </div>
      </Modal>

      <ConfirmationModal isOpen={!!expelTarget} onClose={() => setExpelTarget(null)} onConfirm={confirmExpel} title="تغییر وضعیت کلاسی" description={`آیا مطمئن هستید که می‌خواهید "${expelTarget?.name}" را از این کلاس خارج کنید؟`} confirmText="بله، خارج کن" />
    </div>
  );
};

export default TeacherStudents;
