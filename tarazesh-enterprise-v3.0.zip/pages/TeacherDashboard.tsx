import React, { useMemo, useState, useEffect } from 'react';
import { 
  Plus, Users, MessageSquare, ClipboardList, Bell, 
  Megaphone, Sparkles, BrainCircuit, Users2, ChevronLeft,
  Calendar, Clock, CheckCircle, Image as ImageIcon,
  Zap, BarChart3, Settings2, Target, Send, MoreHorizontal,
  FileText, BookOpen, MessageCircle, UserCheck, ArrowLeft,
  Search, Filter, ListChecks, ShieldAlert, KeyRound, Check, X,
  Coffee, Timer, LayoutPanelLeft
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { User, UserRole, Exam, Assignment, PasswordResetRequest, ClassEntity, ScheduleItem } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';

interface TeacherDashboardProps {
  currentUser: User;
  onNavigate: (view: string, data?: any) => void;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ currentUser, onNavigate }) => {
  const [activeTab, setActiveTab] = useState('announcements');
  const [announcementText, setAnnouncementText] = useState('');
  const [resetRequests, setResetRequests] = useState<PasswordResetRequest[]>([]);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const toast = useToast();

  useEffect(() => {
    setResetRequests(storageService.getPendingResets());
    const interval = setInterval(() => {
        setResetRequests(storageService.getPendingResets());
        setCurrentTime(new Date());
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleApproveReset = (req: PasswordResetRequest) => {
    const newPass = '123456'; 
    storageService.approveReset(req.id, newPass);
    setResetRequests(prev => prev.filter(r => r.id !== req.id));
    toast.success(`رمز عبور ${req.userName} به "123456" تغییر یافت.`);
  };

  const handleNavigateClean = (e: React.MouseEvent, view: string, data?: any) => {
    e.preventDefault();
    e.stopPropagation();
    onNavigate(view, data);
  };

  const results = storageService.getResults();
  const exams = storageService.getExams();
  const assignments = storageService.getAssignments();
  const messages = storageService.getMessages();
  const classes = storageService.getClasses();
  const allUsers = storageService.getUsers();
  const submissions = storageService.getSubmissions();

  const schedule = useMemo(() => {
    const allSchedule = storageService.getSchedule();
    return allSchedule.filter(s => s.teacherName === currentUser.name);
  }, [currentUser.name]);

  const activeScheduleStatus = useMemo(() => {
    const now = currentTime;
    const daysMap: Record<number, string> = {
      0: 'Sunday', 1: 'Monday', 2: 'Tuesday', 3: 'Wednesday', 4: 'Thursday', 5: 'Friday', 6: 'Saturday'
    };
    const todayName = daysMap[now.getDay()];
    const currentMins = now.getHours() * 60 + now.getMinutes();

    const todayClasses = schedule.filter(s => s.day === todayName)
      .map(s => {
        const [sh, sm] = s.startTime.split(':').map(Number);
        const [eh, em] = s.endTime.split(':').map(Number);
        return { ...s, startMins: sh * 60 + sm, endMins: eh * 60 + em };
      })
      .sort((a, b) => a.startMins - b.startMins);

    const ongoing = todayClasses.find(c => currentMins >= c.startMins && currentMins <= c.endMins);
    if (ongoing) return { ...ongoing, statusType: 'ONGOING' as const };

    const next = todayClasses.find(c => currentMins < c.startMins);
    if (next) return { ...next, statusType: 'NEXT' as const };

    return null;
  }, [schedule, currentTime]);

  const classAvg = useMemo(() => {
    if (results.length === 0) return '۱۷.۴';
    const sum = results.reduce((acc, r) => acc + (r.score / r.maxScore * 20), 0);
    return (sum / results.length).toFixed(1);
  }, [results]);

  const tabs = [
    { id: 'announcements', label: 'اعلان‌ها' },
    { id: 'tasks', label: 'تکالیف و آزمون' },
    { id: 'chat', label: 'گفتگو' },
    { id: 'people', label: 'افراد' },
  ];

  const handlePostAnnouncement = () => {
    if (!announcementText.trim()) return;
    toast.success('اطلاعیه جدید با موفقیت برای تمامی هنرجویان ارسال شد.');
    setAnnouncementText('');
  };

  const recentMessages = useMemo(() => {
    return [...messages]
      .filter(m => m.receiverId === currentUser.id)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 8);
  }, [messages, currentUser.id]);

  return (
    <div className="space-y-6 pb-24 font-sans" dir="rtl">
      {/* Improved Header Section with Dynamic Theme */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative h-72 md:h-80 w-full rounded-[3.5rem] overflow-hidden shadow-2xl border border-slate-200 dark:border-white/5"
      >
         <div className={`absolute inset-0 transition-colors duration-1000 ${
            activeScheduleStatus?.statusType === 'ONGOING' 
              ? 'bg-gradient-to-br from-emerald-500 via-emerald-800 to-slate-900' 
              : activeScheduleStatus?.statusType === 'NEXT'
                ? 'bg-gradient-to-br from-primary-500 via-primary-800 to-slate-900'
                : 'bg-gradient-to-br from-slate-700 via-slate-800 to-slate-950'
         }`}></div>
         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 mix-blend-overlay"></div>
         
         {/* Upper Floating Controls */}
         <div className="absolute top-8 left-10 flex gap-3 z-20">
            <button 
              onClick={(e) => handleNavigateClean(e, 'teacher_classes')}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-xl px-5 py-3 rounded-2xl text-white text-xs font-black transition-all border border-white/20 shadow-xl flex items-center gap-2 group"
            >
               <ListChecks size={18} className="group-hover:scale-110 transition-transform" />
               لیست حضور
            </button>
            <button 
              onClick={(e) => handleNavigateClean(e, 'teacher_schedule')}
              className="p-3 bg-white/10 hover:bg-white/20 backdrop-blur-xl rounded-2xl text-white transition-all border border-white/20 shadow-xl"
            >
               <Calendar size={20} />
            </button>
         </div>

         {/* Hero Title Area */}
         <div className="absolute inset-0 flex flex-col justify-end p-10 md:p-14 z-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-4">
                    <div className="flex gap-3">
                        <AnimatePresence mode="wait">
                            {activeScheduleStatus?.statusType === 'ONGOING' ? (
                                <motion.div key="ongoing" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-emerald-400 text-slate-900 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg">
                                    <div className="w-1.5 h-1.5 rounded-full bg-slate-900 animate-ping"></div>
                                    کلاس در حال برگزاری
                                </motion.div>
                            ) : activeScheduleStatus?.statusType === 'NEXT' ? (
                                <motion.div key="next" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-primary-400 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                                    <Timer size={14} /> کلاس بعدی
                                </motion.div>
                            ) : null}
                        </AnimatePresence>
                        <div className="bg-white/10 backdrop-blur-md px-4 py-1.5 rounded-full text-[10px] font-black text-white/80 border border-white/10">
                            {currentTime.toLocaleTimeString('fa-IR', {hour: '2-digit', minute: '2-digit'})}
                        </div>
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black text-white tracking-tighter drop-shadow-2xl">
                        {activeScheduleStatus ? activeScheduleStatus.courseTitle : 'میز کار مدرس'}
                    </h1>
                </div>

                {activeScheduleStatus && (
                    <div className="bg-white/10 backdrop-blur-2xl p-6 rounded-[2.5rem] border border-white/10 shadow-2xl flex flex-col items-center md:items-start min-w-[200px]">
                        <p className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em] mb-2">زمان‌بندی جلسه</p>
                        <div className="flex items-center gap-3 text-white">
                            <Clock size={24} className="text-primary-300" />
                            <span className="text-2xl font-black font-mono tracking-tighter">{activeScheduleStatus.startTime} - {activeScheduleStatus.endTime}</span>
                        </div>
                    </div>
                )}
            </div>
         </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 space-y-8">
          <div className="flex justify-start border-b border-slate-200 dark:border-slate-800 px-2 overflow-x-auto no-scrollbar scroll-smooth">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-8 py-5 text-sm font-black transition-all relative whitespace-nowrap ${
                  activeTab === tab.id 
                    ? 'text-primary-600' 
                    : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
                }`}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div 
                    layoutId="teacherNavActive"
                    className="absolute bottom-0 left-0 right-0 h-1 bg-primary-600 rounded-t-full shadow-[0_-4px_10px_rgba(14,165,233,0.3)]"
                  />
                )}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'announcements' && (
              <motion.div 
                key="ann" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="bg-white dark:bg-slate-900 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-[2.5rem] p-6 shadow-sm flex items-center gap-6 group transition-all hover:border-primary-400/50">
                   <div className="w-14 h-14 rounded-2xl bg-primary-50 dark:bg-primary-900/30 text-primary-600 flex items-center justify-center shrink-0 transition-all group-hover:scale-110 shadow-inner">
                      <Megaphone size={28} />
                   </div>
                   <div className="flex-1 flex gap-3">
                      <input 
                        type="text" 
                        placeholder="ارسال اطلاعیه جدید برای هنرجویان..." 
                        value={announcementText}
                        onChange={(e) => setAnnouncementText(e.target.value)}
                        className="flex-1 bg-transparent border-none outline-none font-bold text-sm text-slate-700 dark:text-slate-300"
                        onKeyPress={(e) => e.key === 'Enter' && handlePostAnnouncement()}
                      />
                      <button 
                        onClick={handlePostAnnouncement}
                        className="p-3 bg-primary-600 text-white rounded-xl shadow-lg hover:scale-110 active:scale-90 transition-all"
                      >
                         <Send size={18} />
                      </button>
                   </div>
                </div>

                <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[3rem] p-10 shadow-sm space-y-10 relative overflow-hidden group">
                   <div className="absolute top-0 right-0 w-2 h-full bg-primary-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                   <div className="flex justify-between items-start">
                      <div className="flex items-center gap-5">
                         <div className="w-16 h-16 rounded-[1.5rem] border-4 border-white dark:border-slate-700 shadow-2xl overflow-hidden bg-slate-100">
                            <img src={currentUser.avatar || "https://api.dicebear.com/7.x/avataaars/svg?seed=Sara"} alt="Teacher" className="w-full h-full object-cover" />
                         </div>
                         <div>
                            <h4 className="font-black text-slate-800 dark:text-white text-xl">{currentUser.name}</h4>
                            <p className="text-[10px] font-black text-primary-500 uppercase tracking-[0.2em] mt-1">مدرس ارشد دپارتمان تخصصی</p>
                         </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className="text-[10px] font-black text-slate-300 font-mono tracking-widest uppercase">بروزرسانی زنده</span>
                        <button className="text-slate-300 hover:text-slate-600 transition-colors"><MoreHorizontal size={20}/></button>
                      </div>
                   </div>
                   <div className="pr-20">
                      <p className="text-slate-600 dark:text-slate-300 font-bold leading-relaxed text-lg italic">
                        « به ترم جدید خوش آمدید! لطفا سرفصل دروس بارگذاری شده در بخش منابع را با دقت بررسی کنید. اولین آزمون کلاسی هفته آینده برگزار خواهد شد. »
                      </p>
                   </div>
                   <div className="pt-8 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center">
                      <button className="flex items-center gap-3 bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-8 py-4 rounded-2xl text-xs font-black transition-all hover:bg-purple-100 hover:scale-105 shadow-sm">
                         <Sparkles size={18} className="animate-pulse" />
                         خلاصه‌سازی هوشمند با هوش مصنوعی
                      </button>
                      <div className="flex -space-x-2 space-x-reverse">
                         {[1,2,3,4].map(i => (
                           <div key={i} className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-800 bg-slate-200"></div>
                         ))}
                         <div className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-800 bg-slate-100 flex items-center justify-center text-[8px] font-black text-slate-400">+۱۲</div>
                      </div>
                   </div>
                </div>
              </motion.div>
            )}

            {/* --- Other Tabs omitted for brevity as they remain mostly the same --- */}
            {activeTab === 'tasks' && (
              <motion.div 
                key="tasks" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="bg-white dark:bg-slate-900 p-8 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm space-y-8 flex flex-col h-full">
                      <div className="flex justify-between items-center">
                         <h3 className="font-black text-xl flex items-center gap-3"><BookOpen size={24} className="text-primary-600"/> آخرین آزمون‌ها</h3>
                         <button onClick={(e) => handleNavigateClean(e, 'teacher_exams')} className="p-3 bg-primary-50 dark:bg-primary-900/30 text-primary-600 rounded-2xl hover:scale-110 transition-all border border-primary-100"><Plus size={18}/></button>
                      </div>
                      <div className="space-y-4 flex-1">
                         {exams.slice(0, 4).map(exam => {
                           const takersCount = results.filter(r => r.examId === exam.id).length;
                           return (
                             <div 
                                key={exam.id} 
                                className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border-2 border-transparent hover:border-primary-100 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group" 
                                onClick={(e) => handleNavigateClean(e, 'teacher_grading', exam.id)}
                             >
                                <div className="flex justify-between items-start">
                                   <div className="space-y-1">
                                      <p className="font-black text-sm text-slate-800 dark:text-white truncate max-w-[200px]">{exam.title}</p>
                                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{exam.forClass} • {exam.questions.length} سوال</p>
                                   </div>
                                   <ChevronLeft size={16} className="text-slate-300 group-hover:text-primary-500 transition-all" />
                                </div>
                                <div className="mt-4 flex items-center justify-between">
                                   <div className="flex items-center gap-2">
                                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                                      <span className="text-[9px] font-black text-slate-500 uppercase">{takersCount} هنرجو شرکت کرده‌اند</span>
                                   </div>
                                   <span className="text-[9px] font-black text-primary-600 bg-primary-50 px-2 py-0.5 rounded-lg border border-primary-100 uppercase">فعال</span>
                                </div>
                             </div>
                           )
                         })}
                      </div>
                      <button onClick={(e) => handleNavigateClean(e, 'teacher_exams')} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 hover:text-white transition-all">مشاهده بانک آزمون</button>
                   </div>

                   <div className="bg-white dark:bg-slate-900 p-8 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm space-y-8 flex flex-col h-full">
                      <div className="flex justify-between items-center">
                         <h3 className="font-black text-xl flex items-center gap-3"><FileText size={24} className="text-indigo-600"/> تکالیف در جریان</h3>
                         <button onClick={(e) => handleNavigateClean(e, 'teacher_assignments')} className="p-3 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-2xl hover:scale-110 transition-all border border-indigo-100"><Plus size={18}/></button>
                      </div>
                      <div className="space-y-4 flex-1">
                         {assignments.length === 0 ? (
                           <div className="h-full flex flex-col items-center justify-center opacity-30 gap-3">
                              <FileText size={48} />
                              <p className="text-xs font-black">تکلیفی تعریف نشده است.</p>
                           </div>
                         ) : assignments.slice(0, 4).map(asg => {
                           const subCount = submissions.filter(s => s.assignmentId === asg.id).length;
                           return (
                             <div 
                                key={asg.id} 
                                className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border-2 border-transparent hover:border-indigo-100 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group" 
                                onClick={(e) => handleNavigateClean(e, 'teacher_assignments')}
                             >
                                <div className="flex justify-between items-start">
                                   <div className="space-y-1">
                                      <p className="font-black text-sm text-slate-800 dark:text-white truncate max-w-[200px]">{asg.title}</p>
                                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">مهلت: {new Date(asg.dueDate).toLocaleDateString('fa-IR')}</p>
                                   </div>
                                   <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-black text-indigo-600">{subCount} پاسخ</span>
                                      <ChevronLeft size={16} className="text-slate-300 group-hover:text-indigo-500 transition-all" />
                                   </div>
                                </div>
                                <div className="mt-4 w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                   <div className="h-full bg-indigo-500 w-[65%] rounded-full shadow-[0_0_8px_rgba(99,102,241,0.4)]"></div>
                                </div>
                             </div>
                           )
                         })}
                      </div>
                      <button onClick={(e) => handleNavigateClean(e, 'teacher_assignments')} className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all">لیست جامع تکالیف</button>
                   </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'chat' && (
              <motion.div 
                key="chat" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }}
                className="bg-white dark:bg-slate-900 p-10 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm space-y-10"
              >
                <div className="flex justify-between items-center">
                   <div className="space-y-1">
                      <h3 className="font-black text-2xl flex items-center gap-3"><MessageCircle size={28} className="text-primary-500"/> پیام‌های دریافتی اخیر</h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">پاسخگویی سریع به سوالات هنرجویان</p>
                   </div>
                   <button onClick={(e) => handleNavigateClean(e, 'messenger')} className="text-[10px] font-black text-primary-600 bg-primary-50 border border-primary-100 px-6 py-3 rounded-2xl hover:bg-primary-600 hover:text-white transition-all shadow-sm">ورود به پنل پیام‌رسان</button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                   {recentMessages.length === 0 ? (
                      <div className="text-center py-28 opacity-30 flex flex-col items-center gap-4">
                         <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center"><MessageSquare size={48} /></div>
                         <p className="font-black text-xl">پیام جدیدی در صندوق ورودی وجود ندارد.</p>
                      </div>
                   ) : recentMessages.map(msg => {
                      const sender = allUsers.find(u => u.id === msg.senderId);
                      return (
                        <div 
                           key={msg.id} 
                           className="flex items-center gap-6 p-5 hover:bg-slate-50 dark:hover:bg-slate-800/80 rounded-[2.5rem] transition-all cursor-pointer border-2 border-transparent hover:border-slate-100 dark:hover:border-slate-700 group" 
                           onClick={(e) => handleNavigateClean(e, 'messenger', msg.senderId)}
                        >
                           <div className="relative">
                              <div className="w-14 h-14 rounded-[1.2rem] bg-slate-200 overflow-hidden shadow-sm shrink-0 border-2 border-white dark:border-slate-700 group-hover:scale-110 transition-transform">
                                 {sender?.avatar ? <img src={sender.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center font-black text-slate-500 text-xl">{sender?.name.charAt(0)}</div>}
                              </div>
                              {!msg.isRead && <div className="absolute -top-1 -right-1 w-4 h-4 bg-primary-500 rounded-full border-2 border-white dark:border-slate-900 shadow-[0_0_10px_#0ea5e9] animate-pulse"></div>}
                           </div>
                           <div className="flex-1 min-w-0 text-right">
                              <div className="flex justify-between items-baseline mb-1">
                                 <h4 className="font-black text-slate-800 dark:text-white text-lg truncate group-hover:text-primary-600 transition-colors">{sender?.name}</h4>
                                 <span className="text-[9px] font-black text-slate-300 font-mono tracking-widest">{new Date(msg.createdAt).toLocaleTimeString('fa-IR', {hour:'2-digit', minute:'2-digit'})}</span>
                              </div>
                              <p className={`text-xs truncate max-w-[500px] leading-relaxed ${!msg.isRead ? 'text-slate-800 dark:text-white font-black' : 'text-slate-500 font-bold'}`}>
                                 {msg.text}
                              </p>
                           </div>
                           <ChevronLeft size={20} className="text-slate-200 group-hover:text-primary-500 transition-all opacity-0 group-hover:opacity-100" />
                        </div>
                      )
                   })}
                </div>
              </motion.div>
            )}

            {activeTab === 'people' && (
              <motion.div 
                key="people" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="bg-white dark:bg-slate-900 p-10 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm space-y-10 flex flex-col">
                      <div className="flex justify-between items-center">
                         <div className="space-y-1 text-right">
                            <h3 className="font-black text-2xl flex items-center gap-3"><Users size={28} className="text-emerald-500"/> مدیریت دانش‌آموزان</h3>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">پایش تحصیلی و انضباطی کلاس‌ها</p>
                         </div>
                      </div>
                      <div className="space-y-4 flex-1">
                         {classes.length === 0 ? (
                            <div className="py-20 text-center text-slate-300 italic font-bold">کلاسی تعریف نشده است.</div>
                         ) : classes.slice(0, 5).map(cls => {
                            const studentCount = allUsers.filter(u => u.role === UserRole.STUDENT && u.class === cls.title).length;
                            return (
                              <div 
                                 key={cls.id} 
                                 className="flex justify-between items-center p-5 bg-slate-50 dark:bg-slate-800/50 rounded-[2.5rem] border-2 border-transparent hover:border-emerald-100 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group" 
                                 onClick={(e) => handleNavigateClean(e, 'teacher_students')}
                              >
                                 <div className="flex items-center gap-5">
                                    <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-700 flex items-center justify-center text-emerald-500 shadow-sm group-hover:rotate-12 group-hover:scale-110 transition-all border border-slate-50 dark:border-slate-600"><Users2 size={24}/></div>
                                    <div className="min-w-0 text-right">
                                       <p className="font-black text-base text-slate-800 dark:text-white truncate">{cls.title}</p>
                                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">پایه {cls.grade} • {cls.major}</p>
                                    </div>
                                 </div>
                                 <div className="flex items-center gap-4">
                                    <span className="text-[10px] font-black bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full">{studentCount} هنرجو</span>
                                    <ChevronLeft size={18} className="text-slate-300 group-hover:text-emerald-500 transition-all" />
                                 </div>
                              </div>
                            )
                         })}
                      </div>
                      <button onClick={(e) => handleNavigateClean(e, 'teacher_students')} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-500/20 hover:scale-[1.02] transition-all">لیست جامع و پایش انفرادی</button>
                   </div>

                   <div className="space-y-8">
                      <div className="bg-slate-900 rounded-[3.5rem] p-10 text-white relative overflow-hidden shadow-2xl h-fit">
                         <div className="absolute top-0 right-0 p-8 opacity-10 rotate-12"><UserCheck size={140}/></div>
                         <div className="relative z-10 space-y-10 text-right">
                            <h3 className="font-black text-2xl uppercase tracking-tighter">Quick Connect</h3>
                            <p className="text-sm font-bold text-slate-400 leading-relaxed italic">« دسترسی سریع به پنل مدیریت برای بررسی وضعیت انضباطی یا اعطای نشان‌های افتخار به هنرجویان برتر کلاس. »</p>
                            <div className="grid grid-cols-2 gap-4 pt-4">
                               <div className="p-5 bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 text-center">
                                  <p className="text-3xl font-black text-primary-400">{allUsers.filter(u => u.role === UserRole.STUDENT).length}</p>
                                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-2">کل هنرجویان</p>
                               </div>
                               <div className="p-5 bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 text-center">
                                  <p className="text-3xl font-black text-emerald-400">{classes.length}</p>
                                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-2">کلاس‌های فعال</p>
                               </div>
                            </div>
                            <button onClick={(e) => handleNavigateClean(e, 'teacher_classes')} className="w-full py-4 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl hover:bg-slate-100 transition-all flex items-center justify-center gap-3">
                               <ListChecks size={20} /> مدیریت حضور و غیاب
                            </button>
                         </div>
                      </div>

                      <div className="bg-indigo-600 rounded-[3rem] p-10 text-white flex flex-col md:flex-row items-center gap-8 shadow-xl shadow-indigo-500/20 group cursor-pointer" onClick={(e) => handleNavigateClean(e, 'teacher_reports')}>
                         <div className="w-20 h-20 bg-white/10 backdrop-blur-xl rounded-[2rem] flex items-center justify-center text-white border border-white/20 group-hover:scale-110 transition-transform">
                            <BarChart3 size={40} />
                         </div>
                         <div className="text-right flex-1">
                            <h4 className="font-black text-xl mb-1">گزارشات و کارنامه‌ها</h4>
                            <p className="text-xs text-indigo-100/70 font-bold leading-relaxed">تحلیل آماری عملکرد هر هنرجو و صدور کارنامه ترمیک با تایید هوش مصنوعی.</p>
                         </div>
                         <ArrowLeft size={32} className="opacity-40 group-hover:opacity-100 transition-all" />
                      </div>
                   </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* --- Sidebar Section --- */}
        <div className="lg:col-span-4 space-y-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, y: 0 }}
            className="bg-slate-900 border border-amber-500/20 rounded-[3rem] p-10 shadow-2xl space-y-8 text-white relative overflow-hidden"
          >
             <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none text-right"><KeyRound size={120}/></div>
             <div className="flex justify-between items-center relative z-10">
                <div className="space-y-1 text-right">
                   <h3 className="font-black text-xl tracking-tighter uppercase text-amber-400 flex items-center gap-2">
                      <ShieldAlert size={20} /> Security Node
                   </h3>
                   <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Password Recovery Hub</span>
                </div>
                {resetRequests.length > 0 && (
                   <span className="flex h-3 w-3 rounded-full bg-rose-500 animate-ping"></span>
                )}
             </div>

             <div className="space-y-4 relative z-10">
                {resetRequests.length === 0 ? (
                   <div className="py-6 text-center bg-white/5 rounded-2xl border border-white/5">
                      <CheckCircle className="mx-auto text-emerald-500 mb-3" size={32} />
                      <p className="text-xs font-bold text-slate-400">تمامی درخواست‌ها تایید شدند.</p>
                   </div>
                ) : (
                   <div className="space-y-3">
                      {resetRequests.slice(0, 3).map(req => (
                         <div key={req.id} className="p-4 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-between group hover:bg-white/10 transition-all">
                            <div className="min-w-0 text-right">
                               <p className="text-xs font-black text-slate-100 truncate">{req.userName}</p>
                               <p className="text-[9px] text-slate-500 font-bold uppercase mt-0.5">ID: {req.studentId}</p>
                            </div>
                            <div className="flex gap-2">
                               <button onClick={() => handleApproveReset(req)} className="p-2 bg-emerald-500 text-slate-950 rounded-lg shadow-lg hover:scale-110 active:scale-90 transition-all">
                                  <Check size={16} strokeWidth={3} />
                               </button>
                               <button className="p-2 bg-white/5 text-slate-400 rounded-lg hover:bg-rose-500 hover:text-white transition-all">
                                  <X size={16} />
                               </button>
                            </div>
                         </div>
                      ))}
                   </div>
                )}
             </div>
             
             <button onClick={() => setIsResetModalOpen(true)} className="w-full py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-400 border border-white/5 transition-all">مدیریت دسترسی‌های امنیتی</button>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[3.5rem] p-10 shadow-sm space-y-12"
          >
             <div className="flex justify-between items-center">
                <div className="space-y-1 text-right">
                   <h3 className="font-black text-slate-800 dark:text-white text-2xl tracking-tighter uppercase">Class Hub</h3>
                   <div className="flex items-center gap-1.5 justify-end">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Real-time Stats</span>
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                   </div>
                </div>
                <div className="p-3 bg-primary-50 dark:bg-primary-900/30 text-primary-600 rounded-2xl shadow-inner">
                   <BarChart3 size={24} />
                </div>
             </div>
             
             <div className="space-y-10">
                <div className="space-y-4">
                   <div className="flex justify-between items-center text-[11px] font-black uppercase tracking-[0.2em]">
                      <span className="text-emerald-500 text-sm">۸۵٪</span>
                      <span className="text-slate-400">تکالیف تکمیل شده</span>
                   </div>
                   <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                      <motion.div initial={{ width: 0 }} animate={{ width: '85%' }} transition={{ duration: 1.5, ease: "easeOut" }} className="h-full bg-emerald-500 rounded-full shadow-[0_0_15px_rgba(16,185,129,0.4)]" />
                   </div>
                </div>

                <div className="space-y-4">
                   <div className="flex justify-between items-center text-[11px] font-black uppercase tracking-[0.2em]">
                      <span className="text-primary-500 text-sm">۹۲٪</span>
                      <span className="text-slate-400">مشارکت فعال</span>
                   </div>
                   <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                      <motion.div initial={{ width: 0 }} animate={{ width: '92%' }} transition={{ duration: 1.5, delay: 0.3, ease: "easeOut" }} className="h-full bg-primary-500 rounded-full shadow-[0_0_15px_rgba(14,165,233,0.4)]" />
                   </div>
                </div>

                <div className="flex justify-between items-center pt-10 border-t border-slate-50 dark:border-slate-800">
                   <div className="w-20 h-20 rounded-3xl bg-primary-50 dark:bg-primary-900/40 flex items-center justify-center text-primary-600 border border-primary-100 dark:border-primary-800 shadow-xl">
                      <Target size={40} />
                   </div>
                   <div className="space-y-1 text-left">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">میانگین نمرات</span>
                      <p className="text-5xl font-black text-primary-600 tracking-tighter">{classAvg}</p>
                   </div>
                </div>
             </div>
          </motion.div>
        </div>
      </div>

      {/* Password Reset Requests Modal */}
      <Modal isOpen={isResetModalOpen} onClose={() => setIsResetModalOpen(false)} title="مدیریت درخواست‌های امنیتی و بازیابی رمز">
         <div className="p-8 space-y-6">
            <div className="bg-amber-50 dark:bg-amber-900/20 p-6 rounded-[2rem] border border-amber-100 dark:border-amber-800 flex items-center gap-6">
                <ShieldAlert className="text-amber-500 shrink-0" size={40} />
                <p className="text-sm font-black text-amber-900 dark:text-amber-200 leading-relaxed text-right">با تایید درخواست، رمز عبور هنرجو به "<b>123456</b>" تغییر یافته و وی می‌تواند وارد سامانه شود.</p>
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar pr-2">
               {resetRequests.length === 0 ? (
                  <div className="py-20 text-center opacity-30">
                     <CheckCircle size={80} className="mx-auto text-slate-200 mb-6" />
                     <p className="font-black text-xl">هیچ درخواست معلقی وجود ندارد.</p>
                  </div>
               ) : resetRequests.map(req => (
                  <div key={req.id} className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 flex flex-col md:flex-row justify-between items-center gap-4">
                     <div className="flex items-center gap-4 text-right w-full md:w-auto">
                        <div className="w-12 h-12 bg-slate-100 dark:bg-slate-900 rounded-2xl flex items-center justify-center text-slate-400 font-black">
                           {req.userName.charAt(0)}
                        </div>
                        <div>
                           <h4 className="font-black text-slate-800 dark:text-white">{req.userName}</h4>
                           <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">کد دانش‌آموزی: {req.studentId}</p>
                           <p className="text-[9px] text-slate-500 mt-1">{new Date(req.timestamp).toLocaleString('fa-IR')}</p>
                        </div>
                     </div>
                     <div className="flex gap-2 w-full md:w-auto">
                        <button onClick={() => handleApproveReset(req)} className="flex-1 md:flex-none px-8 py-3 bg-emerald-600 text-white rounded-xl font-black text-xs shadow-lg hover:bg-emerald-500 transition-all flex items-center justify-center gap-2">
                           <Check size={18} /> تایید و فعال‌سازی رمز
                        </button>
                        <button className="p-3 bg-slate-100 dark:bg-slate-900 text-slate-400 rounded-xl hover:text-rose-500">
                           <X size={20} />
                        </button>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </Modal>
    </div>
  );
};

export default TeacherDashboard;