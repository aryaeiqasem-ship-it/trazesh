
import React, { useState, useEffect, useRef } from 'react';
import { 
  Save, ShieldCheck, Palette, Lock, 
  School, CheckCircle, Info, Plus, 
  Settings as SettingsIcon, Shield, Layers, Image as ImageIcon,
  Monitor, Globe, Activity, Terminal, Trash2, Users, Quote as QuoteIcon,
  Edit, Key, CreditCard, Award, CheckCircle2, AlertCircle, Loader2, X
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { SystemSettings, Permission, CustomRole, Quote } from '../types';
import ConfirmationModal from '../components/ConfirmationModal';
import Modal from '../components/Modal';
import { compressImage } from '../utils/imageUtils';
import { motion, AnimatePresence } from 'framer-motion';

const AdminSettings: React.FC = () => {
  const toast = useToast();
  const { refreshBranding } = useTheme();
  const [activeTab, setActiveTab] = useState<'general' | 'branding' | 'security' | 'roles' | 'quotes' | 'license'>('general');
  const [settings, setSettings] = useState<SystemSettings>(() => storageService.getSettings());
  const [loading, setLoading] = useState(false);
  const [licenseKey, setLicenseKey] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [editingQuote, setEditingQuote] = useState<Quote | null>(null);
  const [quoteFormData, setQuoteFormData] = useState<Partial<Quote>>({ text: '', author: '' });

  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleSave = async () => {
    setLoading(true);
    try {
      storageService.saveSettings(settings);
      refreshBranding();
      toast.success('تنظیمات با موفقیت در هسته عملیاتی ثبت و اعمال شد.');
    } catch (err) {
      toast.error('خطا در همگام‌سازی تنظیمات با زیرساخت.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const compressed = await compressImage(file, 200, 0.8);
      setSettings({
        ...settings,
        branding: { ...settings.branding, logoUrl: compressed }
      });
      toast.success('لوگوی جدید آماده ذخیره‌سازی نهایی است.');
    }
  };

  // Quote Management Logic
  const handleOpenQuoteModal = (quote?: Quote) => {
    if (quote) {
      setEditingQuote(quote);
      setQuoteFormData({ ...quote });
    } else {
      setEditingQuote(null);
      setQuoteFormData({ text: '', author: '' });
    }
    setIsQuoteModalOpen(true);
  };

  const handleSaveQuote = () => {
    if (!quoteFormData.text) return toast.error('متن نقل‌قول الزامی است.');
    
    let newQuotes = [...(settings.branding.quotes || [])];
    if (editingQuote) {
      newQuotes = newQuotes.map(q => q.id === editingQuote.id ? { ...editingQuote, ...quoteFormData } as Quote : q);
    } else {
      newQuotes.push({
        id: `q_${Date.now()}`,
        text: quoteFormData.text!,
        author: quoteFormData.author || 'نامشخص'
      });
    }

    setSettings({ ...settings, branding: { ...settings.branding, quotes: newQuotes } });
    setIsQuoteModalOpen(false);
    toast.success(editingQuote ? 'نقل‌قول ویرایش شد.' : 'نقل‌قول جدید اضافه شد.');
  };

  const handleDeleteQuote = (id: string) => {
    const newQuotes = (settings.branding.quotes || []).filter(q => q.id !== id);
    setSettings({ ...settings, branding: { ...settings.branding, quotes: newQuotes } });
    toast.info('نقل‌قول حذف شد.');
  };

  const NavButton = ({ id, label, icon: Icon, color = "" }: { id: typeof activeTab, label: string, icon: any, color?: string }) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-3 px-6 py-4 rounded-2xl font-black text-sm transition-all ${activeTab === id ? `bg-primary-600 text-white shadow-xl scale-105` : `text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 ${color}`}`}
    >
      <Icon size={18} />
      {label}
    </button>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
           <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tighter flex items-center gap-3">
             <SettingsIcon className="text-primary-600" size={32} />
             تنظیمات کلان سامانه
           </h1>
           <p className="text-slate-500 font-bold mt-1">مدیریت هویت بصری، امنیت و وضعیت لایسنس سازمان</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={loading}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-10 py-4 rounded-2xl flex items-center gap-3 shadow-2xl transition-all font-black"
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />} ذخیره و اعمال تغییرات
        </button>
      </div>

      <div className="flex flex-wrap gap-2 p-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm w-fit overflow-x-auto no-scrollbar">
         <NavButton id="general" label="پیکربندی پایه" icon={Layers} />
         <NavButton id="branding" label="برندینگ هوشمند" icon={Palette} />
         <NavButton id="quotes" label="نقل‌قول‌ها" icon={QuoteIcon} />
         <NavButton id="license" label="فعال‌سازی" icon={Key} color="text-amber-600" />
         <NavButton id="security" label="امنیت" icon={ShieldCheck} />
      </div>

      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          {activeTab === 'general' && (
            <motion.div key="gen" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
               <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="font-black text-lg mb-6 flex items-center gap-2 dark:text-white"><School className="text-primary-500" />اطلاعات پایه موسسه</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2 text-right">نام رسمی موسسه</label>
                        <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner" value={settings.instituteName} onChange={e => setSettings({...settings, instituteName: e.target.value})} />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2 text-right">پیام خوش‌آمدگویی</label>
                        <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner" value={settings.branding.welcomeMessage} onChange={e => setSettings({...settings, branding: {...settings.branding, welcomeMessage: e.target.value}})} />
                     </div>
                  </div>
               </div>
            </motion.div>
          )}

          {activeTab === 'branding' && (
            <motion.div key="brand" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
               <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="font-black text-lg mb-6 flex items-center gap-2 dark:text-white"><Palette className="text-primary-500" />هویت بصری و پالت رنگی</h3>
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                     <div className="md:col-span-4 flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-[2rem]">
                        <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-3xl flex items-center justify-center overflow-hidden mb-4 shadow-inner">
                           {settings.branding.logoUrl ? <img src={settings.branding.logoUrl} className="w-full h-full object-contain" /> : <ImageIcon size={40} className="text-slate-300" />}
                        </div>
                        <input type="file" ref={logoInputRef} className="hidden" accept="image/*" onChange={handleLogoUpload} />
                        <button onClick={() => logoInputRef.current?.click()} className="text-[10px] font-black text-primary-600 uppercase tracking-widest hover:underline">تغییر لوگو سازمان</button>
                     </div>
                     <div className="md:col-span-8 space-y-6">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block text-right">رنگ سازمانی (Primary Color)</label>
                          <div className="flex gap-4 items-center">
                             <input type="color" className="w-20 h-20 rounded-2xl border-none p-0 overflow-hidden cursor-pointer shadow-lg transition-transform hover:scale-105" value={settings.branding.primaryColor} onChange={e => setSettings({...settings, branding: {...settings.branding, primaryColor: e.target.value}})} />
                             <div className="flex-1">
                                <input type="text" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-mono text-sm text-slate-900 dark:text-white" value={settings.branding.primaryColor} readOnly />
                                <p className="text-[9px] text-slate-400 mt-2 font-bold leading-relaxed">تغییر این رنگ بلافاصله در تمامی دکمه‌ها، آیکون‌ها و المان‌های سیستم اعمال خواهد شد.</p>
                             </div>
                          </div>
                        </div>
                     </div>
                  </div>
               </div>
            </motion.div>
          )}

          {activeTab === 'quotes' && (
             <motion.div key="quotes" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-6">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                   <div className="flex justify-between items-center mb-8">
                      <h3 className="font-black text-lg flex items-center gap-2 dark:text-white"><QuoteIcon className="text-primary-500" /> مدیریت نقل‌قول‌های صفحه ورود</h3>
                      <button onClick={() => handleOpenQuoteModal()} className="bg-primary-50 dark:bg-primary-900/20 text-primary-600 px-6 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all hover:bg-primary-600 hover:text-white">
                         <Plus size={16} /> افزودن جدید
                      </button>
                   </div>

                   <div className="grid grid-cols-1 gap-4">
                      {(settings.branding.quotes || []).length === 0 ? (
                         <div className="py-20 text-center opacity-30 italic font-black text-slate-500">نقل‌قولی تعریف نشده است.</div>
                      ) : (settings.branding.quotes || []).map(q => (
                         <div key={q.id} className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800 flex justify-between items-center group transition-all hover:bg-white">
                            <div className="flex-1 pr-4">
                               <p className="font-black text-slate-800 dark:text-slate-100 leading-relaxed text-sm">« {q.text} »</p>
                               <p className="text-[10px] text-slate-400 font-bold mt-1">― {q.author}</p>
                            </div>
                            <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                               <button onClick={() => handleOpenQuoteModal(q)} className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg"><Edit size={16}/></button>
                               <button onClick={() => handleDeleteQuote(q.id)} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg"><Trash2 size={16}/></button>
                            </div>
                         </div>
                      ))}
                   </div>
                </div>
             </motion.div>
          )}
          
          {activeTab === 'license' && (
             <motion.div key="lic" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
                <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-10">
                   <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shadow-inner"><Key size={32}/></div>
                      <div>
                         <h3 className="text-xl font-black">فعال‌سازی ویژگی‌های حرفه‌ای</h3>
                         <p className="text-xs text-slate-400 font-bold">کد لایسنس خود را جهت فعال‌سازی ماژول‌های هوش مصنوعی وارد کنید.</p>
                      </div>
                   </div>
                   <div className="space-y-4">
                      <div className="relative">
                         <input 
                           type="text"
                           value={licenseKey}
                           onChange={e => setLicenseKey(e.target.value.toUpperCase())}
                           className="w-full p-6 bg-slate-50 dark:bg-slate-800 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-3xl font-mono text-lg tracking-widest text-center outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all text-slate-900 dark:text-white"
                           placeholder="EDUP-XXXX-XXXX"
                         />
                         <Terminal size={20} className="absolute left-6 top-7 text-slate-300" />
                      </div>
                      <button 
                        onClick={() => toast.info('این قابلیت در نسخه دمو فعال نیست.')}
                        className="w-full py-5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-2xl font-black shadow-2xl flex items-center justify-center gap-3 transition-all"
                      >
                         <ShieldCheck size={24}/> فعال‌سازی آنی سیستم
                      </button>
                   </div>
                </div>
             </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Quote Modal */}
      <Modal isOpen={isQuoteModalOpen} onClose={() => setIsQuoteModalOpen(false)} title={editingQuote ? 'ویرایش نقل‌قول' : 'افزودن نقل‌قول جدید'} maxWidth="max-w-md">
         <div className="p-8 space-y-6 text-right">
            <div className="space-y-2">
               <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">متن نقل‌قول</label>
               <textarea className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner" rows={4} value={quoteFormData.text} onChange={e => setQuoteFormData({...quoteFormData, text: e.target.value})} placeholder="آموزش سلاحی است که..." />
            </div>
            <div className="space-y-2">
               <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">نام نویسنده (اختیاری)</label>
               <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner" value={quoteFormData.author} onChange={e => setQuoteFormData({...quoteFormData, author: e.target.value})} placeholder="نلسون ماندلا" />
            </div>
            <button onClick={handleSaveQuote} className="w-full py-4 bg-primary-600 hover:bg-primary-700 text-white rounded-2xl font-black shadow-xl flex items-center justify-center gap-2">
               <Save size={18} /> ثبت در لیست
            </button>
         </div>
      </Modal>
    </div>
  );
};

export default AdminSettings;
