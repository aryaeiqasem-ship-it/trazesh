
import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { User, ClassEntity, UserRole, AttendanceRecord } from '../types';
import { Check, X, Clock, Calendar, Save, Filter, Shuffle, Grid, List, ThumbsUp, ThumbsDown, MoreHorizontal, Users, BarChart2 } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import Modal from '../components/Modal';
import confetti from 'canvas-confetti';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const TeacherAttendance: React.FC = () => {
  const [classes, setClasses] = useState<ClassEntity[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [students, setStudents] = useState<User[]>([]);
  const [attendanceDate, setAttendanceDate] = useState<string>(new Date().toISOString().slice(0, 10));
  
  // States
  const [attendanceStatus, setAttendanceStatus] = useState<Record<string, 'present' | 'absent' | 'late'>>({});
  const [participationScore, setParticipationScore] = useState<Record<string, number>>({});
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Random Picker State
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [pickedStudent, setPickedStudent] = useState<User | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);

  const toast = useToast();

  useEffect(() => {
    setClasses(storageService.getClasses());
  }, []);

  useEffect(() => {
    if (selectedClassId) {
      const cls = classes.find(c => c.id === selectedClassId);
      const allUsers = storageService.getUsers();
      // Match students by class name (Mock logic)
      const classStudents = allUsers.filter(u => 
        u.role === UserRole.STUDENT && 
        u.class === cls?.title
      );
      setStudents(classStudents);
      
      // Initialize Status
      const initialStatus: Record<string, 'present' | 'absent' | 'late'> = {};
      const initialScores: Record<string, number> = {};
      classStudents.forEach(s => {
        initialStatus[s.id] = 'absent'; // Default to absent or 'unset' logic
        initialScores[s.id] = 0;
      });
      setAttendanceStatus(initialStatus);
      setParticipationScore(initialScores);
    }
  }, [selectedClassId, classes]);

  // --- Statistics ---
  const stats = useMemo(() => {
    const total = students.length;
    if (total === 0) return { present: 0, late: 0, absent: 0, percent: 0, avgScore: 0 };
    
    const presentCount = Object.values(attendanceStatus).filter(s => s === 'present').length;
    const lateCount = Object.values(attendanceStatus).filter(s => s === 'late').length;
    const absentCount = Object.values(attendanceStatus).filter(s => s === 'absent').length;
    
    // Explicitly cast to number[] to ensure reduce works correctly with arithmetic types
    const scores = Object.values(participationScore) as number[];
    const totalScore = scores.reduce((a, b) => a + b, 0);
    
    return {
      present: presentCount,
      late: lateCount,
      absent: absentCount,
      percent: Math.round(((presentCount + lateCount) / total) * 100),
      avgScore: total > 0 ? parseFloat((totalScore / total).toFixed(1)) : 0
    };
  }, [attendanceStatus, students, participationScore]);

  const chartData = [
    { name: 'حاضر', value: stats.present, color: '#22c55e' },
    { name: 'تاخیر', value: stats.late, color: '#f59e0b' },
    { name: 'غایب', value: stats.absent, color: '#ef4444' },
  ];

  // --- Actions ---

  const handleStatusChange = (studentId: string, status: 'present' | 'absent' | 'late') => {
    setAttendanceStatus(prev => ({ ...prev, [studentId]: status }));
  };

  const handleParticipation = (studentId: string, delta: number) => {
    setParticipationScore(prev => {
        const currentVal = prev[studentId] || 0;
        return { ...prev, [studentId]: currentVal + delta };
    });
    
    // In a real app, this would update the backend immediately or queue it
    if (delta > 0) toast.success('امتیاز مثبت ثبت شد (+XP)');
    else toast.info('امتیاز منفی ثبت شد');
  };

  const markAllPresent = () => {
    if (students.length === 0) return;
    const newStatus = { ...attendanceStatus };
    students.forEach(s => {
      // Only mark as present if currently absent (preserve 'late' status if manually set)
      if (newStatus[s.id] === 'absent') {
        newStatus[s.id] = 'present';
      }
    });
    setAttendanceStatus(newStatus);
    toast.success('وضعیت همه دانش‌آموزان به "حاضر" تغییر یافت.');
  };

  const saveAttendance = () => {
    if (!selectedClassId) return;

    const record: AttendanceRecord = {
      id: `att_${Date.now()}`,
      classId: selectedClassId,
      date: attendanceDate,
      presentStudentIds: Object.keys(attendanceStatus).filter(id => attendanceStatus[id] === 'present'),
      absentStudentIds: Object.keys(attendanceStatus).filter(id => attendanceStatus[id] === 'absent'),
      lateStudentIds: Object.keys(attendanceStatus).filter(id => attendanceStatus[id] === 'late'),
    };

    const existingRecords = storageService.getAttendance();
    storageService.saveAttendance([...existingRecords, record]);
    toast.success('لیست حضور و غیاب و امتیازات کلاسی ذخیره شد.');
  };

  // --- Random Picker Logic ---
  const startRandomPicker = () => {
    const presentStudents = students.filter(s => attendanceStatus[s.id] !== 'absent');
    if (presentStudents.length === 0) {
      toast.error('هیچ دانش‌آموز حاضری برای انتخاب وجود ندارد.');
      return;
    }

    setIsPickerOpen(true);
    setIsSpinning(true);
    setPickedStudent(null);

    let duration = 3000;
    let interval = 100;
    let elapsed = 0;

    const spinInterval = setInterval(() => {
      const randomIdx = Math.floor(Math.random() * presentStudents.length);
      setPickedStudent(presentStudents[randomIdx]);
      elapsed += interval;
      
      if (elapsed >= duration) {
        clearInterval(spinInterval);
        setIsSpinning(false);
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }, interval);
  };

  // --- Render Components ---

  const renderGridCard = (student: User) => {
    const status = attendanceStatus[student.id];
    const score = participationScore[student.id];
    
    let borderColor = 'border-slate-200 dark:border-slate-800';
    let bgColor = 'bg-white dark:bg-slate-900';
    
    if (status === 'present') {
      borderColor = 'border-green-500';
      bgColor = 'bg-green-50/30 dark:bg-green-900/10';
    } else if (status === 'late') {
      borderColor = 'border-amber-500';
      bgColor = 'bg-amber-50/30 dark:bg-amber-900/10';
    } else {
      borderColor = 'border-red-200 dark:border-red-900/50';
      bgColor = 'bg-slate-50 dark:bg-slate-900/50 opacity-80';
    }

    return (
      <motion.div 
        layout
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        key={student.id}
        className={`relative rounded-2xl border-2 shadow-sm overflow-hidden flex flex-col transition-all ${borderColor} ${bgColor}`}
      >
        <div className="p-4 flex items-center gap-3">
          <div className="relative">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold text-white shadow-md ${
              status === 'present' ? 'bg-green-500' : status === 'late' ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'
            }`}>
              {student.avatar ? <img src={student.avatar} className="w-full h-full rounded-full object-cover"/> : student.name.charAt(0)}
            </div>
            {status !== 'absent' && (
              <div className="absolute -bottom-1 -right-1 bg-white dark:bg-slate-900 rounded-full p-0.5 shadow-sm">
                {status === 'present' ? <Check className="w-4 h-4 text-green-600" /> : <Clock className="w-4 h-4 text-amber-600" />}
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-slate-800 dark:text-slate-100 truncate">{student.name}</h3>
            <p className="text-xs text-slate-500 font-mono">{student.studentId}</p>
          </div>
          {score !== 0 && (
            <div className={`px-2 py-1 rounded-lg text-xs font-bold ${score > 0 ? 'bg-indigo-100 text-indigo-700' : 'bg-red-100 text-red-700'}`}>
              {score > 0 ? '+' : ''}{score}
            </div>
          )}
        </div>

        {/* Action Bar */}
        <div className="mt-auto grid grid-cols-5 divide-x divide-x-reverse divide-slate-100 dark:divide-slate-800 border-t border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm">
          <button onClick={() => handleStatusChange(student.id, 'present')} className={`p-3 flex justify-center hover:bg-green-50 dark:hover:bg-green-900/20 ${status === 'present' ? 'text-green-600' : 'text-slate-400'}`}>
            <Check size={18} />
          </button>
          <button onClick={() => handleStatusChange(student.id, 'late')} className={`p-3 flex justify-center hover:bg-amber-50 dark:hover:bg-amber-900/20 ${status === 'late' ? 'text-amber-600' : 'text-slate-400'}`}>
            <Clock size={18} />
          </button>
          <button onClick={() => handleStatusChange(student.id, 'absent')} className={`p-3 flex justify-center hover:bg-red-50 dark:hover:bg-red-900/20 ${status === 'absent' ? 'text-red-500' : 'text-slate-400'}`}>
            <X size={18} />
          </button>
          <button onClick={() => handleParticipation(student.id, 1)} className="p-3 flex justify-center text-indigo-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20">
            <ThumbsUp size={16} />
          </button>
          <button onClick={() => handleParticipation(student.id, -1)} className="p-3 flex justify-center text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20">
            <ThumbsDown size={16} />
          </button>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header & Controls */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Calendar className="text-primary-600" />
              مدیریت کلاس و حضور و غیاب
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              {new Date().toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
          </div>
          
          {/* Enhanced Stats with Chart */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
             <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-800 px-4 py-2 rounded-xl border border-slate-100 dark:border-slate-700">
                <div className="w-12 h-12">
                   <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                         <Pie data={chartData} innerRadius={15} outerRadius={24} paddingAngle={0} dataKey="value" stroke="none">
                            {chartData.map((entry, index) => (
                               <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                         </Pie>
                      </PieChart>
                   </ResponsiveContainer>
                </div>
                <div className="flex flex-col gap-1 min-w-[100px]">
                   <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                      <span>{stats.percent}% حضور</span>
                      <span className="text-slate-400 font-normal">کل: {students.length}</span>
                   </div>
                   <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden flex">
                      <div className="bg-green-500 h-full" style={{ width: `${(stats.present / (students.length || 1)) * 100}%` }}></div>
                      <div className="bg-amber-500 h-full" style={{ width: `${(stats.late / (students.length || 1)) * 100}%` }}></div>
                   </div>
                </div>
             </div>

             <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl border border-slate-100 dark:border-slate-700">
                <BarChart2 className="text-indigo-500" size={20} />
                <div>
                   <p className="text-[10px] text-slate-500 uppercase font-bold">میانگین امتیاز</p>
                   <p className="text-lg font-black text-indigo-600 dark:text-indigo-400">{stats.avgScore}</p>
                </div>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="flex-1">
            <label className="text-xs font-bold text-slate-500 mb-1 block">کلاس</label>
            <select 
              className="w-full p-2.5 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
            >
              <option value="">انتخاب کلاس...</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.title} ({c.major})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 mb-1 block">تاریخ</label>
            <input 
              type="date" 
              className="w-full p-2.5 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-white outline-none"
              value={attendanceDate}
              onChange={(e) => setAttendanceDate(e.target.value)}
            />
          </div>
          
          {/* Tools */}
          <div className="flex gap-2">
             <button 
                onClick={markAllPresent}
                disabled={!selectedClassId}
                className="flex-1 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900/30 px-4 py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
             >
               <Users size={18} /> همه حاضر
             </button>
             <button 
                onClick={startRandomPicker}
                disabled={!selectedClassId}
                className="flex-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 px-4 py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
             >
               <Shuffle size={18} /> قرعه‌کشی
             </button>
             <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0">
                <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600' : 'text-slate-400'}`}>
                   <Grid size={18} />
                </button>
                <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600' : 'text-slate-400'}`}>
                   <List size={18} />
                </button>
             </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      {!selectedClassId ? (
        <div className="text-center py-20 bg-slate-50 dark:bg-slate-900/50 rounded-3xl border-2 border-dashed border-slate-300 dark:border-slate-800">
          <div className="w-20 h-20 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center shadow-sm mx-auto mb-4">
             <Calendar size={32} className="text-slate-400" />
          </div>
          <h3 className="text-lg font-bold text-slate-700 dark:text-slate-300">کلاس را انتخاب کنید</h3>
          <p className="text-slate-500">برای شروع ثبت حضور و غیاب، ابتدا یک کلاس را انتخاب کنید.</p>
        </div>
      ) : students.length === 0 ? (
        <div className="text-center py-12 text-slate-400">دانش‌آموزی در این کلاس یافت نشد.</div>
      ) : (
        <>
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              <AnimatePresence>
                {students.map(student => renderGridCard(student))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
               {/* List View Implementation */}
               <table className="w-full text-right">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-sm">
                     <tr>
                        <th className="px-6 py-4">دانش‌آموز</th>
                        <th className="px-6 py-4 text-center">وضعیت</th>
                        <th className="px-6 py-4 text-center">امتیاز کلاسی</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                     {students.map(student => (
                        <tr key={student.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                           <td className="px-6 py-4 font-medium text-slate-800 dark:text-slate-200">
                              <div className="flex items-center gap-3">
                                 <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-xs font-bold">
                                    {student.name.charAt(0)}
                                 </div>
                                 {student.name}
                              </div>
                           </td>
                           <td className="px-6 py-4">
                              <div className="flex justify-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg w-fit mx-auto">
                                 <button onClick={() => handleStatusChange(student.id, 'present')} className={`px-3 py-1 rounded text-xs font-bold transition-colors ${attendanceStatus[student.id] === 'present' ? 'bg-green-500 text-white shadow' : 'text-slate-500'}`}>حاضر</button>
                                 <button onClick={() => handleStatusChange(student.id, 'late')} className={`px-3 py-1 rounded text-xs font-bold transition-colors ${attendanceStatus[student.id] === 'late' ? 'bg-amber-500 text-white shadow' : 'text-slate-500'}`}>تاخیر</button>
                                 <button onClick={() => handleStatusChange(student.id, 'absent')} className={`px-3 py-1 rounded text-xs font-bold transition-colors ${attendanceStatus[student.id] === 'absent' ? 'bg-red-500 text-white shadow' : 'text-slate-500'}`}>غایب</button>
                              </div>
                           </td>
                           <td className="px-6 py-4">
                              <div className="flex items-center justify-center gap-3">
                                 <button onClick={() => handleParticipation(student.id, -1)} className="w-8 h-8 rounded-full border border-rose-200 text-rose-500 hover:bg-rose-50 flex items-center justify-center"><ThumbsDown size={14}/></button>
                                 <span className="font-bold w-6 text-center">{participationScore[student.id] || 0}</span>
                                 <button onClick={() => handleParticipation(student.id, 1)} className="w-8 h-8 rounded-full border border-indigo-200 text-indigo-500 hover:bg-indigo-50 flex items-center justify-center"><ThumbsUp size={14}/></button>
                              </div>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
          )}

          {/* Sticky Save Bar */}
          <div className="fixed bottom-6 right-6 md:right-80 left-6 z-20">
             <div className="bg-slate-900/90 dark:bg-slate-800/90 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl flex justify-between items-center max-w-3xl mx-auto border border-white/10">
                <div className="text-sm">
                   <span className="font-bold text-green-400">{stats.present} حاضر</span>، 
                   <span className="font-bold text-amber-400 mx-2">{stats.late} تاخیر</span>، 
                   <span className="font-bold text-red-400">{stats.absent} غایب</span>
                </div>
                <button 
                   onClick={saveAttendance}
                   className="bg-green-600 hover:bg-green-500 text-white px-6 py-2 rounded-xl font-bold shadow-lg shadow-green-600/30 transition-all flex items-center gap-2"
                >
                   <Save size={18} /> ثبت نهایی
                </button>
             </div>
          </div>
        </>
      )}

      {/* Random Picker Modal */}
      <Modal 
        isOpen={isPickerOpen}
        onClose={() => setIsPickerOpen(false)}
        title="انتخاب تصادفی دانش‌آموز"
        maxWidth="max-w-md"
      >
         <div className="p-8 flex flex-col items-center justify-center text-center min-h-[300px]">
            {isSpinning ? (
               <div className="space-y-6">
                  <div className="relative w-32 h-32">
                     <div className="absolute inset-0 border-4 border-slate-200 rounded-full"></div>
                     <div className="absolute inset-0 border-4 border-indigo-500 rounded-full border-t-transparent animate-spin"></div>
                     <div className="absolute inset-0 flex items-center justify-center font-bold text-4xl text-slate-300">?</div>
                  </div>
                  <h3 className="text-xl font-bold animate-pulse text-slate-700 dark:text-slate-300">
                     {pickedStudent ? pickedStudent.name : 'در حال انتخاب...'}
                  </h3>
               </div>
            ) : pickedStudent ? (
               <motion.div 
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="space-y-6"
               >
                  <div className="w-32 h-32 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-5xl font-bold text-white shadow-xl mx-auto border-4 border-white dark:border-slate-800">
                     {pickedStudent.avatar ? <img src={pickedStudent.avatar} className="w-full h-full rounded-full object-cover"/> : pickedStudent.name.charAt(0)}
                  </div>
                  <div>
                     <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-1">{pickedStudent.name}</h2>
                     <p className="text-slate-500">انتخاب شده برای پاسخگویی</p>
                  </div>
                  <div className="flex gap-3 justify-center pt-4">
                     <button onClick={() => { setIsPickerOpen(false); handleParticipation(pickedStudent.id, 1); }} className="bg-green-100 text-green-700 px-6 py-2 rounded-xl font-bold hover:bg-green-200 transition-colors flex items-center gap-2">
                        <ThumbsUp size={18} /> پاسخ صحیح (+XP)
                     </button>
                     <button onClick={() => { setIsPickerOpen(false); handleParticipation(pickedStudent.id, -1); }} className="bg-red-100 text-red-700 px-6 py-2 rounded-xl font-bold hover:bg-red-200 transition-colors flex items-center gap-2">
                        <ThumbsDown size={18} /> پاسخ غلط
                     </button>
                  </div>
               </motion.div>
            ) : null}
         </div>
      </Modal>
    </div>
  );
};

export default TeacherAttendance;
