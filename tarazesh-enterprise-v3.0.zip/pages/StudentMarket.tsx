import React, { useState } from 'react';
import { User, ShopItem } from '../types';
import { storageService } from '../services/storageService';
import { 
  Zap, ShoppingBag, Clock, Palette, RefreshCcw, 
  Check, Star, Sparkles, Coins,
  Crown, ShieldCheck, Wand2, Diamond, Gem, Trophy, CreditCard, Plus
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import Modal from '../components/Modal';
import PaymentModal from '../components/PaymentModal';
import confetti from 'canvas-confetti';

const VIP_AVATARS = [
  "https://api.dicebear.com/7.x/avataaars/svg?seed=King&backgroundColor=f59e0b",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Queen&backgroundColor=fef3c7",
  "https://api.dicebear.com/7.x/bottts/svg?seed=VIP1&colors=ffd700",
  "https://api.dicebear.com/7.x/pixel-art/svg?seed=Legend&backgroundColor=f59e0b",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Hero&hair=long01&backgroundColor=fcd34d",
  "https://api.dicebear.com/7.x/personas/svg?seed=Royal&backgroundColor=fbbf24",
  "https://api.dicebear.com/7.x/miniavs/svg?seed=Elite&backgroundColor=d97706",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Mythic&backgroundColor=b45309",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Prime&backgroundColor=78350f",
  "https://api.dicebear.com/7.x/bottts/svg?seed=Obsidian&colors=451a03",
  "https://api.dicebear.com/7.x/pixel-art/svg?seed=Star&backgroundColor=fde68a",
  "https://api.dicebear.com/7.x/adventurer/svg?seed=Champion&backgroundColor=f59e0b",
];

const SHOP_ITEMS: ShopItem[] = [
  { id: 'item_1', title: 'کارت وقت اضافه', description: '۱۰ دقیقه زمان بیشتر برای آزمون بعدی', costXp: 800, type: 'booster', icon: 'clock' },
  { id: 'item_2', title: 'تم طلایی متالیک', description: 'ظاهری سلطنتی و لوکس برای تمام بخش‌های سامانه شما', costXp: 7500, type: 'cosmetic', icon: 'palette' },
  { id: 'item_3', title: 'شانس مجدد حرفه‌ای', description: 'امکان شرکت مجدد در یک آزمون رسمی با تایید مدرس', costXp: 1500, type: 'privilege', icon: 'refresh-ccw' },
  { id: 'item_4', title: 'آواتارهای ویژه VIP', description: 'دسترسی به مجموعه ۱۲ عددی آواتارهای متحرک و درخشان', costXp: 4500, type: 'cosmetic', icon: 'user' },
];

const XP_BUNDLES = [
  { id: 'xp_1', amount: 1000, price: 49000 },
  { id: 'xp_2', amount: 5000, price: 199000, popular: true },
  { id: 'xp_3', amount: 15000, price: 450000 },
];

/* Fix: Local component for section labeling to resolve missing name error */
const SectionLabel = ({ children }: { children?: React.ReactNode }) => (
  <p className="px-5 mt-6 mb-2 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{children}</p>
);

interface MarketProps {
  currentUser: User;
  onRefreshUser?: () => void;
}

const StudentMarket: React.FC<MarketProps> = ({ currentUser, onRefreshUser }) => {
  const [xp, setXp] = useState(currentUser.gamification?.xp || 0);
  const [purchased, setPurchased] = useState<string[]>(currentUser.gamification?.purchasedItems || []);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [paymentTarget, setPaymentTarget] = useState<{name: string, amount: number, xpValue: number} | null>(null);
  
  const { theme, setTheme } = useTheme();
  const toast = useToast();

  const handlePurchase = (item: ShopItem) => {
    if (xp < item.costXp) {
      toast.error(`امتیاز XP شما کافی نیست. (نیاز به ${item.costXp - xp} امتیاز بیشتر)`);
      return;
    }
    if (purchased.includes(item.id)) {
      toast.warning('شما قبلاً این جادو را تصاحب کرده‌اید.');
      return;
    }

    const newXp = xp - item.costXp;
    const newPurchased = [...purchased, item.id];
    
    setXp(newXp);
    setPurchased(newPurchased);
    
    const updatedUser: Partial<User> = {
      id: currentUser.id,
      gamification: { 
        ...(currentUser.gamification || {level: 1, nextLevelXp: 400, badges: []}), 
        xp: newXp, 
        purchasedItems: newPurchased 
      }
    };

    storageService.saveUser(updatedUser).then(() => {
        if (onRefreshUser) onRefreshUser();
        toast.success(`آیتم "${item.title}" با موفقیت خریداری شد! ✨`);
        if (item.type === 'cosmetic') confetti({ particleCount: 150, spread: 70, colors: ['#fbbf24', '#f59e0b', '#d97706'] });
    });
  };

  const handlePaymentSuccess = () => {
    if (!paymentTarget) return;
    
    const newXp = xp + paymentTarget.xpValue;
    setXp(newXp);
    
    const updatedUser: Partial<User> = {
      id: currentUser.id,
      gamification: { 
        ...(currentUser.gamification || {level: 1, nextLevelXp: 400, badges: []}), 
        xp: newXp 
      }
    };

    storageService.saveUser(updatedUser).then(() => {
        if (onRefreshUser) onRefreshUser();
        toast.success(`تعداد ${paymentTarget.xpValue.toLocaleString()} امتیاز به حساب شما واریز شد!`);
        confetti({ particleCount: 200, spread: 90, colors: ['#0088cc', '#ffffff'] });
    });
  };

  const handleUseItem = (item: ShopItem) => {
    if (item.id === 'item_2') {
      if (theme === 'gold') {
        setTheme('dark');
        toast.info('تم به حالت پیش‌فرض بازگشت.');
      } else {
        setTheme('gold');
        toast.success('تم طلایی متالیک با موفقیت اعمال شد! 👑');
        confetti({ particleCount: 100, spread: 80, colors: ['#fbbf24'] });
      }
    } else if (item.id === 'item_4') {
      setIsAvatarModalOpen(true);
    } else {
       toast.info('این قابلیت در زمان مناسب به صورت خودکار توسط سیستم فعال خواهد شد.');
    }
  };

  const handleSelectAvatar = (url: string) => {
    storageService.saveUser({ id: currentUser.id, avatar: url }).then(() => {
        if (onRefreshUser) onRefreshUser();
        setIsAvatarModalOpen(false);
        toast.success('آواتار VIP شما با موفقیت تغییر یافت. فوق‌العاده به نظر می‌رسید! 😎');
        confetti({ particleCount: 100, spread: 70 });
    }).catch(() => toast.error("خطا در اعمال آواتار جدید."));
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'clock': return <Clock size={24} />;
      case 'palette': return <Gem size={24} className="text-amber-500" />;
      case 'refresh-ccw': return <RefreshCcw size={24} />;
      case 'user': return <Diamond size={24} className="text-blue-400" />;
      default: return <ShoppingBag size={24} />;
    }
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-slate-950 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl border border-amber-500/20">
         <div className="absolute top-0 right-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
         <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-right">
               <h1 className="text-4xl font-black mb-2 flex items-center gap-4">
                  <Trophy className="text-amber-500" size={36} /> بازارچه افتخارات (Royal Shop)
               </h1>
               <p className="text-slate-400 font-bold text-lg">ارتقای هویت بصری و قابلیت‌های جادویی با امتیاز XP</p>
            </div>
            <div className="bg-white/5 backdrop-blur-2xl p-6 rounded-[2.5rem] border border-white/10 flex items-center gap-6 shadow-[0_0_50px_rgba(245,158,11,0.1)]">
               <div className="text-right">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">ثروت فعلی شما</p>
                  <p className="text-4xl font-black text-amber-400 tracking-tighter">{xp.toLocaleString()} <span className="text-sm opacity-50">XP</span></p>
               </div>
               <div className="w-16 h-16 bg-amber-500 text-slate-950 rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(251,191,36,0.4)] animate-pulse">
                  <Coins size={36} />
               </div>
            </div>
         </div>
      </div>

      <SectionLabel>شارژ سریع امتیاز XP</SectionLabel>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {XP_BUNDLES.map(bundle => (
           <div key={bundle.id} className={`bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border-2 flex flex-col items-center text-center group transition-all hover:scale-105 ${bundle.popular ? 'border-primary-500 shadow-xl' : 'border-slate-100 dark:border-slate-800'}`}>
              {bundle.popular && <span className="px-4 py-1 bg-primary-500 text-white text-[10px] font-black rounded-full mb-4 uppercase tracking-widest">محبوب‌ترین</span>}
              <div className="w-16 h-16 bg-primary-50 text-primary-600 rounded-2xl flex items-center justify-center mb-4"><Zap size={32} /></div>
              <h3 className="text-xl font-black text-slate-800 dark:text-white mb-1">{bundle.amount.toLocaleString()} XP</h3>
              <p className="text-2xl font-black text-slate-900 dark:text-slate-100 mb-8">{bundle.price.toLocaleString()} <span className="text-xs opacity-50">تومان</span></p>
              <button 
                onClick={() => setPaymentTarget({ name: `شارژ ${bundle.amount} XP`, amount: bundle.price, xpValue: bundle.amount })}
                className="w-full py-4 bg-primary-600 text-white rounded-2xl font-black shadow-lg shadow-primary-600/20 hover:bg-primary-700 transition-all flex items-center justify-center gap-2"
              >
                <Plus size={18} /> خرید آنی
              </button>
           </div>
         ))}
      </div>

      <SectionLabel>فروشگاه جادوها و تم‌ها</SectionLabel>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
         {SHOP_ITEMS.map((item, idx) => {
            const isOwned = purchased.includes(item.id);
            const canAfford = xp >= item.costXp;
            const isEquipped = item.id === 'item_2' && theme === 'gold';
            
            return (
               <motion.div key={item.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }}
                  className={`bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border-2 transition-all group relative overflow-hidden ${isOwned ? 'border-amber-500/30' : 'border-transparent hover:border-amber-500 shadow-sm hover:shadow-2xl'}`}
               >
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-inner transition-transform group-hover:rotate-12 ${
                    item.type === 'booster' ? 'bg-rose-50 text-rose-600' : 
                    item.type === 'cosmetic' ? 'bg-amber-50 text-amber-600' : 
                    'bg-blue-50 text-blue-600'
                  }`}>
                     {getIcon(item.icon)}
                  </div>
                  
                  <h3 className="text-xl font-black text-slate-800 dark:text-white mb-2 text-right">{item.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-bold mb-8 leading-relaxed h-12 overflow-hidden text-right">{item.description}</p>
                  
                  <div className="flex justify-between items-center pt-6 border-t border-slate-50 dark:border-slate-800">
                     {!isOwned ? (
                        <div className="flex items-center gap-1.5">
                           <Zap size={14} className="text-amber-500" />
                           <span className="text-xl font-black text-slate-700 dark:text-slate-200">{item.costXp.toLocaleString()}</span>
                        </div>
                     ) : (
                        <div className="flex items-center gap-1 text-amber-600 text-[10px] font-black uppercase">
                           <ShieldCheck size={14} /> تملک شده
                        </div>
                     )}
                     
                     <button onClick={() => isOwned ? handleUseItem(item) : handlePurchase(item)} disabled={!isOwned && !canAfford}
                        className={`px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${
                          isOwned 
                            ? (isEquipped ? 'bg-amber-500 text-white shadow-lg' : 'bg-slate-900 text-white hover:bg-amber-600') 
                            : (canAfford ? 'bg-amber-500 text-slate-950 shadow-xl hover:scale-105 active:scale-95' : 'bg-slate-100 text-slate-400 cursor-not-allowed')
                        }`}
                     >
                        {isOwned ? (isEquipped ? 'غیرفعال‌سازی' : 'استفاده از جادو') : 'خرید نهایی'}
                     </button>
                  </div>
               </motion.div>
            )
         })}
      </div>

      <Modal isOpen={isAvatarModalOpen} onClose={() => setIsAvatarModalOpen(false)} title="کمد آواتارهای سلطنتی (VIP)">
         <div className="p-8">
            <div className="flex items-center gap-4 mb-10 bg-gradient-to-r from-amber-500 to-yellow-600 p-6 rounded-[2rem] text-slate-950 shadow-xl">
               <Crown size={40} />
               <div>
                  <h4 className="font-black text-xl uppercase tracking-tight">VIP Elite Status</h4>
                  <p className="text-xs font-bold opacity-80 leading-relaxed">شما اجازه دسترسی به مخزن آواتارهای ویژه با درخشش متالیک را دارید.</p>
               </div>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-6">
               {VIP_AVATARS.map((url, i) => (
                  <button key={i} onClick={() => handleSelectAvatar(url)} className="relative group transition-all hover:scale-110 active:scale-95">
                     <div className="w-full aspect-square rounded-[2rem] overflow-hidden border-4 border-slate-100 group-hover:border-amber-400 shadow-lg group-hover:shadow-[0_0_30px_rgba(245,158,11,0.4)] transition-all">
                        <img src={url} className="w-full h-full object-cover bg-slate-50" alt={`VIP Avatar ${i}`} />
                     </div>
                     <div className="absolute -top-2 -right-2 bg-amber-500 text-slate-950 w-6 h-6 rounded-lg flex items-center justify-center shadow-lg"><Star size={12} fill="currentColor" /></div>
                  </button>
               ))}
            </div>
         </div>
      </Modal>

      <PaymentModal 
        isOpen={!!paymentTarget} 
        onClose={() => setPaymentTarget(null)} 
        onSuccess={handlePaymentSuccess}
        amount={paymentTarget?.amount || 0}
        itemName={paymentTarget?.name || ''}
      />
    </div>
  );
};

export default StudentMarket;