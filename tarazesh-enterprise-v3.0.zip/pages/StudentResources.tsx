
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { Resource } from '../types';
// Fix: Added missing 'X' icon to the lucide-react import list
import { FolderOpen, FileText, Video, Link, Download, Search, Image as ImageIcon, ExternalLink, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const StudentResources: React.FC = () => {
  const [resources, setResources] = useState<Resource[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    setResources(storageService.getResources());
  }, []);

  const filteredResources = resources.filter(r => 
    r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getIcon = (type: string) => {
    switch(type) {
      case 'pdf': return <FileText size={24} className="text-rose-500" />;
      case 'video': return <Video size={24} className="text-blue-500" />;
      case 'image': return <ImageIcon size={24} className="text-emerald-500" />;
      default: return <Link size={24} className="text-indigo-500" />;
    }
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-3">
            <FolderOpen className="text-primary-600" size={32} />
            کتابخانه دیجیتال و منابع آموزشی
          </h1>
          <p className="text-sm text-slate-500 font-bold mt-1">دسترسی به جزوات، ویدیوها و محتوای کمک‌درسی</p>
        </div>
        <div className="bg-primary-50 dark:bg-primary-900/20 px-6 py-3 rounded-2xl border border-primary-100 dark:border-primary-800">
           <span className="text-xs font-black text-primary-700 dark:text-primary-400 uppercase">{resources.length} منبع در دسترس</span>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm relative group">
         <input 
           type="text" 
           placeholder="جستجو در نام یا توضیحات منابع..." 
           className="w-full pl-4 pr-12 py-3 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-sm dark:text-white focus:ring-2 focus:ring-primary-500 transition-all"
           value={searchTerm}
           onChange={(e) => setSearchTerm(e.target.value)}
         />
         <Search className="absolute right-6 top-7 text-slate-400 group-focus-within:text-primary-500 transition-colors" size={20} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence>
          {filteredResources.map((res, index) => (
            <motion.div 
              key={res.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group flex flex-col h-full"
            >
              <div className="flex items-start justify-between mb-6">
                 <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl group-hover:scale-110 transition-transform shadow-inner">
                   {getIcon(res.type)}
                 </div>
                 <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 px-3 py-1 rounded-full uppercase font-black tracking-widest">{res.type}</span>
              </div>
              
              <div className="flex-1">
                <h3 className="font-black text-lg text-slate-800 dark:text-slate-100 mb-2 line-clamp-1 group-hover:text-primary-600 transition-colors">{res.title}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 line-clamp-3 leading-relaxed font-bold min-h-[3.6rem]">{res.description || 'توضیحات تکمیلی برای این منبع ثبت نشده است.'}</p>
              </div>

              {res.type === 'image' && res.url && (
                <div 
                  onClick={() => setSelectedImage(res.url)}
                  className="mb-6 rounded-2xl overflow-hidden aspect-video bg-slate-50 dark:bg-slate-800 border cursor-pointer hover:opacity-80 transition-opacity"
                >
                   <img src={res.url} alt={res.title} className="w-full h-full object-cover" />
                </div>
              )}

              <a 
                href={res.url} 
                target="_blank" 
                rel="noreferrer"
                className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-xs font-black shadow-lg hover:bg-primary-600 hover:text-white transition-all flex items-center justify-center gap-2"
              >
                 {res.type === 'link' ? <ExternalLink size={16} /> : <Download size={16} />}
                 {res.type === 'link' ? 'مشاهده لینک خارجی' : 'دریافت مستقیم فایل'}
              </a>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filteredResources.length === 0 && (
        <div className="py-40 text-center bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
          <FolderOpen size={64} className="mx-auto text-slate-200 dark:text-slate-800 mb-6" />
          <p className="text-slate-400 font-black text-xl">منبع آموزشی یافت نشد.</p>
        </div>
      )}

      {/* Image Preview Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
            className="fixed inset-0 z-[1000] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-8"
          >
             <button className="absolute top-8 right-8 text-white hover:text-primary-400 transition-colors p-2"><X size={32}/></button>
             <motion.img 
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.9 }}
                src={selectedImage} 
                className="max-w-full max-h-full object-contain rounded-3xl shadow-2xl border border-white/10" 
                onClick={e => e.stopPropagation()}
             />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default StudentResources;
