
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { Grade, Major } from '../types';
import { Search, Plus, Edit, Trash2, GraduationCap, Save, Bookmark, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const AdminEducationStructure: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'grades' | 'majors'>('grades');
  const [grades, setGrades] = useState<Grade[]>(() => storageService.getGrades());
  const [majors, setMajors] = useState<Major[]>(() => storageService.getMajors());
  const [searchTerm, setSearchTerm] = useState('');
  const toast = useToast();
  
  // Sync with Storage
  useEffect(() => { storageService.saveGrades(grades); }, [grades]);
  useEffect(() => { storageService.saveMajors(majors); }, [majors]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<{id: string, title: string} | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ title: '' });

  const filteredItems = activeTab === 'grades' 
    ? grades.filter(g => g.title.includes(searchTerm))
    : majors.filter(m => m.title.includes(searchTerm));

  const handleOpenModal = (item?: {id: string, title: string}) => {
    if (item) {
      setEditingItem(item);
      setFormData({ title: item.title });
    } else {
      setEditingItem(null);
      setFormData({ title: '' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.title) {
      toast.error('عنوان الزامی است.');
      return;
    }

    if (activeTab === 'grades') {
      const newGrade: Grade = { id: editingItem ? editingItem.id : `g_${Date.now()}`, title: formData.title };
      if (editingItem) setGrades(prev => prev.map(g => g.id === editingItem.id ? newGrade : g));
      else setGrades(prev => [...prev, newGrade]);
    } else {
      const newMajor: Major = { id: editingItem ? editingItem.id : `m_${Date.now()}`, title: formData.title };
      if (editingItem) setMajors(prev => prev.map(m => m.id === editingItem.id ? newMajor : m));
      else setMajors(prev => [...prev, newMajor]);
    }

    toast.success(`${activeTab === 'grades' ? 'پایه' : 'رشته'} با موفقیت ذخیره شد.`);
    setIsModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteId) {
      if (activeTab === 'grades') setGrades(prev => prev.filter(g => g.id !== deleteId));
      else setMajors(prev => prev.filter(m => m.id !== deleteId));
      toast.info('آیتم حذف شد.');
      setDeleteId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100">ساختار آموزشی</h1>
           <p className="text-sm text-slate-500 font-bold">مدیریت متمرکز پایه‌ها و رشته‌های تحصیلی</p>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-primary-500/20 transition-all font-bold">
          <Plus size={18} />
          <span>افزودن {activeTab === 'grades' ? 'پایه' : 'رشته'} جدید</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800/50 rounded-2xl w-fit">
        <button 
          onClick={() => { setActiveTab('grades'); setSearchTerm(''); }}
          className={`px-8 py-2.5 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTab === 'grades' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <GraduationCap size={18} /> پایه‌های تحصیلی
        </button>
        <button 
          onClick={() => { setActiveTab('majors'); setSearchTerm(''); }}
          className={`px-8 py-2.5 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTab === 'majors' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <Bookmark size={18} /> رشته‌های تحصیلی
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative">
          <input
            type="text"
            placeholder={`جستجو در ${activeTab === 'grades' ? 'پایه‌ها' : 'رشته‌ها'}...`}
            className="w-full pl-4 pr-10 py-3 bg-slate-50 dark:bg-slate-800 border-none rounded-xl outline-none focus:ring-2 focus:ring-primary-500 font-bold text-black"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute right-3 top-3.5 text-slate-400" size={20} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredItems.map((item) => (
            <motion.div 
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group"
            >
              <div className="flex justify-between items-start mb-4">
                 <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${activeTab === 'grades' ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-600' : 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600'}`}>
                    {activeTab === 'grades' ? <GraduationCap size={24} /> : <Bookmark size={24} />}
                 </div>
                 <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleOpenModal(item)} className="p-2 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"><Edit size={16} /></button>
                    <button onClick={() => setDeleteId(item.id)} className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 size={16} /></button>
                 </div>
              </div>
              <h3 className="text-xl font-black text-slate-800 dark:text-white">{item.title}</h3>
              <p className="text-[10px] text-slate-400 mt-1 font-mono uppercase tracking-widest">{item.id}</p>
            </motion.div>
          ))}
          {filteredItems.length === 0 && (
            <div className="col-span-full py-20 text-center text-slate-400 font-bold border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-[2.5rem]">
              آیتمی برای نمایش یافت نشد.
            </div>
          )}
        </AnimatePresence>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingItem ? 'ویرایش اطلاعات' : 'افزودن مورد جدید'}>
        <div className="p-6 space-y-4">
          <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">عنوان {activeTab === 'grades' ? 'پایه' : 'رشته'}</label>
              <input 
                type="text" 
                value={formData.title}
                onChange={(e) => setFormData({ title: e.target.value })}
                className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-primary-500 font-bold text-black"
                placeholder="مثال: دوازدهم / ریاضی فیزیک"
                autoFocus
              />
          </div>
          <button onClick={handleSave} className="w-full py-4 bg-primary-600 text-white font-black rounded-2xl shadow-xl hover:bg-primary-700 transition-all flex items-center justify-center gap-2">
            <Save size={20} /> ذخیره نهایی
          </button>
        </div>
      </Modal>

      <ConfirmationModal 
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={confirmDelete}
        title="تایید حذف"
        description="آیا مطمئن هستید؟ حذف این مورد ممکن است باعث ایجاد اختلال در دروس و کلاس‌های مرتبط شود."
      />
    </div>
  );
};

export default AdminEducationStructure;
