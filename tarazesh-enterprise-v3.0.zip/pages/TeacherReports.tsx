
import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, BarChart3, Users, Calendar, Filter, 
  Search, ChevronLeft, User as UserIcon, Download, Printer,
  Layers, Target, Award, ShieldCheck, Heart, Star, FileText
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { User, UserRole, ClassEntity } from '../types';
import StudentResults from './StudentResults';
import { motion, AnimatePresence } from 'framer-motion';

const TeacherReports: React.FC = () => {
  const [selectedClassId, setSelectedClassId] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const allClasses = storageService.getClasses();
  const allUsers = storageService.getUsers();

  const classStudents = useMemo(() => {
    if (!selectedClassId) return [];
    const cls = allClasses.find(c => c.id === selectedClassId);
    return allUsers.filter(u => u.role === UserRole.STUDENT && u.class === cls?.title);
  }, [selectedClassId, allClasses, allUsers]);

  const filteredStudents = useMemo(() => {
    return classStudents.filter(s => s.name.includes(searchTerm));
  }, [classStudents, searchTerm]);

  const selectedStudent = useMemo(() => {
    return allUsers.find(u => u.id === selectedStudentId);
  }, [selectedStudentId, allUsers]);

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm transition-all">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
           <h1 className="text-2xl font-black flex items-center gap-4 text-slate-900 dark:text-white">
              <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-2xl flex items-center justify-center text-primary-600">
                <BarChart3 size={28} />
              </div>
              مدیریت کارنامه‌ها و گزارشات تحلیلی
           </h1>
           <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <select 
                className="flex-1 md:w-72 p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-black text-xs outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                value={selectedClassId}
                onChange={e => { setSelectedClassId(e.target.value); setSelectedStudentId(''); }}
              >
                 <option value="">فیلتر بر اساس کلاس...</option>
                 {allClasses.map(c => <option key={c.id} value={c.id}>{c.title} ({c.major})</option>)}
              </select>
           </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!selectedClassId ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-40 text-center bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
             <Target size={80} className="mx-auto text-slate-100 dark:text-slate-800 mb-6" />
             <p className="text-slate-500 dark:text-slate-400 font-black text-2xl">لطفاً ابتدا یک کلاس را از لیست بالا انتخاب کنید.</p>
          </motion.div>
        ) : !selectedStudentId ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
             <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                <div className="relative flex-1">
                   <input 
                     type="text" 
                     placeholder="جستجو در لیست دانش‌آموزان..." 
                     className="w-full pl-4 pr-12 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none text-slate-900 dark:text-white"
                     value={searchTerm}
                     onChange={e => setSearchTerm(e.target.value)}
                   />
                   <Search className="absolute right-4 top-4 text-slate-400" size={24} />
                </div>
             </div>

             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredStudents.map(student => (
                   <div 
                     key={student.id}
                     onClick={() => setSelectedStudentId(student.id)}
                     className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-2xl transition-all cursor-pointer group"
                   >
                      <div className="flex flex-col items-center text-center mb-8">
                         <div className="w-24 h-24 rounded-[2rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-slate-400 overflow-hidden mb-4 border-4 border-white dark:border-slate-700 shadow-xl group-hover:scale-105 transition-transform">
                            {student.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : <UserIcon size={48}/>}
                         </div>
                         <h4 className="font-black text-xl text-slate-900 dark:text-white leading-tight">{student.name}</h4>
                         <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">ID: {student.studentId}</p>
                      </div>
                      <button className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-[10px] uppercase shadow-xl group-hover:bg-primary-600 group-hover:text-white transition-all">مشاهده گزارش نهایی</button>
                   </div>
                ))}
             </div>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="space-y-8">
             <div className="flex justify-between items-center bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                <button onClick={() => setSelectedStudentId('')} className="flex items-center gap-2 text-sm font-black text-slate-600 dark:text-slate-400 hover:text-primary-600 transition-colors">
                   <ChevronLeft className="rotate-180" /> بازگشت به لیست کلاس
                </button>
                <button onClick={() => window.print()} className="px-8 py-3.5 bg-primary-600 text-white rounded-2xl font-black text-xs flex items-center gap-3 shadow-xl">
                   <Printer size={18}/> چاپ گزارش نهایی
                </button>
             </div>
             
             <div className="print:bg-white print:p-0">
               <StudentResults currentUser={selectedStudent!} />
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default TeacherReports;
