
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { generateAIQuestions } from '../services/aiService';
import { Exam, Question, QuestionType, ClassEntity, ExamType, Major, Grade, Course } from '../types';
import { 
  Plus, Trash2, BookOpen, Sparkles, Edit, 
  Loader2, Check, Camera, Zap, 
  ChevronLeft, CheckCircle, Search, Clock, Lock, 
  Activity, ListChecks, Database, FileUp, Image as ImageIcon, 
  ListOrdered, ChevronRight, Settings2, Shield, 
  Layout, ClipboardCheck, Rocket, Info, X,
  Target, FileQuestion, Eye, Layers2, FileText, HelpCircle, Filter, Save, Upload, Star,
  AlertTriangle, ClipboardList, Download, Calendar, Timer, MoreVertical, LayoutGrid, List,
  Users, ArrowRight, Share2, Copy
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';
import { motion, AnimatePresence } from 'framer-motion';
import { compressImage } from '../utils/imageUtils';

// @ts-ignore
import mammoth from 'mammoth';

interface TeacherExamsProps {
  onNavigate: (view: string, data?: any) => void;
}

type AddMethod = 'manual' | 'bank' | 'ai' | 'word' | null;
type Step = 'settings' | 'questions' | 'security';

const TeacherExams: React.FC<TeacherExamsProps> = ({ onNavigate }) => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [classes, setClasses] = useState<ClassEntity[]>([]);
  const [majors, setMajors] = useState<Major[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'archived'>('all');
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState<Step>('settings');
  const [activeAddMethod, setActiveAddMethod] = useState<AddMethod>(null);
  
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [editingExamId, setEditingExamId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isTemplateGuideOpen, setIsTemplateGuideOpen] = useState(false);
  const [editingQuestionIdx, setEditingQuestionIdx] = useState<number | null>(null);

  const toast = useToast();
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const wordInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const [bankFilters, setBankFilters] = useState({ major: '', grade: '', courseId: '', search: '' });

  const [formData, setFormData] = useState<Partial<Exam>>({
    title: '', description: '', durationMinutes: 45, type: ExamType.OFFICIAL,
    forClass: '', questions: [], lockBrowser: true, securityLevel: 'standard',
    rewardXp: 100, requireFaceId: false, status: 'active'
  });

  const [manualQ, setManualQ] = useState<Partial<Question>>({
    text: '', type: QuestionType.MULTIPLE_CHOICE, options: ['', '', '', ''], 
    correctAnswer: 0, points: 1, difficulty: 'medium', image: ''
  });

  const [aiConfig, setAiConfig] = useState({ prompt: '', difficulty: 'medium' as any, count: 5, pdfFile: null as File | null });

  useEffect(() => {
    setExams(storageService.getExams());
    setClasses(storageService.getClasses());
    setMajors(storageService.getMajors());
    setGrades(storageService.getGrades());
    setCourses(storageService.getCourses());
  }, []);

  const availableBankQuestions = useMemo(() => {
    const all = storageService.getQuestions();
    return all.filter(q => {
      const mMatch = !bankFilters.major || q.major === bankFilters.major;
      const gMatch = !bankFilters.grade || q.grade === bankFilters.grade;
      const cMatch = !bankFilters.courseId || q.courseId === bankFilters.courseId;
      const sMatch = !bankFilters.search || q.text.includes(bankFilters.search);
      return mMatch && gMatch && cMatch && sMatch;
    });
  }, [bankFilters]);

  const filteredExamsList = useMemo(() => {
    return exams.filter(e => {
        const matchesSearch = e.title.toLowerCase().includes(searchTerm.toLowerCase()) || e.forClass.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'all' || e.status === statusFilter;
        return matchesSearch && matchesStatus;
    });
  }, [exams, searchTerm, statusFilter]);

  const handleSaveExam = () => {
    if (!formData.title || !formData.forClass) return toast.error('عنوان و کلاس الزامی است.');
    if (!formData.questions || formData.questions.length === 0) return toast.error('آزمون باید حداقل یک سوال داشته باشد.');

    const examToSave: Exam = {
      ...formData as Exam,
      id: editingExamId || `exam_${Date.now()}`,
      status: 'active',
      createdBy: '2', 
      startDate: new Date().toISOString()
    };

    const updated = editingExamId ? exams.map(e => e.id === editingExamId ? examToSave : e) : [examToSave, ...exams];
    setExams(updated);
    storageService.saveExams(updated);
    setIsEditorOpen(false);
    resetForm();
    toast.success('آزمون با موفقیت ثبت شد.');
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', durationMinutes: 45, type: ExamType.OFFICIAL, forClass: '', questions: [], lockBrowser: true, securityLevel: 'standard', rewardXp: 100, requireFaceId: false, status: 'active' });
    setEditingExamId(null);
    setCurrentStep('settings');
    setActiveAddMethod(null);
    setEditingQuestionIdx(null);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, isInline = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await compressImage(file, 500, 0.6); // کاهش رزولوشن برای سرعت بیشتر
      setManualQ(prev => ({ ...prev, image: base64 }));
      toast.success("تصویر ضمیمه شد.");
    }
  };

  const addOrUpdateManualQuestion = () => {
    if (!manualQ.text) return toast.error('متن سوال الزامی است.');
    
    const updatedQuestions = [...(formData.questions || [])];
    if (editingQuestionIdx !== null) {
      updatedQuestions[editingQuestionIdx] = { ...manualQ, id: updatedQuestions[editingQuestionIdx].id } as Question;
      setFormData(p => ({ ...p, questions: updatedQuestions }));
      setEditingQuestionIdx(null);
      toast.success('سوال بروزرسانی شد.');
    } else {
      const newQ = { ...manualQ, id: `q_${Date.now()}` } as Question;
      setFormData(p => ({ ...p, questions: [...updatedQuestions, newQ] }));
      toast.success('سوال اضافه شد.');
    }

    setManualQ({ text: '', type: QuestionType.MULTIPLE_CHOICE, options: ['', '', '', ''], correctAnswer: 0, points: 1, difficulty: 'medium', image: '' });
    setActiveAddMethod(null);
  };

  const startEditQuestion = (idx: number) => {
    const q = formData.questions![idx];
    setManualQ({ ...q });
    setEditingQuestionIdx(idx);
    setActiveAddMethod(null); 
  };

  const handleAiGenerate = async () => {
    if (isAiLoading) return;
    setIsAiLoading(true);
    try {
      let fileData = undefined;
      if (aiConfig.pdfFile) {
        const reader = new FileReader();
        const base64 = await new Promise<string>((resolve) => {
          reader.onload = () => resolve((reader.result as string).split(',')[1]);
          reader.readAsDataURL(aiConfig.pdfFile!);
        });
        fileData = { data: base64, mimeType: aiConfig.pdfFile.type };
      }

      const generated = await generateAIQuestions({
        count: aiConfig.count,
        types: [QuestionType.MULTIPLE_CHOICE, QuestionType.TRUE_FALSE],
        difficulty: aiConfig.difficulty,
        customPrompt: aiConfig.prompt,
        fileData
      });

      if (generated && generated.length > 0) {
        setFormData(prev => ({ ...prev, questions: [...(prev.questions || []), ...generated] }));
        toast.success(`${generated.length} سوال با سرعت بالا تولید شد.`);
        setActiveAddMethod(null);
      } else {
        toast.error("هوش مصنوعی پاسخی دریافت نکرد.");
      }
    } catch (e) {
        toast.error("خطا در پردازش هوشمند.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleWordImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || isImporting) return;
    setIsImporting(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.convertToHtml({ arrayBuffer });
      // محدود کردن متن برای سرعت بیشتر
      const cleanText = result.value.replace(/<[^>]*>?/gm, ' ').substring(0, 10000);
      
      const generated = await generateAIQuestions({
        sourceText: cleanText, 
        count: 10, 
        types: [QuestionType.MULTIPLE_CHOICE],
        difficulty: 'medium',
      });
      if (generated && generated.length > 0) {
        setFormData(prev => ({ ...prev, questions: [...(prev.questions || []), ...generated] }));
        toast.success('سوالات استخراج و آماده شدند.');
        setActiveAddMethod(null);
      }
    } catch(e) { toast.error("خطا در خواندن فایل."); }
    finally { setIsImporting(false); }
  };

  // Fix: Implemented missing downloadSampleTemplate function to handle template download request
  const downloadSampleTemplate = () => {
    toast.info("فایل نمونه در حال آماده‌سازی است. در نسخه دمو، می‌توانید از راهنمای متنی بالا استفاده کنید.");
  };

  const StepperItem = ({ step, label, icon: Icon, active, completed }: { step: Step, label: string, icon: any, active: boolean, completed: boolean }) => (
    <div className="flex flex-col items-center gap-2 flex-1 relative z-10">
       <button 
         onClick={() => setCurrentStep(step)}
         className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
           active ? 'bg-primary-600 text-white shadow-lg scale-110' : completed ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
         }`}
       >
         {completed ? <Check size={20} strokeWidth={3} /> : <Icon size={20} />}
       </button>
       <span className={`text-[10px] font-black uppercase ${active ? 'text-primary-700 dark:text-primary-400' : 'text-slate-500 dark:text-slate-400'}`}>{label}</span>
    </div>
  );

  const renderManualQuestionForm = (isInline = false) => (
    <div className="space-y-6">
       <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-8 space-y-4">
             <div>
               <label className="text-[10px] font-black text-slate-400 block mb-2">متن سوال</label>
               <textarea className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-lg outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" rows={3} value={manualQ.text} onChange={e => setManualQ({...manualQ, text: e.target.value})} placeholder="صورت سوال..." />
             </div>
             
             <div className="flex gap-4">
                 <div className="flex-1">
                     <label className="text-[10px] font-black text-slate-400 block mb-2">نمره سوال (بارم)</label>
                     <input type="number" step="0.25" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-center text-slate-900 dark:text-white shadow-inner" value={manualQ.points} onChange={e => setManualQ({...manualQ, points: parseFloat(e.target.value)})} />
                 </div>
                 <div className="flex-1">
                     <label className="text-[10px] font-black text-slate-400 block mb-2">سطح دشواری</label>
                     <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-white" value={manualQ.difficulty} onChange={e => setManualQ({...manualQ, difficulty: e.target.value as any})}>
                         <option value="easy">آسان</option>
                         <option value="medium">متوسط</option>
                         <option value="hard">سخت</option>
                     </select>
                 </div>
             </div>
          </div>
          <div className="md:col-span-4 space-y-4">
             <div>
               <label className="text-[10px] font-black text-slate-400 block mb-2">نوع سوال</label>
               <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-white" value={manualQ.type} onChange={e => setManualQ({...manualQ, type: e.target.value as any})}>
                  <option value={QuestionType.MULTIPLE_CHOICE}>چهارگزینه‌ای (تستی)</option>
                  <option value={QuestionType.TRUE_FALSE}>صحیح / غلط</option>
                  <option value={QuestionType.DESCRIPTIVE}>تشریحی (جای خالی)</option>
               </select>
             </div>

             <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 block mb-2">تصویر سوال (اختیاری)</label>
                <div onClick={() => imageInputRef.current?.click()} className="h-28 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all overflow-hidden">
                   {manualQ.image ? (
                       <img src={manualQ.image} className="w-full h-full object-cover" />
                   ) : (
                       <>
                           <Upload className="text-slate-300" size={24} />
                           <span className="text-[9px] font-black text-slate-400 mt-2">انتخاب تصویر</span>
                       </>
                   )}
                   <input type="file" ref={imageInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, isInline)} />
                </div>
             </div>
          </div>
       </div>

       {manualQ.type === QuestionType.MULTIPLE_CHOICE && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             {manualQ.options?.map((opt, i) => (
                <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border-2 ${manualQ.correctAnswer === i ? 'border-emerald-500 bg-emerald-50/10' : 'border-slate-100 dark:border-slate-800'}`}>
                   <button onClick={() => setManualQ({...manualQ, correctAnswer: i})} className={`w-6 h-6 rounded-full border-2 flex items-center justify-center font-black ${manualQ.correctAnswer === i ? 'bg-emerald-500 text-white' : 'text-slate-300 dark:text-slate-600'}`}>{i+1}</button>
                   <input className="bg-transparent border-none outline-none font-bold flex-1 text-slate-900 dark:text-white" value={opt} onChange={e => { const n = [...manualQ.options!]; n[i] = e.target.value; setManualQ({...manualQ, options: n}); }} placeholder={`گزینه ${i+1}`} />
                </div>
             ))}
          </div>
       )}

       {manualQ.type === QuestionType.TRUE_FALSE && (
          <div className="flex gap-4">
             <button onClick={() => setManualQ({...manualQ, correctAnswer: true})} className={`flex-1 py-4 rounded-2xl font-black border-2 transition-all ${manualQ.correctAnswer === true ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-50 dark:bg-slate-800 text-slate-400'}`}>صحیح</button>
             <button onClick={() => setManualQ({...manualQ, correctAnswer: false})} className={`flex-1 py-4 rounded-2xl font-black border-2 transition-all ${manualQ.correctAnswer === false ? 'bg-rose-500 text-white shadow-lg' : 'bg-slate-50 dark:bg-slate-800 text-slate-400'}`}>غلط</button>
          </div>
       )}

       {manualQ.type === QuestionType.DESCRIPTIVE && (
          <div className="space-y-2">
             <label className="text-[10px] font-black text-slate-400 block mr-2">پاسخ مرجع / کلید تصحیح</label>
             <textarea className="w-full p-4 bg-emerald-50/10 border-2 border-emerald-500/20 rounded-2xl font-bold text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500" value={manualQ.correctAnswer} onChange={e => setManualQ({...manualQ, correctAnswer: e.target.value})} placeholder="متن پاسخ صحیح یا کلمه کلیدی را بنویسید..." />
          </div>
       )}

       <div className="flex gap-3">
          <button onClick={() => { setActiveAddMethod(null); setEditingQuestionIdx(null); }} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-2xl font-black transition-all">انصراف</button>
          <button onClick={addOrUpdateManualQuestion} className="flex-[3] py-4 bg-primary-600 text-white rounded-2xl font-black shadow-lg hover:bg-primary-700 transition-all flex items-center justify-center gap-2">
             <Check size={20}/> {isInline ? 'ذخیره تغییرات' : 'الحاق سوال به آزمون'}
          </button>
       </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-32 font-sans text-right" dir="rtl">
      {/* Header & Quick Stats */}
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none flex flex-col md:flex-row justify-between items-center gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-primary-500/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
        
        <div className="flex items-center gap-6 relative z-10">
           <div className="w-20 h-20 bg-primary-600 rounded-[2.2rem] flex items-center justify-center text-white shadow-[0_20px_40px_-10px_rgba(0,136,204,0.5)] border-4 border-white dark:border-slate-700">
              <BookOpen size={36} />
           </div>
           <div>
              <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight leading-none">مرکز مدیریت آزمون‌ها</h1>
              <p className="text-sm text-slate-500 font-bold mt-3">طراحی، مانیتورینگ و ارزیابی هوشمند جلسات امتحانی</p>
           </div>
        </div>

        <div className="flex items-center gap-4 relative z-10">
           <div className="hidden lg:flex items-center gap-8 px-8 border-x border-slate-100 dark:border-slate-800">
              <div className="text-center">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">کل آزمون‌ها</p>
                 <p className="text-2xl font-black text-slate-800 dark:text-white">{exams.length}</p>
              </div>
              <div className="text-center">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">جلسات فعال</p>
                 <p className="text-2xl font-black text-emerald-500">{exams.filter(e => e.status === 'active').length}</p>
              </div>
           </div>
           <button onClick={() => { resetForm(); setIsEditorOpen(true); }} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-5 rounded-[2.2rem] flex items-center gap-3 shadow-[0_15px_35px_rgba(0,136,204,0.3)] font-black transition-all hover:scale-105 active:scale-95 border-b-4 border-primary-800 active:border-b-0">
             <Plus size={24} /> طراحی آزمون جدید
           </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-md p-6 rounded-[2.5rem] border border-white dark:border-slate-800 shadow-xl shadow-slate-200/40 dark:shadow-none flex flex-col md:flex-row gap-4 items-center">
         <div className="relative flex-1 w-full group">
            <input 
              type="text" 
              placeholder="جستجو در عنوان آزمون یا کلاس هدف..." 
              className="w-full pl-4 pr-12 py-4 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl outline-none font-bold text-sm text-slate-900 dark:text-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all shadow-inner"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            <Search className="absolute right-4 top-4 text-slate-400 group-focus-within:text-primary-500" size={22} />
         </div>
         <div className="flex gap-2">
            <select 
              className="p-4 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl font-black text-xs text-slate-600 dark:text-slate-300 outline-none cursor-pointer hover:border-primary-400 transition-colors shadow-sm"
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as any)}
            >
               <option value="all">همه وضعیت‌ها</option>
               <option value="active">در حال برگزاری</option>
               <option value="archived">بایگانی شده</option>
            </select>
         </div>
      </div>

      {/* Exams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredExamsList.map((exam, idx) => (
              <motion.div 
                key={exam.id}
                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: idx * 0.05, type: 'spring', stiffness: 200 }}
                className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-2xl hover:-translate-y-2 transition-all group flex flex-col h-full overflow-hidden relative"
              >
                 <div className={`absolute top-0 right-0 w-32 h-32 blur-3xl opacity-10 -mr-16 -mt-16 rounded-full transition-colors ${exam.status === 'active' ? 'bg-emerald-500' : 'bg-slate-500'}`}></div>

                 <div className="p-8 pb-4 flex justify-between items-start relative z-10">
                    <div className={`w-16 h-16 rounded-[1.8rem] flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-500 border-4 border-white dark:border-slate-800 ${exam.status === 'active' ? 'bg-emerald-500 text-white shadow-emerald-500/20' : 'bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-500 shadow-slate-400/10'}`}>
                       {exam.status === 'active' ? <Zap size={32} /> : <Database size={32} />}
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all transform translate-x-4 group-hover:translate-x-0">
                       <button onClick={() => onNavigate('teacher_live_monitor', exam.id)} className="p-3 text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl hover:bg-emerald-500 hover:text-white transition-all shadow-sm" title="مانیتورینگ زنده"><Activity size={20}/></button>
                       <button onClick={() => onNavigate('teacher_grading', exam.id)} className="p-3 text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl hover:bg-indigo-500 hover:text-white transition-all shadow-sm" title="تصحیح و نمرات"><ClipboardCheck size={20}/></button>
                       <button onClick={() => { setEditingExamId(exam.id); setFormData({...exam}); setIsEditorOpen(true); }} className="p-3 text-blue-500 bg-blue-50 dark:bg-blue-950/40 rounded-xl hover:bg-blue-500 hover:text-white transition-all shadow-sm" title="ویرایش"><Edit size={20}/></button>
                       <button onClick={() => setDeleteId(exam.id)} className="p-3 text-rose-500 bg-rose-50 dark:bg-rose-950/40 rounded-xl hover:bg-rose-500 hover:text-white transition-all shadow-sm" title="حذف"><Trash2 size={20}/></button>
                    </div>
                 </div>

                 <div className="p-8 pt-0 flex-1 space-y-4 relative z-10">
                    <div className="flex items-center gap-2">
                       <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-lg border tracking-widest shadow-sm ${exam.type === ExamType.OFFICIAL ? 'bg-rose-500 text-white border-rose-600' : 'bg-indigo-500 text-white border-indigo-600'}`}>
                          {exam.type === ExamType.OFFICIAL ? 'رسمی' : 'تمرینی'}
                       </span>
                       <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-lg border tracking-widest shadow-sm bg-white dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700`}>
                          {exam.status === 'active' ? 'در حال اجرا' : 'بایگانی'}
                       </span>
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 dark:text-white leading-snug line-clamp-2 h-16 group-hover:text-primary-600 transition-colors">{exam.title}</h3>
                    
                    <div className="grid grid-cols-2 gap-4 pt-4">
                       <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-[1.8rem] border border-slate-100 dark:border-slate-800 shadow-inner group-hover:bg-white dark:group-hover:bg-slate-800 transition-all">
                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-2">کلاس هدف</p>
                          <div className="flex items-center gap-2">
                             <div className="w-6 h-6 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600"><Users size={12} /></div>
                             <span className="text-xs font-black text-slate-700 dark:text-slate-200">{exam.forClass}</span>
                          </div>
                       </div>
                       <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-[1.8rem] border border-slate-100 dark:border-slate-800 shadow-inner group-hover:bg-white dark:group-hover:bg-slate-800 transition-all">
                          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-2">محتوای علمی</p>
                          <div className="flex items-center gap-2">
                             <div className="w-6 h-6 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600"><ListOrdered size={12} /></div>
                             <span className="text-xs font-black text-slate-700 dark:text-slate-200">{exam.questions.length} سوال</span>
                          </div>
                       </div>
                    </div>
                 </div>

                 <div className="p-6 bg-slate-50/50 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center mt-auto relative z-10">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
                       <Timer size={16} className="text-slate-400" />
                       <span className="text-[11px] font-black text-slate-600 dark:text-slate-300 uppercase tracking-tighter">{exam.durationMinutes} دقیقه</span>
                    </div>
                    <button 
                      onClick={() => onNavigate('teacher_live_monitor', exam.id)} 
                      className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 rounded-2xl font-black text-[10px] uppercase shadow-lg shadow-primary-500/20 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border-b-2 border-primary-800 active:border-b-0"
                    >
                      مانیتورینگ <ArrowRight size={14} />
                    </button>
                 </div>
                 <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 group-hover:translate-x-full transition-all duration-1000 -skew-x-12"></div>
              </motion.div>
            ))}
          </AnimatePresence>

          {filteredExamsList.length === 0 && (
            <div className="col-span-full py-40 text-center border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[4rem] bg-white/30 dark:bg-slate-900/30">
               <div className="relative inline-block mb-6">
                  <BookOpen size={100} className="text-slate-200 dark:text-slate-800" />
                  <div className="absolute inset-0 flex items-center justify-center"><Search size={32} className="text-slate-300 dark:text-slate-600 animate-bounce" /></div>
               </div>
               <p className="text-slate-400 font-black text-2xl tracking-tight">هنوز آزمونی طراحی نکرده‌اید یا فیلتر فعلی نتیجه‌ای ندارد.</p>
               <button onClick={() => { resetForm(); setIsEditorOpen(true); }} className="mt-8 px-8 py-3 bg-primary-600 text-white rounded-2xl font-black text-sm shadow-xl hover:scale-105 transition-all">ایجاد اولین آزمون</button>
            </div>
          )}
      </div>

      <Modal isOpen={isEditorOpen} onClose={() => setIsEditorOpen(false)} title={<span className="font-black flex items-center gap-3"><Settings2 size={24} className="text-primary-500"/> میز کار طراحی آزمون هوشمند</span>} maxWidth="max-w-6xl" className="!p-0">
         <div className="flex flex-col h-[85vh] bg-slate-50 dark:bg-slate-950/50">
            {/* Stepper */}
            <div className="bg-white dark:bg-slate-900 px-10 py-6 border-b border-slate-100 dark:border-slate-800 shadow-sm relative z-10">
               <div className="flex justify-between max-w-xl mx-auto relative">
                  <div className="absolute top-6 left-0 right-0 h-0.5 bg-slate-100 dark:bg-slate-800 -z-0"></div>
                  <StepperItem step="settings" label="تنظیمات" icon={Layout} active={currentStep === 'settings'} completed={currentStep !== 'settings'} />
                  <StepperItem step="questions" label="طراحی محتوا" icon={ListOrdered} active={currentStep === 'questions'} completed={currentStep === 'security'} />
                  <StepperItem step="security" label="امنیت" icon={Shield} active={currentStep === 'security'} completed={false} />
               </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar p-10">
               <AnimatePresence mode="wait">
                  {currentStep === 'settings' && (
                    <motion.div key="settings" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="max-w-3xl mx-auto space-y-8">
                       <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] shadow-xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800 space-y-8">
                          <h3 className="font-black text-xl text-slate-900 dark:text-white border-r-4 border-primary-500 pr-4">اطلاعات شناسنامه‌ای</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase mr-2 tracking-widest block text-right">عنوان آزمون</label>
                                <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="مثال: فیزیک دوازدهم - ترم اول" />
                             </div>
                             <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase mr-2 tracking-widest block text-right">کلاس هدف</label>
                                <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner appearance-none cursor-pointer" value={formData.forClass} onChange={e => setFormData({...formData, forClass: e.target.value})}>
                                   <option value="">انتخاب کلاس...</option>
                                   {classes.map(c => <option key={c.id} value={c.title}>{c.title}</option>)}
                                </select>
                             </div>
                          </div>
                          <div className="grid grid-cols-2 gap-6">
                             <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase mr-2 text-right block">زمان (دقیقه)</label>
                                <input type="number" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-center text-xl text-slate-900 dark:text-white shadow-inner" value={formData.durationMinutes} onChange={e => setFormData({...formData, durationMinutes: parseInt(e.target.value)})} />
                             </div>
                             <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase mr-2 text-right block">پاداش (XP)</label>
                                <input type="number" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-center text-xl text-slate-900 dark:text-white shadow-inner" value={formData.rewardXp} onChange={e => setFormData({...formData, rewardXp: parseInt(e.target.value)})} />
                             </div>
                          </div>
                       </div>
                    </motion.div>
                  )}

                  {currentStep === 'questions' && (
                    <motion.div key="questions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                       <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                          {[
                            { id: 'manual', label: 'درج سوال دستی', icon: Plus, color: 'text-primary-600', bg: 'bg-primary-50 dark:bg-primary-900/20' },
                            { id: 'bank', label: 'انتخاب از بانک', icon: Database, color: 'text-indigo-600', bg: 'bg-indigo-50 dark:bg-indigo-900/20' },
                            { id: 'ai', label: 'هوش مصنوعی (PDF)', icon: Sparkles, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
                            { id: 'word', label: 'فراخوانی Word', icon: FileUp, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20' }
                          ].map(method => (
                            <button 
                              key={method.id} 
                              onClick={() => { setActiveAddMethod(method.id as AddMethod); setEditingQuestionIdx(null); }}
                              className={`p-8 rounded-[2.5rem] border-2 transition-all flex flex-col items-center gap-4 group ${activeAddMethod === method.id ? 'border-primary-500 bg-white dark:bg-slate-900 shadow-2xl scale-105' : 'border-transparent bg-white dark:bg-slate-900 hover:border-slate-200 dark:hover:border-slate-700 shadow-lg shadow-slate-200/50 dark:shadow-none'}`}
                            >
                               <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform ${method.bg} ${method.color}`}>
                                  <method.icon size={32} />
                                </div>
                                <span className="font-black text-[12px] uppercase tracking-widest text-slate-900 dark:text-white">{method.label}</span>
                            </button>
                          ))}
                       </div>

                       {/* Forms Container */}
                       <AnimatePresence mode="wait">
                          {activeAddMethod === 'manual' && (
                             <motion.div initial={{ height: 0, opacity: 0, scale: 0.95 }} animate={{ height: 'auto', opacity: 1, scale: 1 }} exit={{ height: 0, opacity: 0, scale: 0.95 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border-2 border-primary-500 shadow-2xl space-y-6 overflow-hidden">
                                <div className="flex justify-between items-center">
                                    <h4 className="font-black text-primary-600 flex items-center gap-3 text-lg">
                                        <Plus size={24}/> ورود دستی سوال جدید
                                    </h4>
                                    <button onClick={()=>{setActiveAddMethod(null);}} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><X size={24}/></button>
                                </div>
                                {renderManualQuestionForm(false)}
                             </motion.div>
                          )}

                          {activeAddMethod === 'bank' && (
                             <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border-2 border-indigo-500 shadow-2xl space-y-6 overflow-hidden">
                                <div className="flex justify-between items-center"><h4 className="font-black text-indigo-600 flex items-center gap-3 text-lg"><Database size={24}/> انتخاب از بانک سوالات متمرکز</h4><button onClick={()=>setActiveAddMethod(null)}><X size={24}/></button></div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/50 p-6 rounded-[2.2rem] border border-slate-100 dark:border-slate-800">
                                   <select className="p-4 bg-white dark:bg-slate-800 rounded-2xl text-xs font-black text-slate-900 dark:text-white border-none shadow-sm" value={bankFilters.major} onChange={e => setBankFilters({...bankFilters, major: e.target.value})}>
                                      <option value="">همه رشته‌ها</option>
                                      {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                                   </select>
                                   <select className="p-4 bg-white dark:bg-slate-800 rounded-2xl text-xs font-black text-slate-900 dark:text-white border-none shadow-sm" value={bankFilters.grade} onChange={e => setBankFilters({...bankFilters, grade: e.target.value})}>
                                      <option value="">همه پایه‌ها</option>
                                      {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
                                   </select>
                                   <select className="p-4 bg-white dark:bg-slate-800 rounded-2xl text-xs font-black text-slate-900 dark:text-white border-none shadow-sm" value={bankFilters.courseId} onChange={e => setBankFilters({...bankFilters, courseId: e.target.value})}>
                                      <option value="">همه درس‌ها</option>
                                      {courses.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                                   </select>
                                   <div className="relative md:col-span-3 mt-2">
                                      <input className="w-full p-4 pr-12 bg-white dark:bg-slate-800 rounded-2xl text-xs font-black outline-none border-none text-slate-900 dark:text-white shadow-inner" placeholder="جستجو در سوالات..." value={bankFilters.search} onChange={e => setBankFilters({...bankFilters, search: e.target.value})} />
                                      <Search className="absolute right-4 top-4 text-slate-400" size={20}/>
                                   </div>
                                </div>
                                <div className="max-h-80 overflow-y-auto custom-scrollbar space-y-3 pr-2">
                                   {availableBankQuestions.map(q => (
                                      <div key={q.id} className="p-5 bg-slate-50 dark:bg-slate-800 rounded-2xl flex justify-between items-center group border-2 border-transparent hover:border-indigo-400 hover:bg-white transition-all shadow-sm">
                                         <p className="text-sm font-black text-slate-800 dark:text-slate-200 line-clamp-1">{q.text}</p>
                                         <button onClick={() => { setFormData(p => ({ ...p, questions: [...(p.questions || []), q] })); toast.success("به آزمون اضافه شد."); }} className="p-3 bg-indigo-600 text-white rounded-xl hover:scale-110 transition-all shadow-lg shadow-indigo-600/20"><Plus size={18}/></button>
                                      </div>
                                   ))}
                                </div>
                             </motion.div>
                          )}

                          {activeAddMethod === 'ai' && (
                             <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border-2 border-emerald-500 shadow-2xl space-y-6 overflow-hidden">
                                <div className="flex justify-between items-center">
                                    <h4 className="font-black text-emerald-600 flex items-center gap-3 text-lg"><Sparkles size={24}/> هوش مصنوعی طراح آزمون هوشمند</h4>
                                    <button onClick={()=>setActiveAddMethod(null)}><X size={24}/></button>
                                </div>
                                <div className="space-y-6">
                                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                      <div className="space-y-2 text-right">
                                         <label className="text-[10px] font-black text-slate-400 block mr-2">پرامپت / موضوع تخصصی</label>
                                         <textarea className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white shadow-inner" rows={3} value={aiConfig.prompt} onChange={e => setAiConfig({...aiConfig, prompt: e.target.value})} placeholder="مثال: ۵ سوال ترکیبی از مبحث کانتوم فیزیک..." />
                                      </div>
                                      <div className="space-y-2 text-right">
                                         <label className="text-[10px] font-black text-slate-400 block mr-2">منبع درسی (PDF)</label>
                                         <div onClick={() => pdfInputRef.current?.click()} className="border-4 border-dashed border-emerald-100 dark:border-emerald-900/30 rounded-[2.5rem] p-10 text-center cursor-pointer hover:bg-emerald-50/10 hover:border-emerald-500 transition-all flex flex-col items-center justify-center group">
                                            <FileText className="text-emerald-500 mb-3 group-hover:scale-125 transition-transform" size={48} />
                                            <p className="text-[11px] font-black text-slate-500">{aiConfig.pdfFile ? aiConfig.pdfFile.name : 'آپلود فایل PDF منبع'}</p>
                                            <input type="file" ref={pdfInputRef} className="hidden" accept=".pdf" onChange={e => setAiConfig({...aiConfig, pdfFile: e.target.files?.[0] || null})} />
                                         </div>
                                      </div>
                                   </div>
                                   <div className="flex gap-4">
                                      <select className="flex-1 p-5 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-black text-slate-900 dark:text-white shadow-inner" value={aiConfig.difficulty} onChange={e => setAiConfig({...aiConfig, difficulty: e.target.value as any})}>
                                         <option value="easy">آسان</option><option value="medium">متوسط</option><option value="hard">سخت</option>
                                      </select>
                                      <button onClick={handleAiGenerate} disabled={isAiLoading} className="flex-[3] py-5 bg-emerald-600 text-white rounded-2xl font-black shadow-[0_15px_30px_rgba(16,185,129,0.3)] flex items-center justify-center gap-3 disabled:opacity-50 hover:scale-[1.02] transition-all">
                                         {isAiLoading ? <Loader2 className="animate-spin" /> : <><Sparkles size={24}/> استخراج و تولید سوالات هوشمند</>}
                                      </button>
                                   </div>
                                </div>
                             </motion.div>
                          )}

                          {activeAddMethod === 'word' && (
                             <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border-2 border-amber-500 shadow-2xl space-y-6 overflow-hidden">
                                <div className="flex justify-between items-center">
                                   <h4 className="font-black text-amber-600 flex items-center gap-3 text-lg"><FileUp size={24}/> استخراج سوالات از Word</h4>
                                   <div className="flex gap-4">
                                      <button onClick={() => setIsTemplateGuideOpen(true)} className="p-2.5 text-slate-400 hover:text-amber-500 flex items-center gap-2 font-black text-xs uppercase"><HelpCircle size={18}/> راهنمای قالب</button>
                                      <button onClick={()=>setActiveAddMethod(null)}><X size={24}/></button>
                                   </div>
                                </div>
                                <div className="border-4 border-dashed border-slate-100 dark:border-slate-800 p-20 rounded-[3rem] text-center cursor-pointer hover:border-amber-500 hover:bg-amber-50/5 transition-all group" onClick={() => wordInputRef.current?.click()}>
                                   <FileUp className="mx-auto text-slate-200 dark:text-slate-800 mb-6 group-hover:scale-125 transition-transform" size={80}/>
                                   <p className="text-slate-500 font-black text-xl">{isImporting ? 'در حال تحلیل...' : 'فایل Word حاوی سوالات را انتخاب کنید'}</p>
                                   <input type="file" ref={wordInputRef} className="hidden" accept=".docx" onChange={handleWordImport} />
                                </div>
                             </motion.div>
                          )}
                       </AnimatePresence>

                       {/* Questions List */}
                       <div className="space-y-6">
                          <h3 className="font-black text-xl flex items-center gap-3 px-4 text-slate-900 dark:text-white"><ListOrdered className="text-primary-500" /> سوالات الحاق شده ({formData.questions?.length})</h3>
                          
                          {formData.questions?.length === 0 ? (
                             <div className="py-24 text-center bg-white/50 dark:bg-slate-900/30 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[4rem] text-slate-400 font-bold flex flex-col items-center gap-6 shadow-inner">
                                <Layers2 size={64} className="opacity-20"/> هنوزهیچ سوالی به این آزمون اضافه نشده است.
                             </div>
                          ) : (
                             <div className="space-y-4">
                                {formData.questions?.map((q, idx) => (
                                   <motion.div layout key={q.id || idx} className="overflow-hidden">
                                      <AnimatePresence mode="wait" initial={false}>
                                        {editingQuestionIdx === idx ? (
                                            <motion.div 
                                              key="edit-form"
                                              initial={{ opacity: 0, height: 0 }}
                                              animate={{ opacity: 1, height: 'auto' }}
                                              exit={{ opacity: 0, height: 0 }}
                                              transition={{ duration: 0.1 }}
                                              className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border-2 border-primary-500 shadow-2xl overflow-hidden mb-6"
                                            >
                                                <div className="flex justify-between items-center mb-8">
                                                    <h4 className="font-black text-primary-600 flex items-center gap-3 text-lg">
                                                        <Edit size={24}/> ویرایش درون‌خطی سوال
                                                    </h4>
                                                </div>
                                                {renderManualQuestionForm(true)}
                                            </motion.div>
                                        ) : (
                                            <motion.div 
                                              key="view-summary"
                                              initial={{ opacity: 0, x: -30 }}
                                              animate={{ opacity: 1, x: 0 }}
                                              exit={{ opacity: 0, x: 30 }}
                                              className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-none flex justify-between items-center group hover:border-primary-400 transition-all hover:-translate-x-2"
                                            >
                                              <div className="flex items-center gap-6 text-right">
                                                <span className="w-12 h-12 rounded-[1.2rem] bg-slate-50 dark:bg-slate-800 flex items-center justify-center shrink-0 font-black text-slate-400 dark:text-slate-600 shadow-inner group-hover:bg-primary-500 group-hover:text-white transition-colors">{idx+1}</span>
                                                {q.image && <div className="w-16 h-16 rounded-[1.2rem] overflow-hidden bg-slate-100 shrink-0 border-2 border-white shadow-md"><img src={q.image} className="w-full h-full object-cover" /></div>}
                                                <div className="min-w-0">
                                                    <p className="font-black text-lg text-slate-900 dark:text-slate-100 line-clamp-1 group-hover:text-primary-600 transition-colors">{q.text}</p>
                                                    <div className="flex gap-3 mt-2">
                                                        <span className="text-[9px] font-black uppercase text-primary-600 bg-primary-50 dark:bg-primary-900/20 px-3 py-1 rounded-lg border border-primary-100">{q.type}</span>
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-[9px] font-black text-slate-400 uppercase bg-slate-50 px-3 py-1 rounded-lg">بارم: {q.points}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                              </div>
                                              <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                                  <button onClick={() => startEditQuestion(idx)} className="p-4 text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 rounded-2xl hover:bg-indigo-500 hover:text-white transition-all shadow-sm" title="ویرایش سوال"><Edit size={22}/></button>
                                                  <button onClick={() => setFormData(p => ({ ...p, questions: p.questions?.filter((_, i) => i !== idx) }))} className="p-4 text-rose-500 bg-rose-50 dark:bg-rose-950/40 rounded-2xl hover:bg-rose-500 hover:text-white transition-all shadow-sm" title="حذف سوال"><Trash2 size={22}/></button>
                                              </div>
                                            </motion.div>
                                        )}
                                      </AnimatePresence>
                                   </motion.div>
                                ))}
                             </div>
                          )}
                       </div>
                    </motion.div>
                  )}

                  {currentStep === 'security' && (
                    <motion.div key="security" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-2xl mx-auto space-y-8">
                       <div className="bg-slate-900 rounded-[3.5rem] p-12 text-white shadow-2xl space-y-8 border border-white/5 relative overflow-hidden">
                          <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500 opacity-5 blur-[100px]"></div>
                          <h3 className="text-2xl font-black mb-8 flex items-center gap-4 border-r-4 border-amber-500 pr-6 uppercase tracking-tighter"><Shield className="text-amber-500" /> پروتکل‌های امنیتی هوشمند</h3>
                          <div className="flex items-center justify-between p-8 bg-white/5 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all group">
                             <div className="text-right flex items-center gap-4">
                                <div className="p-3 bg-white/5 rounded-2xl text-primary-400 group-hover:scale-110 transition-transform"><Lock size={28}/></div>
                                <div><h4 className="font-black text-lg">قفل مرورگر (Proctoring)</h4><p className="text-[11px] text-slate-400 mt-1 font-bold">جلوگیری از خروج از زبانه آزمون و ثبت تقلب</p></div>
                             </div>
                             <button onClick={() => setFormData({...formData, lockBrowser: !formData.lockBrowser})} className={`w-16 h-8 rounded-full relative transition-all shadow-inner ${formData.lockBrowser ? 'bg-primary-500' : 'bg-slate-700'}`}><div className={`absolute top-1 w-6 h-6 rounded-full bg-white shadow-lg transition-all ${formData.lockBrowser ? 'left-1' : 'left-9'}`} /></button>
                          </div>
                          <div className="flex items-center justify-between p-8 bg-white/5 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all group">
                             <div className="text-right flex items-center gap-4">
                                <div className="p-3 bg-white/5 rounded-2xl text-emerald-400 group-hover:scale-110 transition-transform"><Camera size={28}/></div>
                                <div><h4 className="font-black text-lg">تایید هویت بیومتریک (Face ID)</h4><p className="text-[11px] text-slate-400 mt-1 font-bold">الزام اسکن چهره پیش از شروع فرآیند آزمون</p></div>
                             </div>
                             <button onClick={() => setFormData({...formData, requireFaceId: !formData.requireFaceId})} className={`w-16 h-8 rounded-full relative transition-all shadow-inner ${formData.requireFaceId ? 'bg-emerald-500' : 'bg-slate-700'}`}><div className={`absolute top-1 w-6 h-6 rounded-full bg-white shadow-lg transition-all ${formData.requireFaceId ? 'left-1' : 'left-9'}`} /></button>
                          </div>
                       </div>
                       
                       <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xl shadow-slate-200/50 dark:shadow-none hover:border-primary-400 transition-all">
                          <div className="text-right"><h4 className="font-black text-xl text-slate-900 dark:text-white">پیش‌نمایش نهایی</h4><p className="text-sm text-slate-500 font-bold">مشاهده محیط آزمون از دید هنرجو جهت تست نهایی</p></div>
                          <button onClick={() => onNavigate('student_exam_preview', formData)} className="px-10 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-950 rounded-[1.8rem] font-black text-xs flex items-center gap-3 shadow-2xl hover:scale-105 active:scale-95 transition-all">
                             <Eye size={20} /> مشاهده آزمون آزمایشی
                          </button>
                       </div>
                    </motion.div>
                  )}
               </AnimatePresence>
            </div>

            {/* Wizard Footer */}
            <div className="p-8 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center px-12 shadow-[0_-10px_30px_rgba(0,0,0,0.02)]">
               <div className="flex gap-4">
                  {currentStep !== 'settings' && <button onClick={() => setCurrentStep(currentStep === 'questions' ? 'settings' : 'questions')} className="text-slate-500 font-black text-sm uppercase flex items-center gap-2 hover:text-primary-600 transition-all px-6 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800"><ChevronRight size={20}/> مرحله قبلی</button>}
               </div>
               <button onClick={currentStep === 'security' ? handleSaveExam : () => setCurrentStep(currentStep === 'settings' ? 'questions' : 'security')} className={`px-16 py-5 rounded-[2.2rem] font-black text-lg shadow-2xl flex items-center gap-4 transition-all hover:scale-105 active:scale-95 border-b-4 active:border-b-0 ${currentStep === 'security' ? 'bg-emerald-600 text-white shadow-emerald-500/30 border-emerald-800' : 'bg-primary-600 text-white shadow-primary-500/30 border-primary-800'}`}>
                  {currentStep === 'security' ? <><Rocket size={28}/> تایید و انتشار نهایی</> : <>گام بعدی طراحی <ChevronLeft size={28}/></>}
               </button>
            </div>
         </div>
      </Modal>

      {/* راهنمای جامع مطابق تصویر */}
      <Modal isOpen={isTemplateGuideOpen} onClose={() => setIsTemplateGuideOpen(false)} title={<span className="flex items-center gap-3"><HelpCircle size={24}/> راهنمای جامع قالب سوالات (Word/Excel)</span>} maxWidth="max-w-4xl">
         <div className="p-8 space-y-8 text-right font-sans">
            <div className="bg-indigo-50 dark:bg-indigo-900/20 p-8 rounded-[3rem] border-r-8 border-indigo-500 flex items-start gap-6 relative overflow-hidden shadow-inner">
                <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
                <div className="w-16 h-16 bg-white dark:bg-slate-800 rounded-[1.8rem] flex items-center justify-center text-indigo-600 shadow-xl shrink-0"><Star size={36} fill="currentColor" /></div>
                <div>
                    <h4 className="font-black text-indigo-950 dark:text-white text-xl mb-2">ساختار استاندارد ترازش</h4>
                    <p className="text-sm font-bold text-indigo-800 dark:text-indigo-300 leading-relaxed">
                        جهت فراخوانی هوشمند، سوالات خود را دقیقاً طبق جدول زیر در یک فایل Word تنظیم کنید. هوش مصنوعی ترازش ستون‌ها را به صورت خودکار شناسایی و سوالات را استخراج می‌کند.
                    </p>
                </div>
            </div>

            <div className="overflow-hidden rounded-[3rem] border-4 border-slate-100 dark:border-slate-800 shadow-2xl bg-white dark:bg-slate-900">
               <table className="w-full text-[13px] font-bold text-slate-800 dark:text-white border-collapse">
                  <thead className="bg-slate-950 text-white">
                     <tr>
                        <th className="p-6 text-center border-l border-white/10">ردیف</th>
                        <th className="p-6 text-center border-l border-white/10">نوع سوال</th>
                        <th className="p-6 text-right border-l border-white/10">متن سوال</th>
                        <th className="p-6 text-right border-l border-white/10">گزینه‌ها (با کاما)</th>
                        <th className="p-6 text-center border-l border-white/10">جواب صحیح</th>
                        <th className="p-6 text-center">نمره</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                     <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                        <td className="p-5 text-center font-mono text-primary-600">1</td>
                        <td className="p-5 text-center"><span className="px-4 py-1.5 bg-primary-50 text-primary-600 rounded-xl text-[10px] font-black uppercase border border-primary-100">تستی</span></td>
                        <td className="p-5 text-right font-black">پایتخت ایران کدام شهر است؟</td>
                        <td className="p-5 text-right text-slate-400 font-bold">تهران، شیراز، اصفهان، تبریز</td>
                        <td className="p-5 text-center font-black bg-emerald-50/30">1</td>
                        <td className="p-5 text-center text-emerald-600 font-black">1.5</td>
                     </tr>
                     <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                        <td className="p-5 text-center font-mono text-primary-600">2</td>
                        <td className="p-5 text-center"><span className="px-4 py-1.5 bg-amber-50 text-amber-600 rounded-xl text-[10px] font-black uppercase border border-amber-100">صحیح/غلط</span></td>
                        <td className="p-5 text-right font-black">پایتخت ایران تهران است.</td>
                        <td className="p-5 text-right text-slate-300">-</td>
                        <td className="p-5 text-center font-black bg-emerald-50/30">صحیح</td>
                        <td className="p-5 text-center text-emerald-600 font-black">1</td>
                     </tr>
                     <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                        <td className="p-5 text-center font-mono text-primary-600">3</td>
                        <td className="p-5 text-center"><span className="px-4 py-1.5 bg-purple-50 text-purple-600 rounded-xl text-[10px] font-black uppercase border border-purple-100">جای خالی</span></td>
                        <td className="p-5 text-right font-black">پایتخت ایران شهر ....... است.</td>
                        <td className="p-5 text-right text-slate-300">-</td>
                        <td className="p-5 text-center font-black bg-emerald-50/30">تهران</td>
                        <td className="p-5 text-center text-emerald-600 font-black">2</td>
                     </tr>
                  </tbody>
               </table>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-8 bg-slate-50 dark:bg-slate-800/50 rounded-[2.5rem] border border-slate-200 dark:border-slate-700 flex gap-6 shadow-inner">
                    <Info className="text-primary-500 shrink-0" size={32}/>
                    <div className="text-[12px] font-bold text-slate-600 dark:text-slate-400 space-y-4">
                        <p>• در سوالات تستی، ستون گزینه‌ها باید با کاما (،) از هم جدا شوند.</p>
                        <p>• در ستون جواب صحیح سوالات تستی، شماره گزینه (۱ تا ۴) را بنویسید.</p>
                    </div>
                </div>
                <div className="p-8 bg-slate-50 dark:bg-slate-800/50 rounded-[2.5rem] border border-slate-200 dark:border-slate-700 flex gap-6 shadow-inner">
                    <AlertTriangle className="text-amber-500 shrink-0" size={32}/>
                    <div className="text-[12px] font-bold text-slate-600 dark:text-slate-400 space-y-4">
                        <p>• برای سوالات صحیح/غلط حتماً از کلمات "صحیح" یا "غلط" استفاده کنید.</p>
                        <p>• نمرات را می‌توانید به صورت اعشاری (مثلاً 0.75) وارد نمایید.</p>
                    </div>
                </div>
            </div>

            <button onClick={downloadSampleTemplate} className="w-full py-6 bg-slate-900 text-white dark:bg-white dark:text-slate-950 rounded-[2.5rem] font-black flex items-center justify-center gap-4 shadow-2xl transition-all hover:scale-[1.02] hover:bg-slate-800">
                <Download size={24} /> دریافت فایل قالب نمونه (Sample Docx)
            </button>
         </div>
      </Modal>

      <ConfirmationModal isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={() => { setExams(exams.filter(e=>e.id!==deleteId)); storageService.saveExams(exams.filter(e=>e.id!==deleteId)); setDeleteId(null); }} title="حذف دائمی آزمون" description="آیا از حذف این آزمون اطمینان دارید؟ تمامی سوابق مرتبط، نمرات و لاگ‌های امنیتی هنرجویان نیز به صورت غیرقابل بازگشت پاک خواهند شد." />
    </div>
  );
};

export default TeacherExams;
