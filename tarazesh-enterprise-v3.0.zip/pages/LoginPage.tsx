
import React, { useState, useEffect, useMemo } from 'react';
import { UserRole, User, Quote as QuoteType, Major, Grade } from '../types';
import { 
  Lock, User as UserIcon, Book, 
  Camera, Check, Quote as QuoteIcon, UserPlus,
  ArrowLeft, ChevronRight, RefreshCw, ShieldCheck, HelpCircle
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import { storageService } from '../services/storageService';
import Modal from '../components/Modal';
import BrandLogo from '../components/BrandLogo';

const PRESET_AVATARS = [
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka",
  "https://api.dicebear.com/7.x/milo/svg?seed=Milo",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Luna",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Buster",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Ginger",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Oliver",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Molly",
  "https://api.dicebear.com/7.x/sam/svg?seed=Sam",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Kiki",
  "https://api.dicebear.com/7.x/max/svg?seed=Max",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Daisy",
];

interface LoginPageProps {
  onLogin: (userData: any, token: string) => void;
  onForgotPassword: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onForgotPassword }) => {
  const [activeTab, setActiveTab] = useState<UserRole>(UserRole.STUDENT);
  const [showHiddenTabs, setShowHiddenTabs] = useState(false);
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isAvatarPickerOpen, setIsAvatarPickerOpen] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(PRESET_AVATARS[0]);
  const [quoteIndex, setQuoteIndex] = useState(0);
  
  const [majors, setMajors] = useState<Major[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  
  const toast = useToast();
  
  const [formData, setFormData] = useState({
    name: '',
    family: '',
    identifier: '',
    password: '',
    grade: '',
    major: ''
  });

  const settings = storageService.getSettings();
  const quotes = useMemo<QuoteType[]>(() => {
    const list = settings.branding.quotes || [];
    return list.length > 0 ? list : [{ id: 'default', text: 'آموزش پلی است میان رویاها و واقعیت.', author: 'ترازش' }];
  }, [settings.branding.quotes]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key.toLowerCase() === 'q') {
        e.preventDefault();
        setShowHiddenTabs(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    setMajors(storageService.getMajors());
    setGrades(storageService.getGrades());
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (quotes.length <= 1) {
      setQuoteIndex(0);
      return;
    }
    const interval = setInterval(() => {
      setQuoteIndex((prev) => (prev + 1) % quotes.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [quotes]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const allUsers = storageService.getUsers();
    const foundUser = allUsers.find(u => {
        const idMatch = u.studentId === formData.identifier || u.username === formData.identifier;
        const passMatch = u.password === formData.password;
        
        let roleMatch = false;
        if (activeTab === UserRole.STUDENT) roleMatch = u.role === UserRole.STUDENT;
        else if (activeTab === UserRole.TEACHER) roleMatch = u.role === UserRole.TEACHER;
        else if (activeTab === UserRole.ADMIN) roleMatch = [UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.DEVELOPER].includes(u.role);
          
        return idMatch && passMatch && roleMatch;
    });

    if (foundUser) onLogin(foundUser, "JWT_AUTH_TOKEN_" + Date.now());
    else {
        toast.error('اطلاعات ورود اشتباه است.');
        setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.family || !formData.identifier || !formData.grade || !formData.major) {
        toast.error('لطفا تمام فیلدها را پر کنید.');
        return;
    }
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newUser: Partial<User> = {
      name: `${formData.name} ${formData.family}`,
      role: UserRole.STUDENT,
      studentId: formData.identifier,
      password: formData.password,
      avatar: selectedAvatar,
      grade: formData.grade,
      major: formData.major,
      gamification: { xp: 100, ipc: 0, level: 1, nextLevelXp: 400, badges: [] }
    };

    try {
      await storageService.saveUser(newUser);
      toast.success('حساب شما ایجاد شد.');
      onLogin(newUser as User, "JWT_REG_TOKEN_" + Date.now());
    } catch (err: any) {
      toast.error('خطا در ثبت‌نام');
      setLoading(false);
    }
  };

  const inputLabelClass = "block text-[10px] font-black text-slate-400 uppercase mb-3 mr-2 text-right tracking-widest";
  const inputFieldClass = "w-full p-4 bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:border-primary-500 rounded-2xl outline-none font-bold text-slate-700 dark:text-white transition-all text-right shadow-inner";

  return (
    <div className="w-full min-h-screen flex items-center justify-center bg-[#e9f0f6] dark:bg-slate-950 p-4" dir="rtl">
      <div className="w-full max-w-[1240px] flex flex-col lg:flex-row items-center gap-10">
        
        <div className="hidden lg:flex flex-1 flex-col items-center text-center">
           <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="mb-6"><BrandLogo size={120} /></motion.div>
           <h2 className="text-4xl font-black text-slate-900 dark:text-white mb-2 tracking-tight">ترازش هوشمند</h2>
           <p className="text-base text-slate-500 font-bold max-w-sm mb-8">پلتفرم جامع مدیریت یادگیری و سنجش متمرکز</p>
           
           <div className="w-full max-w-md p-8 rounded-[3rem] bg-white/40 dark:bg-white/5 backdrop-blur-md border-2 border-white/50 dark:border-white/10 relative shadow-2xl min-h-[160px] flex flex-col justify-center overflow-hidden">
              <QuoteIcon className="text-primary-500 opacity-20 absolute -top-2 -right-2" size={60} />
              <AnimatePresence mode="wait">
                <motion.div 
                  key={quoteIndex} 
                  initial={{ opacity: 0, x: 20 }} 
                  animate={{ opacity: 1, x: 0 }} 
                  exit={{ opacity: 0, x: -20 }} 
                  className="space-y-4"
                >
                  <p className="text-slate-800 dark:text-slate-100 font-black italic leading-relaxed text-lg">« {quotes[quoteIndex].text} »</p>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">― {quotes[quoteIndex].author}</p>
                </motion.div>
              </AnimatePresence>
           </div>
        </div>

        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="w-full max-w-[640px]">
          <div className="bg-white dark:bg-slate-900 rounded-[3.5rem] p-6 md:p-8 shadow-2xl border-2 border-slate-200 dark:border-slate-800 relative min-h-[580px] flex flex-col">
            
            <div className="flex flex-col items-center mb-6">
              {!isRegisterMode ? (
                <div className="mb-4"><BrandLogo size={48} /></div>
              ) : (
                <div className="relative mb-3 group cursor-pointer" onClick={() => setIsAvatarPickerOpen(true)}>
                   <div className="w-16 h-16 rounded-full border-4 border-white dark:border-slate-700 bg-slate-100 overflow-hidden shadow-xl">
                      <img src={selectedAvatar} alt="Avatar" className="w-full h-full object-cover" />
                   </div>
                   <div className="absolute bottom-0 right-0 w-5 h-5 bg-primary-600 text-white rounded-full flex items-center justify-center border-2 border-white"><Camera size={12} /></div>
                </div>
              )}
              <h1 className="text-xl font-black text-slate-900 dark:text-white">
                {isRegisterMode ? 'عضویت در ترازش' : 'ورود به سامانه ترازش'}
              </h1>
            </div>

            <form onSubmit={isRegisterMode ? handleRegisterSubmit : handleLoginSubmit} className="space-y-6 flex-1">
              {!isRegisterMode && showHiddenTabs && (
                <div className="flex p-1 bg-slate-200 dark:bg-slate-950 rounded-2xl border border-slate-300 dark:border-slate-800">
                   <button type="button" onClick={() => setActiveTab(UserRole.STUDENT)} className={`flex-1 py-2 rounded-xl text-[10px] font-black transition-all ${activeTab === UserRole.STUDENT ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-md' : 'text-slate-500'}`}>هنرجو</button>
                   <button type="button" onClick={() => setActiveTab(UserRole.TEACHER)} className={`flex-1 py-2 rounded-xl text-[10px] font-black transition-all ${activeTab === UserRole.TEACHER ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-md' : 'text-slate-500'}`}>مدرس</button>
                   <button type="button" onClick={() => setActiveTab(UserRole.ADMIN)} className={`flex-1 py-2 rounded-xl text-[10px] font-black transition-all ${activeTab === UserRole.ADMIN ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-md' : 'text-slate-500'}`}>ادمین</button>
                </div>
              )}

              <AnimatePresence mode="wait">
                {isRegisterMode && (
                  <div className="space-y-5">
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="grid grid-cols-2 gap-4">
                      <div><label className={inputLabelClass}>نام</label><input required className={inputFieldClass} value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} /></div>
                      <div><label className={inputLabelClass}>نام خانوادگی</label><input required className={inputFieldClass} value={formData.family} onChange={e => setFormData({...formData, family: e.target.value})} /></div>
                    </motion.div>
                    
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={inputLabelClass}>پایه تحصیلی</label>
                        <select required className={inputFieldClass} value={formData.grade} onChange={e => setFormData({...formData, grade: e.target.value})}>
                          <option value="">انتخاب پایه...</option>
                          {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={inputLabelClass}>رشته آموزشی</label>
                        <select required className={inputFieldClass} value={formData.major} onChange={e => setFormData({...formData, major: e.target.value})}>
                          <option value="">انتخاب رشته...</option>
                          {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                        </select>
                      </div>
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>

              <div className="space-y-1">
                <label className={inputLabelClass}>{activeTab === UserRole.STUDENT ? 'شماره دانش‌آموزی / کدملی' : 'نام کاربری'}</label>
                <div className="relative group">
                   <input required className={inputFieldClass} value={formData.identifier} onChange={e => setFormData({...formData, identifier: e.target.value})} />
                   <UserIcon className="absolute left-4 top-4 text-slate-300 group-focus-within:text-primary-500" size={20} />
                </div>
              </div>

              <div className="space-y-1">
                <label className={inputLabelClass}>گذرواژه</label>
                <div className="relative group">
                   <input type="password" required className={inputFieldClass} value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="••••••••" />
                   <Lock className="absolute left-4 top-4 text-slate-300 group-focus-within:text-primary-500" size={20} />
                </div>
              </div>

              <div className="pt-2">
                <button type="submit" disabled={loading} className="w-full py-4 bg-primary-600 hover:bg-primary-700 text-white font-black rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2">
                  {loading ? <RefreshCw className="animate-spin" /> : isRegisterMode ? 'ثبت‌نام و ورود به ترازش' : 'ورود به سامانه'}
                </button>
              </div>

              {!isRegisterMode && (
                <div className="flex justify-center mt-4">
                  <button 
                    type="button" 
                    onClick={onForgotPassword} 
                    className="text-[11px] font-black text-primary-600 hover:text-primary-700 transition-colors flex items-center gap-2 group"
                  >
                    فراموشی رمز عبور؟
                    <div className="w-6 h-6 bg-primary-50 dark:bg-primary-900/30 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                       <HelpCircle size={14} />
                    </div>
                  </button>
                </div>
              )}
            </form>

            <div className="mt-6 pt-4 border-t text-center">
               <button onClick={() => setIsRegisterMode(!isRegisterMode)} className="text-[10px] font-black text-slate-500 hover:text-primary-600 transition-colors flex items-center justify-center gap-2 mx-auto">
                  {isRegisterMode ? 'بازگشت به ورود' : 'عضویت جدید در سامانه ترازش'}
               </button>
            </div>
          </div>
        </motion.div>
      </div>

      <Modal isOpen={isAvatarPickerOpen} onClose={() => setIsAvatarPickerOpen(false)} title="انتخاب آواتار">
         <div className="p-4 grid grid-cols-4 gap-3">
            {PRESET_AVATARS.map((url, i) => (
               <button key={i} onClick={() => { setSelectedAvatar(url); setIsAvatarPickerOpen(false); }} className={`relative rounded-2xl overflow-hidden border-2 ${selectedAvatar === url ? 'border-primary-500 scale-105' : 'border-slate-100'}`}>
                  <img src={url} alt="Avatar" className="w-full h-full object-cover" />
                  {selectedAvatar === url && <div className="absolute inset-0 bg-primary-600/20 flex items-center justify-center"><Check className="text-white" size={20} /></div>}
               </button>
            ))}
         </div>
      </Modal>
    </div>
  );
};

export default LoginPage;
