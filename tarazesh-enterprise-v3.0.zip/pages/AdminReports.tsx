
import React, { useState, useMemo } from 'react';
import { 
  BarChart3, Printer, Search, School, User as UserIcon, 
  ChevronLeft, Layers, Target, TrendingUp, Award,
  Activity, ShieldCheck, Heart, Star, FileText, Download, Calendar
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { User, UserRole, ClassEntity } from '../types';
import StudentResults from './StudentResults';
import { motion, AnimatePresence } from 'framer-motion';

const AdminReports: React.FC = () => {
  const [selectedClassId, setSelectedClassId] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const allClasses = storageService.getClasses();
  const allUsers = storageService.getUsers();
  const settings = storageService.getSettings();

  const classStudents = useMemo(() => {
    if (!selectedClassId) return [];
    const cls = allClasses.find(c => c.id === selectedClassId);
    return allUsers.filter(u => u.role === UserRole.STUDENT && u.class === cls?.title);
  }, [selectedClassId, allClasses, allUsers]);

  const filteredStudents = useMemo(() => {
    return classStudents.filter(s => s.name.includes(searchTerm) || s.studentId?.includes(searchTerm));
  }, [classStudents, searchTerm]);

  const selectedStudent = useMemo(() => {
    return allUsers.find(u => u.id === selectedStudentId);
  }, [selectedStudentId, allUsers]);

  const handlePrint = () => {
     window.print();
  };

  return (
    <div className="space-y-8 pb-32">
      {/* Official Print Styles Optimized for Full Report */}
      <style>{`
        @media print {
          @page { size: A4; margin: 1cm; }
          body * { visibility: hidden; }
          .print-area, .print-area * { visibility: visible; }
          .print-area { 
            position: absolute; 
            left: 0; 
            top: 0; 
            width: 100%; 
            display: block !important; 
            background: white !important; 
            color: black !important;
            box-shadow: none !important;
            padding: 0 !important;
          }
          .no-print { display: none !important; }
          .recharts-legend-wrapper, .recharts-tooltip-wrapper { display: none !important; }
          .print-footer { position: fixed; bottom: 0; width: 100%; text-align: center; font-size: 10px; border-top: 1px solid #eee; padding-top: 5px; }
        }
      `}</style>

      {/* Strategic Header */}
      <div className="no-print bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl border border-slate-800">
         <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
         <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-10">
            <div>
               <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-primary-500/20 rounded-2xl backdrop-blur-md border border-primary-500/30">
                     <BarChart3 className="text-primary-400" size={32} />
                  </div>
                  <h1 className="text-3xl font-black tracking-tight tracking-widest uppercase">Academic Intelligence Node</h1>
               </div>
               <p className="text-slate-400 font-bold text-sm max-w-lg leading-relaxed">تولید کارنامه رسمی و جامع هنرجویان با تمام جزئیات تحصیلی، انضباطی و رتبه‌بندی کلاسی.</p>
            </div>
            
            <div className="flex gap-4 w-full lg:w-auto">
               <select 
                className="flex-1 lg:w-72 p-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl font-black text-xs text-white outline-none focus:ring-2 focus:ring-primary-500"
                value={selectedClassId}
                onChange={e => { setSelectedClassId(e.target.value); setSelectedStudentId(''); }}
              >
                 <option value="" className="text-slate-900">فیلتر بر اساس کلاس...</option>
                 {allClasses.map(c => <option key={c.id} value={c.id} className="text-slate-900">{c.title} ({c.major})</option>)}
              </select>
            </div>
         </div>
      </div>

      <AnimatePresence mode="wait">
        {!selectedClassId ? (
           <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="no-print py-40 text-center bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
              <School size={80} className="mx-auto text-slate-100 dark:text-slate-800 mb-6" />
              <p className="text-slate-400 font-bold text-2xl">برای تولید گزارش، لطفاً کلاس هدف را انتخاب کنید.</p>
           </motion.div>
        ) : !selectedStudentId ? (
           <motion.div key="list" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="no-print space-y-8">
              <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                 <div className="relative flex-1">
                    <input 
                      type="text" 
                      placeholder="جستجو در لیست کلاس (نام یا کد ملی)..." 
                      className="w-full pl-4 pr-12 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none shadow-inner"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                    />
                    <Search className="absolute right-4 top-4 text-slate-400" size={24} />
                 </div>
                 <div className="bg-primary-600 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase">{filteredStudents.length} هنرجو</div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                 {filteredStudents.map(student => (
                    <div 
                      key={student.id}
                      onClick={() => setSelectedStudentId(student.id)}
                      className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-3xl transition-all cursor-pointer group"
                    >
                       <div className="flex flex-col items-center text-center mb-8">
                          <div className="w-24 h-24 rounded-[2rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-slate-400 overflow-hidden mb-4 border-4 border-white dark:border-slate-700 shadow-xl group-hover:scale-105 transition-transform">
                             {student.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : <UserIcon size={48}/>}
                          </div>
                          <h4 className="font-black text-xl text-slate-800 dark:text-white leading-tight">{student.name}</h4>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">ID: {student.studentId}</p>
                       </div>
                       <button className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-[10px] uppercase shadow-xl group-hover:bg-primary-600 group-hover:text-white transition-all">انتخاب جهت چاپ</button>
                    </div>
                 ))}
              </div>
           </motion.div>
        ) : (
           <motion.div key="report" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="no-print space-y-8">
              <div className="flex justify-between items-center bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                 <button onClick={() => setSelectedStudentId('')} className="flex items-center gap-2 text-sm font-black text-slate-500 hover:text-primary-600 transition-colors">
                    <ChevronLeft className="rotate-180" /> انتخاب دانش‌آموز دیگر
                 </button>
                 <div className="flex gap-3">
                    <button onClick={handlePrint} className="px-10 py-4 bg-primary-600 text-white rounded-2xl font-black text-xs flex items-center gap-3 shadow-2xl hover:bg-primary-700 transition-all">
                       <Printer size={20}/> چاپ کارنامه رسمی A4
                    </button>
                 </div>
              </div>
              
              <div className="print-area">
                <div className="hidden print:block mb-6">
                   <div className="flex justify-between items-center border-b-4 border-slate-900 pb-6">
                      <School size={60} />
                      <div className="text-center space-y-1">
                         <h1 className="text-3xl font-black">{settings.instituteName}</h1>
                         <h2 className="text-lg font-bold uppercase tracking-widest">گزارش جامع پیشرفت تحصیلی و انضباطی</h2>
                         <p className="text-xs font-bold text-slate-500">سال تحصیلی: ۱۴۰۳-۱۴۰۴ | تاریخ صدور: {new Date().toLocaleDateString('fa-IR')}</p>
                      </div>
                      <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center text-[10px] font-black text-slate-400">QR Code</div>
                   </div>
                </div>

                {/* This shared component now handles rank and all details */}
                <StudentResults currentUser={selectedStudent!} />

                <div className="hidden print:block mt-12">
                   <div className="grid grid-cols-3 gap-10 px-6">
                      <div className="text-center space-y-10">
                         <p className="font-black text-sm">مهر و امضای مدرس</p>
                         <div className="h-20"></div>
                      </div>
                      <div className="text-center space-y-10 border-x border-slate-100">
                         <p className="font-black text-sm">تاییدیه واحد آموزش</p>
                         <div className="h-20"></div>
                      </div>
                      <div className="text-center space-y-10">
                         <p className="font-black text-sm">مهر و امضای مدیریت</p>
                         <div className="h-20"></div>
                      </div>
                   </div>
                   <div className="print-footer">
                      این کارنامه توسط سامانه هوشمند {settings.instituteName} صادر شده و فاقد خدشه معتبر است.
                   </div>
                </div>
              </div>
           </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminReports;
