
import React, { useState, useEffect } from 'react';
import { User, ExamResult, Exam } from '../types';
import { storageService } from '../services/storageService';
import { generateLearningPath } from '../services/aiService';
import { BrainCircuit, Sparkles, Target, ArrowRight, Loader2, CheckCircle2, ChevronLeft, Map, Lightbulb, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';

interface Props {
  currentUser: User;
}

const StudentLearningPath: React.FC<Props> = ({ currentUser }) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const toast = useToast();

  const fetchPath = async () => {
    setLoading(true);
    try {
        const results = storageService.getResults().filter(r => r.studentId === currentUser.id);
        const exams = storageService.getExams();
        const pathData = await generateLearningPath(results, exams);
        if (pathData) setData(pathData);
        else toast.error("داده‌های کافی برای تحلیل یافت نشد.");
    } catch (e) {
        toast.error("خطا در ارتباط با هسته هوش مصنوعی.");
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-5">
           <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-3xl flex items-center justify-center text-indigo-600 shadow-inner">
              <Compass size={36} />
           </div>
           <div>
              <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">نقشه راه یادگیری هوشمند</h1>
              <p className="text-sm text-slate-500 font-bold mt-1">تحلیل اختصاصی Gemini از عملکرد تحصیلی شما</p>
           </div>
        </div>
        {!data && !loading && (
            <button onClick={fetchPath} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-4 rounded-2xl flex items-center gap-3 shadow-2xl font-black transition-all hover:scale-105 active:scale-95">
                <Sparkles size={20} /> شروع تحلیل هوشمند
            </button>
        )}
      </div>

      <AnimatePresence mode="wait">
        {loading ? (
          <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-40 text-center space-y-6">
             <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 border-4 border-primary-500/20 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-primary-500 rounded-full border-t-transparent animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center text-primary-500"><BrainCircuit size={40} /></div>
             </div>
             <p className="text-slate-500 font-black text-xl animate-pulse">در حال آنالیز سوابق و ترسیم نقشه رشد...</p>
          </motion.div>
        ) : data ? (
          <motion.div key="data" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
             {/* Analysis Summary */}
             <div className="lg:col-span-12 bg-gradient-to-br from-indigo-600 to-primary-700 rounded-[3.5rem] p-10 text-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-10"><Lightbulb size={200} /></div>
                <div className="relative z-10 max-w-3xl">
                   <h3 className="text-2xl font-black mb-4 flex items-center gap-2"><Sparkles /> تحلیل مشاور هوشمند</h3>
                   <p className="text-lg leading-relaxed text-indigo-50 font-bold italic">« {data.analysis} »</p>
                </div>
             </div>

             {/* Strengths & Weaknesses */}
             <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <h4 className="font-black text-emerald-600 mb-6 flex items-center gap-2"><CheckCircle2 size={24}/> نقاط قوت شناسایی شده</h4>
                <div className="space-y-3">
                   {data.strengths.map((s: string, i: number) => (
                      <div key={i} className="p-4 bg-emerald-50 dark:bg-emerald-900/10 rounded-2xl border border-emerald-100 dark:border-emerald-800 flex items-center gap-3">
                         <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                         <span className="text-sm font-bold text-emerald-900 dark:text-emerald-100">{s}</span>
                      </div>
                   ))}
                </div>
             </div>

             <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <h4 className="font-black text-rose-600 mb-6 flex items-center gap-2"><Target size={24}/> مواردی که نیاز به تمرکز دارند</h4>
                <div className="space-y-3">
                   {data.weaknesses.map((w: string, i: number) => (
                      <div key={i} className="p-4 bg-rose-50 dark:bg-rose-900/10 rounded-2xl border border-rose-100 dark:border-rose-800 flex items-center gap-3">
                         <div className="w-2 h-2 rounded-full bg-rose-500"></div>
                         <span className="text-sm font-bold text-rose-900 dark:text-rose-100">{w}</span>
                      </div>
                   ))}
                </div>
             </div>

             {/* Steps Roadmap */}
             <div className="lg:col-span-12 space-y-6">
                <h3 className="text-xl font-black text-slate-800 dark:text-white px-4">نقشه عملیاتی پیشنهادی</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   {data.roadmap.map((step: any, i: number) => (
                      <div key={i} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm relative group hover:border-primary-400 transition-all">
                         <span className="absolute top-6 left-6 text-5xl font-black text-slate-50 dark:text-slate-800 group-hover:text-primary-500/10 transition-colors">{step.step}</span>
                         <div className="relative z-10">
                            <h5 className="font-black text-lg text-slate-900 dark:text-white mb-3">{step.title}</h5>
                            <p className="text-xs text-slate-500 dark:text-slate-400 font-bold leading-relaxed">{step.description}</p>
                         </div>
                      </div>
                   ))}
                </div>
             </div>

             <div className="lg:col-span-12 text-center pt-10">
                <button onClick={() => setData(null)} className="text-slate-400 font-black text-xs uppercase tracking-widest hover:text-primary-600 transition-colors flex items-center gap-2 mx-auto">
                   <ChevronLeft className="rotate-180" /> تحلیل مجدد با داده‌های جدید
                </button>
             </div>
          </motion.div>
        ) : (
          <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-32 text-center bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
             <Map size={80} className="mx-auto text-slate-100 dark:text-slate-800 mb-6" />
             <p className="text-slate-400 font-black text-xl">آماده تحلیل عملکرد و تولید نقشه راه اختصاصی شما.</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default StudentLearningPath;
