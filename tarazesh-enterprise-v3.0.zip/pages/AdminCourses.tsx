
import React, { useState, useMemo, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { Course, Major, Grade } from '../types';
import { 
  Search, Plus, Edit, Trash2, BookOpen, Save, Layers, 
  GraduationCap, Bookmark, School, Tag, Hash, BookMarked, 
  Settings2, Star, CheckCircle2, ChevronRight, Filter, Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const AdminCourses: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>(() => storageService.getCourses());
  const [majors] = useState<Major[]>(() => storageService.getMajors());
  const [grades] = useState<Grade[]>(() => storageService.getGrades());
  
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMajor, setFilterMajor] = useState('all');
  const [filterGrade, setFilterGrade] = useState('all');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  const toast = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  
  const [formData, setFormData] = useState<Partial<Course>>({
    title: '', grade: '', major: '', code: '', category: 'GENERAL', description: ''
  });

  const filteredCourses = useMemo(() => {
    return courses.filter(c => {
      const matchSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (c.code && c.code.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchMajor = filterMajor === 'all' || c.major === filterMajor;
      const matchGrade = filterGrade === 'all' || c.grade === filterGrade;
      return matchSearch && matchMajor && matchGrade;
    });
  }, [courses, searchTerm, filterMajor, filterGrade]);

  const handleOpenModal = (course?: Course) => {
    if (course) {
      setEditingCourse(course);
      setFormData({ ...course });
    } else {
      setEditingCourse(null);
      setFormData({ title: '', grade: '', major: '', code: '', category: 'GENERAL', description: '' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.title || !formData.grade || !formData.major) {
      toast.error('لطفاً اطلاعات اصلی درس (عنوان، پایه و رشته) را تکمیل کنید.');
      return;
    }

    const newCourse: Course = {
      id: editingCourse ? editingCourse.id : `c_${Date.now()}`,
      title: formData.title!,
      grade: formData.grade!,
      major: formData.major!,
      code: formData.code || '',
      category: formData.category || 'GENERAL',
      description: formData.description
    };

    const updated = editingCourse 
      ? courses.map(c => c.id === editingCourse.id ? newCourse : c)
      : [newCourse, ...courses];

    setCourses(updated);
    storageService.saveCourses(updated);
    toast.success(editingCourse ? 'واحد درسی با موفقیت بروزرسانی شد.' : 'واحد درسی جدید به چارت آموزشی اضافه شد.');
    setIsModalOpen(false);
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const updated = courses.filter(c => c.id !== deleteId);
    setCourses(updated);
    storageService.saveCourses(updated);
    toast.info('واحد درسی از آرشیو سیستم حذف شد.');
    setDeleteId(null);
  };

  const getCategoryStyle = (cat: string) => {
     switch(cat) {
        case 'SPECIALIZED': return 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400 border-amber-100 dark:border-amber-800';
        case 'PODMANI': return 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400 border-indigo-100 dark:border-indigo-800';
        default: return 'bg-slate-50 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border-slate-100 dark:border-slate-700';
     }
  };

  return (
    <div className="space-y-8 pb-32">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm transition-all">
        <div className="flex items-center gap-5">
           <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-3xl flex items-center justify-center text-primary-600 shadow-inner">
             <BookMarked size={36} />
           </div>
           <div>
              <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 tracking-tight leading-none">مدیریت چارت دروس</h1>
              <p className="text-sm text-slate-500 font-bold mt-2">تعریف سرفصل‌های آموزشی، کدینگ استاندارد و دسته‌بندی واحدها</p>
           </div>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-4 rounded-2xl flex items-center gap-3 shadow-2xl shadow-primary-500/30 font-black transition-all hover:scale-105 active:scale-95">
          <Plus size={24} /> تعریف واحد درسی
        </button>
      </div>

      {/* Advanced Control Center */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative md:col-span-2">
           <input 
             type="text" 
             placeholder="جستجوی هوشمند در نام یا کد درس..." 
             className="w-full pl-4 pr-12 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-primary-500 transition-all"
             value={searchTerm}
             onChange={e => setSearchTerm(e.target.value)}
           />
           <Search className="absolute right-4 top-4.5 text-slate-400" size={22} />
        </div>
        <div className="relative">
          <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-black outline-none border-none text-slate-900 dark:text-white appearance-none cursor-pointer" value={filterGrade} onChange={e => setFilterGrade(e.target.value)}>
             <option value="all">فیلتر بر اساس پایه</option>
             {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
          </select>
          <GraduationCap className="absolute left-4 top-4.5 text-slate-400 pointer-events-none" size={18} />
        </div>
        <div className="relative">
          <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-black outline-none border-none text-slate-900 dark:text-white appearance-none cursor-pointer" value={filterMajor} onChange={e => setFilterMajor(e.target.value)}>
             <option value="all">فیلتر بر اساس رشته</option>
             {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
          </select>
          <Layers className="absolute left-4 top-4.5 text-slate-400 pointer-events-none" size={18} />
        </div>
      </div>

      {/* Courses Display Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        <AnimatePresence mode="popLayout">
          {filteredCourses.map(course => (
            <motion.div 
              key={course.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-2xl transition-all group relative overflow-hidden"
            >
               <div className="flex justify-between items-start mb-6">
                  <div className="w-14 h-14 bg-primary-50 dark:bg-primary-900/30 text-primary-600 rounded-2xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform duration-500">
                     <BookOpen size={28} />
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300">
                     <button onClick={() => handleOpenModal(course)} className="p-2.5 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-xl transition-all"><Edit size={18}/></button>
                     <button onClick={() => setDeleteId(course.id)} className="p-2.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-xl transition-all"><Trash2 size={18}/></button>
                  </div>
               </div>

               <span className={`inline-block px-3 py-1 rounded-full text-[8px] font-black uppercase border mb-4 tracking-widest ${getCategoryStyle(course.category)}`}>
                  {course.category}
               </span>

               <h3 className="font-black text-xl text-slate-900 dark:text-white mb-2 leading-tight group-hover:text-primary-600 transition-colors">{course.title}</h3>
               <p className="text-[10px] text-slate-400 font-bold uppercase mb-8 tracking-[0.2em]">کد درس: {course.code || 'فاقد کد'}</p>

               <div className="flex flex-wrap gap-2 pt-6 border-t border-slate-50 dark:border-slate-800">
                  <div className="px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center gap-1.5">
                     <GraduationCap size={12} className="text-slate-400" />
                     <span className="text-[9px] font-black text-slate-500 uppercase">{course.grade}</span>
                  </div>
                  <div className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg flex items-center gap-1.5">
                     <Layers size={12} className="text-indigo-400" />
                     <span className="text-[9px] font-black text-indigo-600 dark:text-indigo-400 uppercase">{course.major}</span>
                  </div>
               </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {filteredCourses.length === 0 && (
          <div className="col-span-full py-40 text-center border-2 border-dashed rounded-[3rem] border-slate-200 dark:border-slate-800">
             <BookMarked size={80} className="mx-auto text-slate-100 dark:text-slate-800 mb-6" />
             <p className="text-slate-400 font-black text-2xl">واحد درسی با این مشخصات یافت نشد.</p>
          </div>
        )}
      </div>

      {/* Course Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingCourse ? 'ویرایش واحد درسی تخصصی' : 'تعریف سرفصل آموزشی جدید'} maxWidth="max-w-4xl">
         <div className="p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><BookOpen size={14}/> عنوان کامل درس</label>
                  <input className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="مثال: فیزیک کوانتوم و نسبیت" />
               </div>
               <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><Hash size={14}/> کد اختصاصی (سیستمی)</label>
                  <input className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white dir-ltr text-left" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} placeholder="PH-202-A" />
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><GraduationCap size={14}/> پایه آموزشی</label>
                  <select className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.grade} onChange={e => setFormData({...formData, grade: e.target.value})}>
                     <option value="">انتخاب پایه...</option>
                     {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
                  </select>
               </div>
               <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><Layers size={14}/> رشته تخصصی</label>
                  <select className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.major} onChange={e => setFormData({...formData, major: e.target.value})}>
                     <option value="">انتخاب رشته...</option>
                     {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                  </select>
               </div>
               <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><Tag size={14}/> دسته‌بندی واحد</label>
                  <select className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                     <option value="GENERAL">عمومی (General)</option>
                     <option value="SPECIALIZED">تخصصی (Specialized)</option>
                     <option value="PODMANI">پودمانی (Modular)</option>
                  </select>
               </div>
            </div>

            <div className="space-y-3">
               <label className="text-[11px] font-black text-slate-400 uppercase block mr-2 flex items-center gap-2"><Info size={14}/> شرح کوتاه درس (اختیاری)</label>
               <textarea className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-bold text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white min-h-[100px]" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="توضیحاتی در مورد سرفصل‌ها یا پیش‌نیازهای این درس..." />
            </div>

            <div className="flex justify-end gap-3 pt-8 border-t border-slate-100 dark:border-slate-800">
               <button onClick={() => setIsModalOpen(false)} className="px-10 py-4 text-slate-400 font-black hover:text-slate-700 transition-colors uppercase text-xs tracking-widest">انصراف</button>
               <button onClick={handleSave} className="bg-primary-600 hover:bg-primary-700 text-white px-16 py-4 rounded-2xl font-black shadow-2xl shadow-primary-500/30 transition-all flex items-center gap-3">
                 <Save size={22} /> ثبت نهایی واحد درسی
               </button>
            </div>
         </div>
      </Modal>

      <ConfirmationModal 
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="حذف واحد درسی از سیستم"
        description="آیا از حذف این واحد درسی اطمینان دارید؟ توجه داشته باشید که این عمل ممکن است باعث ایجاد خطا در کارنامه‌های صادر شده برای هنرجویان شود."
        confirmText="بله، حذف شود"
      />
    </div>
  );
};

export default AdminCourses;
