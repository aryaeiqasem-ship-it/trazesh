import React, { useState, useRef } from 'react';
import { User, UserRole } from '../types';
import { storageService } from '../services/storageService';
import { Lock, User as UserIcon, Camera, Save, Shield, KeyRound, Mail, Smartphone, Upload, CheckCircle } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import { compressImage } from '../utils/imageUtils';

interface SettingsPageProps {
  currentUser: User;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security'>('profile');
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Profile Form State
  const [profileData, setProfileData] = useState({
    email: currentUser.email || '',
    phoneNumber: currentUser.phoneNumber || '',
    avatar: currentUser.avatar || ''
  });

  // Password Form State
  const [passData, setPassData] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleProfileSave = async () => {
    setLoading(true);
    try {
      // Create updated user object
      const updatedUser: User = {
        ...currentUser,
        email: profileData.email,
        phoneNumber: profileData.phoneNumber,
        avatar: profileData.avatar
      };

      // Save locally (for immediate UI update) and sync
      const allUsers = storageService.getUsers();
      const newUsersList = allUsers.map(u => u.id === currentUser.id ? updatedUser : u);
      storageService.saveUsers(newUsersList);
      
      toast.success('مشخصات فردی با موفقیت بروزرسانی شد.');
    } catch (err) {
      toast.error('خطا در ذخیره‌سازی اطلاعات.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passData.newPassword.length < 6) return toast.error('رمز عبور جدید باید حداقل ۶ کاراکتر باشد.');
    if (passData.newPassword !== passData.confirmPassword) return toast.error('تکرار رمز عبور مطابقت ندارد.');

    setLoading(true);
    try {
      const token = localStorage.getItem('auth_token');
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({
          oldPassword: passData.oldPassword,
          newPassword: passData.newPassword
        })
      });

      const data = await res.json();
      if (res.ok) {
        toast.success(data.message);
        setPassData({ oldPassword: '', newPassword: '', confirmPassword: '' });
      } else {
        toast.error(data.error || 'خطا در تغییر رمز عبور.');
      }
    } catch (err) {
      toast.error('خطا در ارتباط با سرور.');
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressed = await compressImage(file, 400, 0.8);
        setProfileData(prev => ({ ...prev, avatar: compressed }));
      } catch (err) {
        toast.error('خطا در پردازش تصویر.');
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-6">تنظیمات حساب کاربری</h1>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar Tabs */}
        <div className="md:w-64 space-y-2">
          <button
            onClick={() => setActiveTab('profile')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
              activeTab === 'profile' 
                ? 'bg-white dark:bg-slate-800 text-primary-600 shadow-md border border-slate-100 dark:border-slate-700' 
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <UserIcon size={20} />
            مشخصات فردی
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
              activeTab === 'security' 
                ? 'bg-white dark:bg-slate-800 text-primary-600 shadow-md border border-slate-100 dark:border-slate-700' 
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Shield size={20} />
            امنیت و رمز عبور
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 md:p-8 min-h-[400px]">
          <AnimatePresence mode="wait">
            {activeTab === 'profile' ? (
              <motion.div
                key="profile"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="flex flex-col items-center sm:flex-row gap-6 pb-6 border-b border-slate-100 dark:border-slate-800">
                  <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                    <div className="w-24 h-24 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-4xl font-bold text-slate-400 overflow-hidden border-4 border-white dark:border-slate-700 shadow-lg">
                      {profileData.avatar ? (
                        <img src={profileData.avatar} alt="Avatar" className="w-full h-full object-cover" />
                      ) : (
                        currentUser.name.charAt(0)
                      )}
                    </div>
                    <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Camera className="text-white" size={24} />
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarUpload} />
                  </div>
                  <div className="text-center sm:text-right">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">{currentUser.name}</h2>
                    <p className="text-slate-500 text-sm mt-1">{currentUser.role === UserRole.TEACHER ? 'مدرس' : 'دانش‌آموز'} | {currentUser.username || currentUser.studentId}</p>
                    <button onClick={() => fileInputRef.current?.click()} className="text-xs text-primary-600 mt-2 hover:underline">تغییر تصویر پروفایل</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">نام و نام خانوادگی</label>
                    <input 
                      type="text" 
                      value={currentUser.name} 
                      disabled
                      className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-500 cursor-not-allowed"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">نام کاربری قابل تغییر نیست.</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">شناسه کاربری</label>
                    <input 
                      type="text" 
                      value={currentUser.studentId || currentUser.username} 
                      disabled
                      className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-500 cursor-not-allowed dir-ltr text-right"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">ایمیل (جهت بازیابی)</label>
                    <div className="relative">
                      <input 
                        type="email" 
                        value={profileData.email}
                        onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                        className="w-full pl-10 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none dir-ltr text-left"
                        placeholder="example@email.com"
                      />
                      <Mail size={18} className="absolute left-3 top-3.5 text-slate-400" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">شماره موبایل</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        value={profileData.phoneNumber}
                        onChange={(e) => setProfileData({...profileData, phoneNumber: e.target.value})}
                        className="w-full pl-10 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none dir-ltr text-left"
                        placeholder="0912..."
                      />
                      <Smartphone size={18} className="absolute left-3 top-3.5 text-slate-400" />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <button 
                    onClick={handleProfileSave}
                    disabled={loading}
                    className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2.5 rounded-xl shadow-lg shadow-primary-500/20 flex items-center gap-2 font-bold disabled:opacity-70 transition-all"
                  >
                    {loading ? <span className="animate-spin w-5 h-5 border-2 border-white/30 border-t-white rounded-full"></span> : <Save size={18} />}
                    <span>ذخیره تغییرات</span>
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="security"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4 flex gap-3">
                   <Lock className="text-amber-600 shrink-0" />
                   <div>
                      <h3 className="font-bold text-amber-800 dark:text-amber-400 text-sm">امنیت حساب کاربری</h3>
                      <p className="text-xs text-amber-700 dark:text-amber-500 mt-1">توصیه می‌شود از یک رمز عبور قوی شامل حروف و اعداد استفاده کنید.</p>
                   </div>
                </div>

                <form onSubmit={handlePasswordChange} className="space-y-4 max-w-md">
                   <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">رمز عبور فعلی</label>
                      <div className="relative">
                         <input 
                           type="password" 
                           className="w-full pl-10 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                           placeholder="••••••••"
                           value={passData.oldPassword}
                           onChange={e => setPassData({...passData, oldPassword: e.target.value})}
                         />
                         <KeyRound size={18} className="absolute left-3 top-3.5 text-slate-400" />
                      </div>
                   </div>
                   
                   <hr className="border-slate-100 dark:border-slate-800 my-4" />

                   <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">رمز عبور جدید</label>
                      <div className="relative">
                         <input 
                           type="password" 
                           className="w-full pl-10 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                           placeholder="حداقل ۶ کاراکتر"
                           value={passData.newPassword}
                           onChange={e => setPassData({...passData, newPassword: e.target.value})}
                         />
                         <Lock size={18} className="absolute left-3 top-3.5 text-slate-400" />
                      </div>
                   </div>

                   <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">تکرار رمز عبور جدید</label>
                      <div className="relative">
                         <input 
                           type="password" 
                           className="w-full pl-10 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                           placeholder="تکرار رمز عبور"
                           value={passData.confirmPassword}
                           onChange={e => setPassData({...passData, confirmPassword: e.target.value})}
                         />
                         <CheckCircle className="absolute left-3 top-3.5 text-slate-400" size={18} />
                      </div>
                   </div>

                   <div className="pt-4">
                      <button 
                        type="submit"
                        disabled={loading || !passData.oldPassword || !passData.newPassword}
                        className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl shadow-lg shadow-green-500/20 font-bold transition-all disabled:opacity-50 disabled:shadow-none flex justify-center items-center gap-2"
                      >
                        {loading ? <span className="animate-spin w-5 h-5 border-2 border-white/30 border-t-white rounded-full"></span> : <Shield size={18} />}
                        <span>تغییر رمز عبور</span>
                      </button>
                   </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;