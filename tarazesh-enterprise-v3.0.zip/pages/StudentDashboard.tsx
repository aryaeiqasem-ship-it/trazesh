
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Exam, QuestionType, User, ExamType, ExamResult, Major, Grade, Course, LiveExamSession, Question, Badge } from '../types';
import { storageService } from '../services/storageService';
import { 
  Clock, ShieldCheck, ArrowRight, Loader2, Activity, Plus, Sparkles, 
  BookOpen, ListOrdered, ThumbsUp, ThumbsDown, Camera, AlertTriangle, 
  Maximize2, MonitorOff, UserCheck, Zap, BookMarked, Layers, GraduationCap, 
  X, Timer, Check, BrainCircuit, Play, ShieldAlert, ChevronLeft, ChevronRight,
  Flag, Award, CheckCircle, Trophy, Star, TrendingUp, Home
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import Modal from '../components/Modal';
import ProctoringCheck from '../components/ProctoringCheck';

interface StudentProps {
  availableExams: Exam[];
  currentUser: User;
  onNavigate: (view: string, data?: any) => void;
  isPreview?: boolean;
}

const StudentDashboard: React.FC<StudentProps> = ({ availableExams, currentUser, onNavigate, isPreview = false }) => {
  const [activeTab, setActiveTab] = useState<ExamType>(ExamType.OFFICIAL);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [pendingExam, setPendingExam] = useState<Exam | null>(null);
  const [showFaceCheck, setShowFaceCheck] = useState(false);
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [finishData, setFinishData] = useState<{ result: ExamResult, badges: Badge[] } | null>(null);
  const [proctoringAlerts, setProctoringAlerts] = useState<string[]>([]);
  
  const toast = useToast();

  const results = storageService.getResults();
  const takenExamIds = useMemo(() => new Set(results.filter(r => r.studentId === currentUser.id).map(r => r.examId)), [results, currentUser.id]);

  useEffect(() => {
    if (isPreview && availableExams.length === 1 && !activeExam) {
      startExam(availableExams[0]);
    }
  }, [isPreview, availableExams, activeExam]);

  useEffect(() => {
    if (!activeExam) return;

    const timerInterval = setInterval(() => {
        setTimeLeft(prev => {
            if (prev <= 1) {
                clearInterval(timerInterval);
                processAutoSubmit();
                return 0;
            }
            return prev - 1;
        });
    }, 1000);

    const heartbeatInterval = setInterval(() => {
        if (isPreview) return; 
        const answeredCount = Object.keys(answers).length;
        const progress = Math.round((answeredCount / (activeExam.questions.length || 1)) * 100);
        
        const session: LiveExamSession = {
            examId: activeExam.id,
            studentId: currentUser.id,
            studentName: currentUser.name,
            startTime: new Date().toISOString(),
            lastHeartbeat: new Date().toISOString(),
            progress,
            alerts: proctoringAlerts,
            status: 'online'
        };
        storageService.updateLiveSession(session);
    }, 5000);

    const handleVisibilityChange = () => {
        if (document.hidden && activeExam.lockBrowser) {
            const msg = `تغییر زبانه شناسایی شد.`;
            setProctoringAlerts(prev => [...prev, msg]);
            toast.warning("خروج از محیط آزمون ثبت شد!");
        }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
        clearInterval(timerInterval);
        clearInterval(heartbeatInterval);
        document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [activeExam, answers, proctoringAlerts, currentUser, toast, timeLeft, isPreview]);

  const processAutoSubmit = () => {
      toast.info("زمان آزمون به پایان رسید.");
      processSubmission();
  };

  const processSubmission = async () => {
    if (!activeExam || isSubmitting) return;
    if (isPreview) {
      toast.success("پیش‌نمایش به پایان رسید.");
      setActiveExam(null);
      onNavigate('teacher_exams');
      return;
    }
    setIsSubmitting(true);
    try {
        if (document.fullscreenElement) document.exitFullscreen();
        const serverRes: any = await storageService.submitExamToServer(activeExam.id, answers, currentUser.id, activeExam.questions);
        
        setFinishData({ result: serverRes, badges: serverRes.newBadges || [] });
        
        if (serverRes.status === 'passed') {
           confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 }, colors: ['#0ea5e9', '#10b981', '#f59e0b'] });
        }
        
        setActiveExam(null);
        setCurrentQuestionIndex(0);
    } finally { 
        setIsSubmitting(false); 
    }
  };

  const handleStartRequest = (exam: Exam) => {
    if (takenExamIds.has(exam.id) && !isPreview) {
        toast.warning("شما قبلاً در این آزمون شرکت کرده‌اید. امکان شرکت مجدد وجود ندارد.");
        return;
    }
    if (exam.requireFaceId && !isPreview) {
        setPendingExam(exam);
        setShowFaceCheck(true);
    } else {
        startExam(exam);
    }
  };

  const startExam = async (exam: Exam) => {
    setTimeLeft(exam.durationMinutes * 60);
    setAnswers({});
    setCurrentQuestionIndex(0);
    setActiveExam(exam);
    if (exam.lockBrowser && !isPreview) {
        try {
            await document.documentElement.requestFullscreen();
        } catch (e) {
            console.error("FS Error");
        }
    }
  };

  const currentQuestion = activeExam?.questions[currentQuestionIndex];
  const totalQuestions = activeExam?.questions.length || 0;
  const progressPercent = Math.round(((currentQuestionIndex + 1) / totalQuestions) * 100);

  return (
    <div className="space-y-10 pb-24 font-sans">
      <AnimatePresence>
        {showFaceCheck && pendingExam && (
            <ProctoringCheck 
                userName={currentUser.name} 
                onCancel={() => { setShowFaceCheck(false); setPendingExam(null); }}
                onSuccess={() => { setShowFaceCheck(false); startExam(pendingExam); setPendingExam(null); }}
            />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {finishData && (
          <div className="fixed inset-0 z-[10005] bg-slate-950/90 backdrop-blur-2xl flex items-center justify-center p-4">
             <motion.div 
               initial={{ scale: 0.8, opacity: 0, y: 50 }} 
               animate={{ scale: 1, opacity: 1, y: 0 }}
               className="max-w-2xl w-full bg-white dark:bg-slate-900 rounded-[3.5rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.5)] border border-slate-100 dark:border-white/5"
             >
                <div className="p-10 md:p-12 text-center space-y-8">
                   <div className="relative inline-block">
                      <motion.div 
                        initial={{ rotate: -10, scale: 0 }} animate={{ rotate: 0, scale: 1 }} transition={{ type: 'spring', delay: 0.3 }}
                        className="w-24 h-24 bg-amber-500 text-slate-950 rounded-[2rem] flex items-center justify-center shadow-2xl mx-auto"
                      >
                         <Trophy size={48} />
                      </motion.div>
                      {finishData.badges.length > 0 && (
                         <motion.div 
                           initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.6 }}
                           className="absolute -top-2 -right-2 bg-emerald-500 text-white p-2 rounded-full border-4 border-white dark:border-slate-900 shadow-xl"
                         >
                            <Star size={20} fill="currentColor" />
                         </motion.div>
                      )}
                   </div>

                   <div>
                      <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">آزمون با موفقیت به پایان رسید</h2>
                      <p className="text-slate-500 font-bold mt-2">عملکرد شما با دقت توسط سیستم تحلیل و ثبت گردید.</p>
                   </div>

                   <div className="grid grid-cols-3 gap-4">
                      <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-[2rem] border border-slate-100 dark:border-white/5">
                         <p className="text-[10px] font-black text-slate-400 uppercase mb-2">نمره نهایی</p>
                         <p className="text-3xl font-black text-primary-600">{finishData.result.score}<span className="text-xs opacity-50">/{finishData.result.maxScore}</span></p>
                      </div>
                      <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-[2rem] border border-emerald-100 dark:border-emerald-800/30">
                         <p className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase mb-2">پاداش تجربه</p>
                         <p className="text-3xl font-black text-emerald-600">+{finishData.result.earnedXp} <span className="text-xs">XP</span></p>
                      </div>
                      <div className="bg-indigo-50 dark:bg-indigo-900/10 p-6 rounded-[2rem] border border-indigo-100 dark:border-indigo-800/30">
                         <p className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase mb-2">وضعیت قبولی</p>
                         <p className={`text-xl font-black ${finishData.result.status === 'passed' ? 'text-emerald-500' : 'text-rose-500'}`}>
                            {finishData.result.status === 'passed' ? 'موفقیت‌آمیز' : 'تلاش مجدد'}
                         </p>
                      </div>
                   </div>

                   {finishData.badges.length > 0 && (
                      <div className="space-y-4">
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">نشان‌های کسب شده</p>
                         <div className="flex justify-center gap-3">
                            {finishData.badges.map(b => (
                               <div key={b.id} className="flex items-center gap-2 bg-amber-50 dark:bg-amber-900/20 px-4 py-2 rounded-xl border border-amber-200 dark:border-amber-800">
                                  <Award size={16} className="text-amber-600" />
                                  <span className="text-xs font-black text-amber-900 dark:text-amber-200">{b.title}</span>
                               </div>
                            ))}
                         </div>
                      </div>
                   )}

                   <div className="pt-4 flex gap-4">
                      <button onClick={() => { setFinishData(null); onNavigate('student_results'); }} className="flex-1 py-4 bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 rounded-2xl font-black text-xs uppercase flex items-center justify-center gap-2 hover:bg-slate-200 transition-all">
                         <Activity size={18} /> مشاهده جزئیات کارنامه
                      </button>
                      <button onClick={() => { setFinishData(null); onNavigate('student_home'); }} className="flex-[2] py-4 bg-primary-600 text-white rounded-2xl font-black text-sm shadow-xl shadow-primary-500/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2">
                         بازگشت به پیشخوان <Home size={20} />
                      </button>
                   </div>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {activeExam && currentQuestion ? (
          <div className="fixed inset-0 z-[1000] bg-slate-50 dark:bg-slate-950 overflow-hidden flex flex-col" dir="rtl">
              <header className="h-20 bg-white dark:bg-slate-900 border-b dark:border-slate-800 flex justify-between items-center px-6 md:px-10 shadow-lg relative z-20">
                 <div className="flex items-center gap-4">
                    <div className="hidden sm:flex p-3 bg-rose-50 dark:bg-rose-900/30 text-rose-600 rounded-2xl shadow-inner"><Timer size={24}/></div>
                    <div>
                       <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">زمان باقی‌مانده</p>
                       <p className={`text-xl md:text-2xl font-black font-mono leading-none ${timeLeft < 300 ? 'text-rose-500 animate-pulse' : 'text-slate-800 dark:text-white'}`}>
                          {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                       </p>
                    </div>
                 </div>

                 <div className="flex flex-col items-center">
                    <h2 className="text-sm font-black text-slate-800 dark:text-white truncate max-w-[150px] md:max-w-md">{activeExam.title}</h2>
                    <div className="flex items-center gap-1.5 mt-1">
                        <div className="w-40 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${progressPercent}%` }} className="h-full bg-primary-500" />
                        </div>
                        <span className="text-[10px] font-black text-slate-400">{currentQuestionIndex + 1} / {totalQuestions}</span>
                    </div>
                 </div>

                 <div className="flex items-center gap-3">
                    <button onClick={processSubmission} className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 md:px-8 py-3 rounded-2xl font-black text-[10px] uppercase shadow-xl transition-all active:scale-95">پایان آزمون</button>
                 </div>
              </header>

              <div className="flex-1 overflow-y-auto p-4 md:p-10 bg-slate-50 dark:bg-slate-950/50">
                 <div className="max-w-4xl mx-auto h-full flex flex-col justify-center">
                    <AnimatePresence mode="wait">
                       <motion.div 
                         key={currentQuestion.id}
                         initial={{ opacity: 0, x: 20 }}
                         animate={{ opacity: 1, x: 0 }}
                         exit={{ opacity: 0, x: -20 }}
                         transition={{ duration: 0.3, ease: "easeOut" }}
                         className="bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-[0_30px_60px_rgba(0,0,0,0.05)] space-y-10 relative"
                       >
                          <div className="space-y-6 text-right">
                             <div className="flex items-center justify-between">
                                <span className="bg-primary-50 dark:bg-primary-900/30 text-primary-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-primary-100">سوال {currentQuestionIndex + 1}</span>
                                <div className="flex gap-2">
                                    <span className="text-[10px] font-black text-slate-400">بارم: {currentQuestion.points}</span>
                                </div>
                             </div>
                             <h3 className="text-2xl md:text-3xl font-black leading-relaxed text-slate-950 dark:text-white">
                                {currentQuestion.text}
                             </h3>
                             {currentQuestion.image && (
                                <div className="rounded-3xl overflow-hidden border-4 border-slate-50 shadow-lg max-h-64 inline-block">
                                    <img src={currentQuestion.image} className="object-contain max-w-full" alt="Question" />
                                </div>
                             )}
                          </div>
                          
                          {currentQuestion.type === QuestionType.MULTIPLE_CHOICE && (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                 {currentQuestion.options?.map((opt, i) => (
                                    <button 
                                       key={i} 
                                       onClick={() => setAnswers({...answers, [currentQuestion.id]: i})}
                                       className={`group p-6 rounded-[2rem] text-right font-black transition-all border-2 flex items-center gap-6 relative overflow-hidden ${
                                         answers[currentQuestion.id] === i 
                                           ? 'bg-primary-600 text-white border-primary-500 shadow-xl scale-[1.02]' 
                                           : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 hover:border-primary-200'
                                       }`}
                                    >
                                       <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl transition-colors ${
                                          answers[currentQuestion.id] === i ? 'bg-white/20 text-white' : 'bg-slate-50 dark:bg-slate-700 text-slate-400 group-hover:text-primary-500'
                                       }`}>
                                          {i + 1}
                                       </div>
                                       <span className={`text-lg flex-1 leading-snug ${answers[currentQuestion.id] === i ? 'text-white' : 'text-slate-700 dark:text-slate-200'}`}>{opt}</span>
                                       {answers[currentQuestion.id] === i && (
                                           <motion.div layoutId="check-icon" initial={{ scale: 0 }} animate={{ scale: 1 }} className="shrink-0">
                                                <CheckCircle className="text-white" size={24} />
                                           </motion.div>
                                       )}
                                    </button>
                                 ))}
                              </div>
                          )}

                          {currentQuestion.type === QuestionType.TRUE_FALSE && (
                              <div className="flex flex-col md:flex-row gap-6">
                                  <button 
                                    onClick={() => setAnswers({...answers, [currentQuestion.id]: true})}
                                    className={`flex-1 p-8 rounded-[2.5rem] border-2 flex flex-col items-center gap-4 transition-all ${
                                        answers[currentQuestion.id] === true 
                                        ? 'bg-emerald-600 border-emerald-500 text-white shadow-xl scale-[1.02]' 
                                        : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 hover:border-emerald-200 text-slate-700 dark:text-slate-200'
                                    }`}
                                  >
                                      <div className={`w-16 h-16 rounded-3xl flex items-center justify-center ${answers[currentQuestion.id] === true ? 'bg-white/20' : 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600'}`}>
                                          <Check size={32} strokeWidth={3} />
                                      </div>
                                      <span className="text-xl font-black">صحیح</span>
                                  </button>
                                  <button 
                                    onClick={() => setAnswers({...answers, [currentQuestion.id]: false})}
                                    className={`flex-1 p-8 rounded-[2.5rem] border-2 flex flex-col items-center gap-4 transition-all ${
                                        answers[currentQuestion.id] === false 
                                        ? 'bg-rose-600 border-rose-500 text-white shadow-xl scale-[1.02]' 
                                        : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 hover:border-rose-200 text-slate-700 dark:text-slate-200'
                                    }`}
                                  >
                                      <div className={`w-16 h-16 rounded-3xl flex items-center justify-center ${answers[currentQuestion.id] === false ? 'bg-white/20' : 'bg-rose-50 dark:bg-rose-900/20 text-rose-600'}`}>
                                          <X size={32} strokeWidth={3} />
                                      </div>
                                      <span className="text-xl font-black">غلط</span>
                                  </button>
                              </div>
                          )}

                          {currentQuestion.type === QuestionType.DESCRIPTIVE && (
                              <div className="space-y-4 text-right">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">پاسخ تشریحی شما</label>
                                  <textarea 
                                    rows={6}
                                    className="w-full p-8 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-[2.5rem] font-bold text-lg text-slate-900 dark:text-white outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all shadow-inner text-right"
                                    placeholder="پاسخ خود را در این کادر تایپ کنید..."
                                    value={answers[currentQuestion.id] || ''}
                                    onChange={(e) => setAnswers({...answers, [currentQuestion.id]: e.target.value})}
                                  />
                              </div>
                          )}
                       </motion.div>
                    </AnimatePresence>

                    <div className="flex justify-between items-center mt-10 px-4">
                       <button 
                         onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
                         disabled={currentQuestionIndex === 0}
                         className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${
                            currentQuestionIndex === 0 ? 'opacity-20 pointer-events-none' : 'bg-white dark:bg-slate-900 text-slate-600 hover:text-primary-600 shadow-md'
                         }`}
                       >
                          <ChevronRight size={20} /> سوال قبلی
                       </button>

                       <div className="hidden md:flex gap-2">
                          {activeExam.questions.map((_, i) => (
                             <button 
                                key={i} onClick={() => setCurrentQuestionIndex(i)}
                                className={`w-2.5 h-2.5 rounded-full transition-all ${currentQuestionIndex === i ? 'bg-primary-500 w-8 shadow-[0_0_10px_#0ea5e9]' : 'bg-slate-200 dark:bg-slate-800'}`}
                             />
                          ))}
                       </div>

                       {currentQuestionIndex < totalQuestions - 1 ? (
                          <button 
                             onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}
                             className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-3 active:scale-95 transition-all"
                          >
                             سوال بعدی <ChevronLeft size={20} />
                          </button>
                       ) : (
                          <button 
                             onClick={processSubmission}
                             className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-3 animate-pulse active:scale-95 transition-all"
                          >
                             ثبت نهایی و اتمام آزمون <Award size={20} />
                          </button>
                       )}
                    </div>
                 </div>
              </div>

              <aside className="hidden lg:block fixed left-10 top-1/2 -translate-y-1/2 bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-2xl space-y-6">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">ناوبر سوالات</p>
                 <div className="grid grid-cols-3 gap-2">
                    {activeExam.questions.map((q, i) => (
                       <button 
                          key={q.id} onClick={() => setCurrentQuestionIndex(i)}
                          className={`w-10 h-10 rounded-xl font-black text-xs transition-all border-2 flex items-center justify-center ${
                             currentQuestionIndex === i ? 'bg-primary-600 border-primary-500 text-white' : 
                             answers[q.id] !== undefined ? 'bg-emerald-50 border-emerald-100 text-emerald-600 dark:bg-emerald-900/20' :
                             'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-400 hover:border-slate-200'
                          }`}
                       >
                          {i + 1}
                       </button>
                    ))}
                 </div>
              </aside>
          </div>
      ) : (
        <div className="space-y-10">
          <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl border w-fit">
            <button onClick={() => setActiveTab(ExamType.OFFICIAL)} className={`px-8 py-3 rounded-xl text-xs font-black transition-all ${activeTab === ExamType.OFFICIAL ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>آزمون‌های رسمی</button>
            <button onClick={() => setActiveTab(ExamType.PRACTICE)} className={`px-8 py-3 rounded-xl text-xs font-black transition-all ${activeTab === ExamType.PRACTICE ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>آزمون‌های تمرینی</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableExams.filter(e => isPreview || e.type === activeTab).map(exam => {
                const isTaken = takenExamIds.has(exam.id) && !isPreview;
                return (
                    <div key={exam.id} className={`bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 shadow-sm group transition-all relative overflow-hidden flex flex-col h-full ${isTaken ? 'opacity-70 grayscale' : 'hover:shadow-2xl'}`}>
                       {isTaken && (
                          <div className="absolute inset-0 z-10 bg-slate-900/10 backdrop-blur-[2px] flex items-center justify-center">
                             <div className="bg-white/90 dark:bg-slate-800/90 px-6 py-2 rounded-full border border-slate-200 shadow-xl flex items-center gap-2">
                                <CheckCircle size={16} className="text-emerald-500" />
                                <span className="text-[10px] font-black text-slate-700 dark:text-slate-100 uppercase tracking-widest">تکمیل شده</span>
                             </div>
                          </div>
                       )}
                       <div className="flex justify-between items-start mb-6">
                          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-600 flex items-center justify-center shadow-inner"><Zap size={24}/></div>
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{exam.durationMinutes} MINS</span>
                       </div>
                       <h3 className="text-xl font-black mb-10 line-clamp-2 text-slate-800 dark:text-white leading-snug">{exam.title}</h3>
                       <button 
                          onClick={() => handleStartRequest(exam)} 
                          disabled={isTaken}
                          className={`w-full mt-auto py-4 rounded-2xl font-black text-[10px] uppercase shadow-lg transition-all ${isTaken ? 'bg-slate-100 text-slate-400' : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 group-hover:bg-amber-500 group-hover:text-slate-950'}`}
                       >
                          {isTaken ? 'قبلاً شرکت کرده‌اید' : 'ورود به آزمون'}
                       </button>
                    </div>
                );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentDashboard;
