
import React, { useMemo } from 'react';
import { 
  Users, School, TrendingUp, BarChart3, Cpu, Database, Globe, Zap, Award, Activity, ShieldCheck, Server
} from 'lucide-react';
import StatsCard from '../components/StatsCard';
import { storageService } from '../services/storageService';
import { UserRole } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

const AdminDashboard: React.FC<{onNavigate: (v: string, data?: any) => void}> = ({ onNavigate }) => {
  const users = storageService.getUsers();
  const exams = storageService.getExams();
  const classes = storageService.getClasses();

  const stats = useMemo(() => ({
    studentsCount: users.filter(u => u.role === UserRole.STUDENT).length,
    teachersCount: users.filter(u => u.role === UserRole.TEACHER).length,
    activeExams: exams.filter(e => e.status === 'active').length,
    classesCount: classes.length,
    systemLoad: 18,
    latency: '12ms',
    dbSync: 'OPTIMIZED'
  }), [users, exams, classes]);

  const chartData = [
    { name: '00:00', load: 12 }, { name: '04:00', load: 8 }, { name: '08:00', load: 45 },
    { name: '12:00', load: 82 }, { name: '16:00', load: 64 }, { name: '20:00', load: 38 },
  ];

  return (
    <div className="space-y-8 pb-20">
      {/* Network Operations Center Header */}
      <div className="bg-slate-950 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-white/5">
         <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
         <div className="absolute -top-24 -left-24 w-80 h-80 bg-primary-600/10 rounded-full blur-[100px]"></div>
         
         <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-10">
            <div className="flex items-center gap-6">
               <div className="p-5 bg-primary-600/20 rounded-[2rem] backdrop-blur-xl border border-primary-500/30 shadow-[0_0_40px_rgba(14,165,233,0.2)]">
                  <Cpu className="text-primary-400" size={40} />
               </div>
               <div>
                  <h1 className="text-3xl font-black tracking-tighter uppercase">Strategic Operations Node</h1>
                  <div className="flex items-center gap-2 mt-2">
                     <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></div>
                     <p className="text-slate-500 font-bold text-[10px] uppercase tracking-[0.4em]">Infrastructure Monitoring Active</p>
                  </div>
               </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full lg:w-auto">
               {[
                 { label: 'Latency', val: stats.latency, icon: Activity, color: 'text-emerald-400' },
                 { label: 'Sys Load', val: `${stats.systemLoad}%`, icon: Cpu, color: 'text-blue-400' },
                 { label: 'Uptime', val: '99.9%', icon: Globe, color: 'text-amber-400' },
                 { label: 'Storage', val: stats.dbSync, icon: Database, color: 'text-indigo-400' }
               ].map((m, i) => (
                  <div key={i} className="bg-white/5 backdrop-blur-md p-4 rounded-3xl border border-white/10 flex flex-col items-center min-w-[110px] shadow-inner">
                     <m.icon size={18} className={`${m.color} mb-2`} />
                     <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">{m.label}</p>
                     <p className="text-sm font-black tracking-tighter">{m.val}</p>
                  </div>
               ))}
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard label="جمعیت هنرجویان" value={stats.studentsCount} icon={Users} colorClass="text-blue-500" bgClass="bg-blue-50 dark:bg-blue-900/20" onClick={() => onNavigate('admin_users')} />
          <StatsCard label="کادر آموزشی" value={stats.teachersCount} icon={Award} colorClass="text-purple-500" bgClass="bg-purple-50 dark:bg-purple-900/20" onClick={() => onNavigate('admin_users')} />
          <StatsCard label="آزمون‌های فعال" value={stats.activeExams} icon={Zap} colorClass="text-amber-500" bgClass="bg-amber-50 dark:bg-amber-900/20" />
          <StatsCard label="واحدهای آموزشی" value={stats.classesCount} icon={School} colorClass="text-emerald-500" bgClass="bg-emerald-50 dark:bg-emerald-900/20" onClick={() => onNavigate('admin_classes')} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-12 bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-center mb-10">
             <h3 className="font-black text-lg text-slate-800 dark:text-white flex items-center gap-3 uppercase tracking-tighter">
               <Activity size={24} className="text-primary-600" /> مانیتورینگ تراکنش‌های شبکه و بار عملیاتی
             </h3>
             <div className="flex gap-2">
                <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full text-[9px] font-black text-slate-500 uppercase">Real-Time Sync</span>
             </div>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                   <linearGradient id="loadColor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                   </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" fontSize={11} tick={{fill: '#94a3b8'}} axisLine={false} />
                <YAxis fontSize={11} tick={{fill: '#94a3b8'}} axisLine={false} />
                <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', fontWeight: 'bold', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Area type="monotone" dataKey="load" stroke="#0ea5e9" fill="url(#loadColor)" strokeWidth={4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
