
import React, { useState, useEffect } from 'react';
import { 
  Terminal, Database, Cpu, Activity, Key, ShoppingCart, 
  TrendingUp, DollarSign, Check, X, ShieldCheck, Plus, 
  Globe, Zap, AlertTriangle, Users, Package, CreditCard,
  Briefcase, BarChart3, Download, Server, HardDrive, 
  Wifi, ShieldAlert, Radio, RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, LineChart, Line } from 'recharts';

const DeveloperDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'system' | 'performance' | 'security'>('performance');
  const [metrics, setMetrics] = useState<any[]>([]);
  const toast = useToast();

  useEffect(() => {
    const data = Array.from({ length: 20 }, (_, i) => ({
      time: `${i}:00`,
      cpu: Math.floor(Math.random() * 30) + 10,
      ram: Math.floor(Math.random() * 20) + 40,
      latency: Math.floor(Math.random() * 15) + 5
    }));
    setMetrics(data);

    const interval = setInterval(() => {
      setMetrics(prev => {
        const newData = [...prev.slice(1)];
        newData.push({
          time: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          cpu: Math.floor(Math.random() * 40) + 15,
          ram: Math.floor(Math.random() * 10) + 50,
          latency: Math.floor(Math.random() * 20) + 8
        });
        return newData;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const MetricCard = ({ label, val, icon: Icon, color, desc }: any) => (
    <div className="bg-slate-900/40 border border-emerald-500/10 p-6 rounded-[2rem] flex items-center gap-5 shadow-2xl hover:border-emerald-500/30 transition-all group">
       <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-emerald-500/5 ${color} shadow-lg group-hover:scale-110 transition-transform`}>
          <Icon size={28} />
       </div>
       <div className="text-right">
          <p className="text-[9px] text-slate-500 font-black uppercase tracking-[0.2em] mb-1">{label}</p>
          <p className="text-2xl font-black text-white leading-none font-mono">{val}</p>
          {desc && <p className="text-[9px] text-slate-600 mt-1 font-bold">{desc}</p>}
       </div>
    </div>
  );

  const ServiceStatus = ({ name, status, type }: { name: string, status: 'online' | 'busy', type: string }) => (
    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all">
       <div className="flex items-center gap-3">
          <div className={`w-2 h-2 rounded-full ${status === 'online' ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-amber-500 animate-pulse'}`}></div>
          <div>
             <p className="text-xs font-black text-white uppercase tracking-wider">{name}</p>
             <p className="text-[9px] text-slate-500 font-bold uppercase">{type}</p>
          </div>
       </div>
       <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${status === 'online' ? 'text-emerald-400 bg-emerald-400/10' : 'text-amber-400 bg-amber-400/10'}`}>
          {status === 'online' ? 'آنلاین' : 'مشغول'}
       </span>
    </div>
  );

  return (
    <div className="space-y-8 bg-[#050505] -m-8 p-10 min-h-screen text-emerald-400 font-mono selection:bg-emerald-500/20 overflow-x-hidden" dir="rtl">
      
      <div className="flex flex-col xl:flex-row justify-between items-center border-b border-white/5 pb-10 gap-8">
        <div className="flex items-center gap-6">
           <div className="w-20 h-20 bg-emerald-500/10 rounded-[2rem] flex items-center justify-center text-emerald-500 border border-emerald-500/20 shadow-[0_0_60px_rgba(16,185,129,0.1)]">
              <Cpu size={44} className="animate-pulse" />
           </div>
           <div className="text-right">
              <h1 className="text-4xl font-black text-white tracking-tighter uppercase">کنسول مرکزی زیرساخت</h1>
              <div className="flex items-center gap-4 mt-2">
                 <div className="px-3 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-[10px] font-black uppercase tracking-widest">تراکم عملیاتی v2.8</div>
                 <span className="text-slate-600 font-black text-[10px] uppercase tracking-[0.4em]">حالت: ریشه (ROOT_ACCESS)</span>
              </div>
           </div>
        </div>
        
        <div className="flex bg-slate-950 p-1.5 rounded-[2rem] border border-white/10 shadow-2xl">
           {[
             { id: 'performance', label: 'عملکرد شبکه', icon: Activity },
             { id: 'security', label: 'امنیت و نفوذ', icon: ShieldCheck },
             { id: 'system', label: 'وقایع هسته', icon: Terminal },
           ].map(tab => (
             <button 
               key={tab.id}
               onClick={() => setActiveTab(tab.id as any)}
               className={`flex items-center gap-2.5 px-7 py-4 rounded-[1.5rem] text-[11px] font-black transition-all ${activeTab === tab.id ? 'bg-emerald-500 text-black shadow-[0_0_30px_rgba(16,185,129,0.3)] scale-105' : 'text-slate-500 hover:text-white'}`}
             >
               <tab.icon size={16} /> {tab.label}
             </button>
           ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'performance' && (
          <motion.div key="perf" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricCard label="بار پردازنده" val={`${metrics[metrics.length-1]?.cpu}%`} icon={Cpu} color="text-blue-400" desc="خوشه ابری اختصاصی" />
                <MetricCard label="مصرف حافظه" val={`${metrics[metrics.length-1]?.ram}%`} icon={HardDrive} color="text-emerald-400" desc="حافظه ECC فیزیکی" />
                <MetricCard label="تأخیر شبکه" val={`${metrics[metrics.length-1]?.latency}ms`} icon={Radio} color="text-amber-400" desc="پروتکل QUIC" />
                <MetricCard label="پایداری گره‌ها" val="99.9%" icon={Wifi} color="text-indigo-400" desc="سیستم خودترمیمی" />
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-8 bg-slate-900/30 border border-white/5 p-8 rounded-[3rem] shadow-2xl">
                   <h3 className="text-white font-black text-xs uppercase tracking-widest mb-8 flex items-center gap-2">
                      <Activity size={18} className="text-emerald-500" /> تله‌متری زنده منابع سیستم
                   </h3>
                   <div className="h-80 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                         <AreaChart data={metrics}>
                            <defs>
                               <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/><stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                               </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                            <XAxis dataKey="time" hide />
                            <YAxis hide domain={[0, 100]} />
                            <Area type="monotone" dataKey="cpu" stroke="#3b82f6" fill="url(#cpuGrad)" strokeWidth={3} isAnimationActive={false} />
                            <Area type="monotone" dataKey="ram" stroke="#10b981" fillOpacity={0.1} fill="#10b981" strokeWidth={3} isAnimationActive={false} />
                         </AreaChart>
                      </ResponsiveContainer>
                   </div>
                </div>

                <div className="lg:col-span-4 bg-white/2 backdrop-blur-md p-8 rounded-[3rem] border border-white/5 shadow-2xl">
                   <h3 className="text-white font-black text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
                      <Server size={18} className="text-blue-400" /> وضعیت سرویس‌های حیاتی
                   </h3>
                   <div className="space-y-3">
                      <ServiceStatus name="پایگاه داده (SQL)" status="online" type="ثبت تراکنش" />
                      <ServiceStatus name="خوشه هوش مصنوعی" status="busy" type="استنتاج زنده" />
                      <ServiceStatus name="درگاه پیام‌رسان" status="online" type="سوکت فعال" />
                      <ServiceStatus name="سرور فایل" status="online" type="ذخیره‌ساز S3" />
                   </div>
                </div>
             </div>
          </motion.div>
        )}

        {activeTab === 'system' && (
           <motion.div key="system" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-slate-950 rounded-[3rem] border border-white/10 h-[500px] flex flex-col shadow-2xl overflow-hidden" dir="ltr">
              <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/2">
                 <span className="text-[9px] font-black opacity-30 tracking-[0.3em]">KERNEL_LOG_VIEWER</span>
                 <div className="flex gap-1.5"><div className="w-2 h-2 rounded-full bg-rose-500/40" /><div className="w-2 h-2 rounded-full bg-amber-500/40" /><div className="w-2 h-2 rounded-full bg-emerald-500/40" /></div>
              </div>
              <div className="flex-1 p-8 overflow-y-auto space-y-2 text-[10px] font-mono leading-relaxed text-emerald-500/60 custom-scrollbar">
                 <div>[ {new Date().toISOString()} ] AUTH: Validating SuperAdmin session...</div>
                 <div>[ {new Date().toISOString()} ] NETWORK: Handshake with Node_Tehran_01 established.</div>
                 <div className="text-blue-400">&rarr; Auto-scaling: Adding 2 worker instances for Messenger service.</div>
                 <div className="text-amber-500 font-black mt-4">ALERT: Traffic peak detected on API_v2_exams.</div>
                 <div className="mt-6 text-white font-black">root@central-engine: ~ # <span className="animate-pulse">_</span></div>
              </div>
           </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default DeveloperDashboard;
