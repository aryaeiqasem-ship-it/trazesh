
import React, { useState, useEffect, useRef } from 'react';
import { storageService } from '../services/storageService';
import { Resource, ClassEntity } from '../types';
import { 
  FolderOpen, Plus, Trash2, Link, Video, FileText, 
  Search, Upload, X, Loader2, Download, CheckCircle,
  File, Paperclip, Globe, Save, Image as ImageIcon, ExternalLink,
  FileUp, AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const TeacherResources: React.FC = () => {
  const [resources, setResources] = useState<Resource[]>([]);
  const [classes, setClasses] = useState<ClassEntity[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadMethod, setUploadMethod] = useState<'link' | 'file'>('file');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const toast = useToast();

  const [formData, setFormData] = useState<Partial<Resource>>({ 
    title: '', 
    description: '', 
    type: 'pdf', 
    url: '', 
    classId: '' 
  });

  useEffect(() => {
    setResources(storageService.getResources());
    setClasses(storageService.getClasses());
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      // Auto-set type based on extension
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (['jpg', 'jpeg', 'png', 'svg', 'webp'].includes(ext || '')) setFormData(p => ({ ...p, type: 'image' }));
      else if (['mp4', 'mov', 'avi'].includes(ext || '')) setFormData(p => ({ ...p, type: 'video' }));
      else setFormData(p => ({ ...p, type: 'pdf' }));
      
      if (!formData.title) setFormData(p => ({ ...p, title: file.name.split('.')[0] }));
    }
  };

  const handleSave = async () => {
    if (!formData.title || !formData.classId) {
      toast.error('لطفاً تمامی فیلدهای الزامی را تکمیل کنید.');
      return;
    }

    if (uploadMethod === 'link' && !formData.url) {
      toast.error('لطفاً لینک منبع را وارد کنید.');
      return;
    }

    if (uploadMethod === 'file' && !selectedFile) {
      toast.error('لطفاً یک فایل برای آپلود انتخاب کنید.');
      return;
    }

    setIsSaving(true);
    setUploadProgress(0);

    try {
      let finalUrl = formData.url;

      if (uploadMethod === 'file' && selectedFile) {
        // Simulate upload progress
        const interval = setInterval(() => {
          setUploadProgress(prev => {
            if (prev >= 90) {
              clearInterval(interval);
              return 90;
            }
            return prev + 10;
          });
        }, 100);

        const uploadRes = await storageService.uploadFile(selectedFile);
        finalUrl = uploadRes.url;
        
        clearInterval(interval);
        setUploadProgress(100);
      }

      const newResource: Resource = {
        id: `res_${Date.now()}`,
        title: formData.title!,
        description: formData.description,
        type: formData.type as any,
        url: finalUrl!,
        classId: formData.classId!,
        addedBy: 'teacher_01',
        dateAdded: new Date().toISOString()
      };

      const updated = [newResource, ...resources];
      setResources(updated);
      storageService.saveResources(updated);
      
      setTimeout(() => {
        toast.success('منبع آموزشی جدید با موفقیت ثبت شد.');
        setIsModalOpen(false);
        resetForm();
      }, 500);

    } catch (err) {
      toast.error('خطا در ثبت اطلاعات یا آپلود فایل.');
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', type: 'pdf', url: '', classId: '' });
    setSelectedFile(null);
    setUploadProgress(0);
    setUploadMethod('file');
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const updated = resources.filter(r => r.id !== deleteId);
    setResources(updated);
    storageService.saveResources(updated);
    setDeleteId(null);
    toast.info('منبع آموزشی حذف شد.');
  };

  const filteredResources = resources.filter(r => 
    r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    classes.find(c => c.id === r.classId)?.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getIcon = (type: string) => {
    switch(type) {
      case 'pdf': return <FileText className="text-rose-500" size={24} />;
      case 'video': return <Video className="text-blue-500" size={24} />;
      case 'image': return <ImageIcon className="text-emerald-500" size={24} />;
      default: return <Link className="text-indigo-500" size={24} />;
    }
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-3">
            <FolderOpen className="text-primary-600" size={32} />
            مدیریت کتابخانه دیجیتال
          </h1>
          <p className="text-sm text-slate-500 font-bold mt-1">بارگذاری جزوات، ویدیوها و محتوای مکمل آموزشی برای هنرجویان</p>
        </div>
        <button 
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3.5 rounded-2xl flex items-center gap-3 shadow-xl font-black transition-all hover:scale-105 active:scale-95"
        >
          <Plus size={20} /> ثبت محتوای جدید
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row gap-4 items-center">
         <div className="relative flex-1 w-full">
            <input 
              type="text" 
              placeholder="جستجو در عنوان محتوا یا کلاس..." 
              className="w-full pl-4 pr-12 py-3.5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-primary-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute right-4 top-4 text-slate-400" size={20} />
         </div>
         <div className="bg-indigo-50 dark:bg-indigo-900/30 px-6 py-3.5 rounded-2xl border border-indigo-100 dark:border-indigo-800 shrink-0">
            <span className="text-xs font-black text-indigo-700 dark:text-indigo-400 uppercase tracking-widest">{resources.length} مورد ثبت شده</span>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence mode="popLayout">
          {filteredResources.map((res) => {
            const targetClass = classes.find(c => c.id === res.classId);
            return (
              <motion.div 
                key={res.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group relative"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl shadow-inner group-hover:scale-110 transition-transform">
                    {getIcon(res.type)}
                  </div>
                  <button 
                    onClick={() => setDeleteId(res.id)}
                    className="p-2.5 text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-black text-lg text-slate-900 dark:text-slate-100 mb-2 line-clamp-1 group-hover:text-primary-600 transition-colors">{res.title}</h3>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-[10px] font-black bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-3 py-1 rounded-full uppercase tracking-tighter">
                      {targetClass?.title || 'کلاس عمومی'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold">{new Date(res.dateAdded).toLocaleDateString('fa-IR')}</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-bold line-clamp-2 h-10">
                    {res.description || 'توضیحات تکمیلی ثبت نشده است.'}
                  </p>
                </div>

                <div className="flex gap-2">
                  <a 
                    href={res.url} 
                    target="_blank" 
                    rel="noreferrer"
                    className="flex-1 py-3.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-[10px] font-black uppercase shadow-lg hover:bg-primary-600 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    {res.type === 'link' ? <ExternalLink size={14} /> : <Download size={14} />}
                    مشاهده / دریافت
                  </a>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {filteredResources.length === 0 && (
        <div className="py-40 text-center bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
          <FolderOpen size={64} className="mx-auto text-slate-200 dark:text-slate-800 mb-6" />
          <p className="text-slate-400 font-black text-xl">منبع آموزشی یافت نشد.</p>
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => !isSaving && setIsModalOpen(false)}
        title="ثبت منبع آموزشی جدید"
        maxWidth="max-w-4xl"
      >
         <div className="p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-2">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest block mr-2">عنوان منبع</label>
                  <input 
                    className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                    placeholder="مثال: جزوه فصل دوم گسسته"
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                  />
               </div>
               <div className="space-y-2">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest block mr-2">کلاس هدف</label>
                  <select 
                    className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                    value={formData.classId}
                    onChange={e => setFormData({...formData, classId: e.target.value})}
                  >
                     <option value="">انتخاب کلاس...</option>
                     {classes.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                  </select>
               </div>
            </div>

            <div className="space-y-4">
               <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest block mr-2">روش بارگذاری</label>
               <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit">
                  <button 
                    onClick={() => setUploadMethod('file')}
                    className={`px-8 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${uploadMethod === 'file' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-md' : 'text-slate-500'}`}
                  >
                     <FileUp size={16} /> آپلود فایل
                  </button>
                  <button 
                    onClick={() => setUploadMethod('link')}
                    className={`px-8 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${uploadMethod === 'link' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-md' : 'text-slate-500'}`}
                  >
                     <Globe size={16} /> لینک خارجی
                  </button>
               </div>

               <AnimatePresence mode="wait">
                  {uploadMethod === 'file' ? (
                     <motion.div 
                        key="file-upload"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-4"
                     >
                        {!selectedFile ? (
                           <div 
                              onClick={() => fileInputRef.current?.click()}
                              className="border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[2.5rem] p-12 text-center cursor-pointer hover:border-primary-500 hover:bg-primary-50/20 transition-all group"
                           >
                              <Upload className="mx-auto text-slate-300 group-hover:text-primary-500 transition-colors mb-4" size={48} />
                              <h4 className="text-sm font-black text-slate-700 dark:text-slate-200 mb-2">انتخاب یا رها کردن فایل</h4>
                              <p className="text-xs text-slate-400 font-bold uppercase tracking-tighter">حداکثر حجم مجاز: ۵۰ مگابایت</p>
                              <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} />
                           </div>
                        ) : (
                           <div className="bg-primary-50 dark:bg-primary-900/10 p-6 rounded-[2rem] border-2 border-primary-200 dark:border-primary-800 flex items-center justify-between group">
                              <div className="flex items-center gap-4">
                                 <div className="w-14 h-14 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center text-primary-600 shadow-lg"><FileText size={28}/></div>
                                 <div>
                                    <p className="font-black text-slate-800 dark:text-white truncate max-w-[200px]">{selectedFile.name}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase">{(selectedFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                                 </div>
                              </div>
                              <button onClick={() => setSelectedFile(null)} className="p-3 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><X size={20}/></button>
                           </div>
                        )}
                     </motion.div>
                  ) : (
                     <motion.div 
                        key="link-upload"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-2"
                     >
                        <div className="relative">
                           <input 
                              className="w-full p-5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 dir-ltr text-left text-slate-900 dark:text-white"
                              placeholder="https://example.com/file.pdf"
                              value={formData.url}
                              onChange={e => setFormData({...formData, url: e.target.value})}
                           />
                           <Link className="absolute left-4 top-5 text-slate-300" size={24} />
                        </div>
                        <p className="flex items-center gap-2 text-[10px] text-slate-400 font-bold uppercase mt-2 px-2"><AlertCircle size={12}/> لینک‌های مستقیم از گوگل درایو یا دراپ‌باکس توصیه می‌شود.</p>
                     </motion.div>
                  )}
               </AnimatePresence>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-2">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest block mr-2">نوع دسته‌بندی</label>
                  <div className="flex p-1 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                    {[
                      { id: 'pdf', label: 'PDF', icon: FileText },
                      { id: 'video', label: 'ویدیو', icon: Video },
                      { id: 'image', label: 'تصویر', icon: ImageIcon },
                      { id: 'link', label: 'لینک', icon: Globe }
                    ].map(type => (
                      <button 
                        key={type.id}
                        onClick={() => setFormData({...formData, type: type.id as any})}
                        className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all ${formData.type === type.id ? 'bg-white dark:bg-slate-700 shadow-lg text-primary-600' : 'text-slate-400'}`}
                      >
                        <type.icon size={18} />
                        <span className="text-[9px] font-black">{type.label}</span>
                      </button>
                    ))}
                  </div>
               </div>
               <div className="space-y-2">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest block mr-2">توضیحات تکمیلی (اختیاری)</label>
                  <textarea 
                     rows={3}
                     className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                     placeholder="نکاتی که دانش‌آموز باید بداند..."
                     value={formData.description}
                     onChange={e => setFormData({...formData, description: e.target.value})}
                  />
               </div>
            </div>

            {isSaving && (
               <div className="space-y-2">
                  <div className="flex justify-between text-[10px] font-black text-primary-600 uppercase tracking-widest">
                     <span className="flex items-center gap-2"><Loader2 size={14} className="animate-spin" /> در حال رمزنگاری و انتقال امن به سرور مرکزی...</span>
                     <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                     <motion.div initial={{ width: 0 }} animate={{ width: `${uploadProgress}%` }} className="h-full bg-primary-600 shadow-[0_0_10px_rgba(14,165,233,0.5)]" />
                  </div>
               </div>
            )}

            <div className="flex justify-end gap-3 pt-6 border-t border-slate-100 dark:border-slate-800">
               <button 
                  onClick={() => setIsModalOpen(false)} 
                  disabled={isSaving}
                  className="px-10 py-4 text-slate-500 font-black hover:text-slate-700 transition-colors uppercase text-xs tracking-widest"
               >
                  انصراف
               </button>
               <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="bg-primary-600 hover:bg-primary-700 text-white px-14 py-4 rounded-2xl font-black shadow-2xl shadow-primary-500/30 flex items-center gap-3 transition-all active:scale-95"
               >
                  {isSaving ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
                  ثبت نهایی و انتشار در کتابخانه
               </button>
            </div>
         </div>
      </Modal>

      <ConfirmationModal 
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="حذف منبع آموزشی"
        description="آیا از حذف این منبع اطمینان دارید؟ این عملیات باعث حذف دسترسی تمامی هنرجویان به این محتوا خواهد شد."
        confirmText="بله، حذف شود"
      />
    </div>
  );
};

export default TeacherResources;
