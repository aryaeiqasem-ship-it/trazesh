
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { Major } from '../types';
import { Search, Plus, Edit, Trash2, Bookmark, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const AdminMajors: React.FC = () => {
  const [majors, setMajors] = useState<Major[]>(() => storageService.getMajors());
  const [searchTerm, setSearchTerm] = useState('');
  const toast = useToast();
  
  // Persist changes
  useEffect(() => {
    storageService.saveMajors(majors);
  }, [majors]);
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMajor, setEditingMajor] = useState<Major | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  // Form State
  const [formData, setFormData] = useState<Partial<Major>>({
    title: ''
  });

  const filteredMajors = majors.filter(m => m.title.includes(searchTerm));

  const handleOpenModal = (major?: Major) => {
    if (major) {
      setEditingMajor(major);
      setFormData({ ...major });
    } else {
      setEditingMajor(null);
      setFormData({
        title: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.title) {
      toast.error('عنوان رشته الزامی است.');
      return;
    }

    const newMajor: Major = {
      id: editingMajor ? editingMajor.id : `m_${Date.now()}`,
      title: formData.title!
    };

    if (editingMajor) {
      setMajors(prev => prev.map(m => m.id === editingMajor.id ? newMajor : m));
      toast.success('رشته با موفقیت ویرایش شد.');
    } else {
      setMajors(prev => [...prev, newMajor]);
      toast.success('رشته جدید اضافه شد.');
    }
    setIsModalOpen(false);
  };

  const handleDeleteClick = (id: string) => {
    setDeleteId(id);
  };

  const confirmDelete = () => {
    if (deleteId) {
      setMajors(prev => prev.filter(m => m.id !== deleteId));
      toast.info('رشته با موفقیت حذف شد.');
      setDeleteId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">مدیریت رشته‌های تحصیلی</h1>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow-lg shadow-primary-500/30 transition-all"
        >
          <Plus size={18} />
          <span>افزودن رشته جدید</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative">
          <input
            type="text"
            placeholder="جستجو نام رشته..."
            className="w-full pl-4 pr-10 py-2 border border-slate-300 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute right-3 top-2.5 text-slate-400" size={18} />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-sm">
              <tr>
                <th className="px-6 py-4 font-medium">عنوان رشته</th>
                <th className="px-6 py-4 font-medium">شناسه</th>
                <th className="px-6 py-4 font-medium">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              <AnimatePresence>
                {filteredMajors.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-slate-400">
                      رشته‌ای یافت نشد.
                    </td>
                  </tr>
                ) : (
                  filteredMajors.map((major, index) => (
                    <motion.tr 
                      key={major.id} 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    >
                      <td className="px-6 py-4 font-medium text-slate-800 dark:text-slate-200 flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                          <Bookmark size={18} />
                        </div>
                        {major.title}
                      </td>
                      <td className="px-6 py-4 text-slate-500 dark:text-slate-400 font-mono text-sm">
                         {major.id}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => handleOpenModal(major)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition-colors"
                          >
                            <Edit size={18} />
                          </button>
                          <button 
                            onClick={() => handleDeleteClick(major.id)}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))
                )}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </div>

      {/* Major Modal */}
      <Modal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={
          <>
             {editingMajor ? <Edit size={20} className="text-primary-600" /> : <Plus size={20} className="text-primary-600" />}
             {editingMajor ? 'ویرایش رشته' : 'افزودن رشته جدید'}
          </>
        }
      >
        <div className="p-6 space-y-4">
          <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">عنوان رشته</label>
              <input 
                type="text" 
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full p-2.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-black dark:text-white rounded-lg outline-none focus:ring-2 focus:ring-primary-500"
                placeholder="مثال: علوم انسانی"
              />
          </div>
        </div>

        <div className="p-6 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3 bg-slate-50 dark:bg-slate-800/50 sticky bottom-0">
          <button 
            onClick={() => setIsModalOpen(false)}
            className="px-5 py-2.5 text-slate-600 dark:text-slate-300 font-medium hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            انصراف
          </button>
          <button 
            onClick={handleSave}
            className="px-5 py-2.5 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 shadow-lg shadow-green-500/20 transition-all flex items-center gap-2"
          >
            <Save size={18} />
            <span>{editingMajor ? 'بروزرسانی' : 'ثبت'}</span>
          </button>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal 
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={confirmDelete}
        title="حذف رشته"
        description="آیا از حذف این رشته اطمینان دارید؟ این عملیات غیرقابل بازگشت است."
      />
    </div>
  );
};

export default AdminMajors;
