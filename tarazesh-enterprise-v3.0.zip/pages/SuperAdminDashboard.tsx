
import React, { useState, useMemo, useEffect } from 'react';
import { 
  DollarSign, Key, TrendingUp, Briefcase, Plus, Search, 
  Download, ShieldCheck, Clock, CheckCircle, 
  AlertCircle, Activity, Crown, Globe,
  CreditCard, BarChart3, Package, Trash2, Edit, RefreshCcw,
  Zap, Server, ShieldAlert, Cpu, Terminal
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { storageService } from '../services/storageService';
import { LicenseRecord, SalesRecord } from '../types';
import { useToast } from '../contexts/ToastContext';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const SuperAdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'sales' | 'licenses' | 'system'>('sales');
  const [licenses, setLicenses] = useState<LicenseRecord[]>([]);
  const [sales, setSales] = useState<SalesRecord[]>([]);
  const [isLicenseModalOpen, setIsLicenseModalOpen] = useState(false);
  const [deleteLicId, setDeleteLicId] = useState<string | null>(null);
  const toast = useToast();

  const [licForm, setLicForm] = useState({
    orgName: '',
    type: 'PRO' as LicenseRecord['type'],
    maxUsers: 100,
    price: 5000000,
    expiryDate: '1404/01/01'
  });

  useEffect(() => {
    setLicenses(storageService.getLicenses());
    setSales(storageService.getSales());
  }, []);

  const stats = useMemo(() => {
    const totalRevenue = sales.reduce((acc, s) => acc + s.amount, 0);
    const activeLicenses = licenses.filter(l => l.status === 'ACTIVE').length;
    return {
      revenue: totalRevenue.toLocaleString(),
      activeOrgs: activeLicenses,
      growth: '۲۸.۴٪+',
      retention: '۹۸.۲٪'
    };
  }, [sales, licenses]);

  const handleCreateLicense = (e: React.FormEvent) => {
    e.preventDefault();
    const newKey = `EDUP-${licForm.orgName.substring(0,3).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${new Date().getFullYear()}`;
    
    const newLic: LicenseRecord = {
      id: `L-${Date.now()}`,
      orgName: licForm.orgName,
      key: newKey,
      type: licForm.type,
      issueDate: new Date().toLocaleDateString('fa-IR'),
      expiryDate: licForm.expiryDate,
      maxUsers: licForm.maxUsers,
      status: 'ACTIVE',
      price: licForm.price
    };

    const newSale: SalesRecord = {
      id: `S-${Date.now()}`,
      orgName: licForm.orgName,
      amount: licForm.price,
      date: new Date().toLocaleDateString('fa-IR'),
      plan: `${licForm.type === 'ENTERPRISE' ? 'سازمانی' : licForm.type === 'PRO' ? 'حرفه‌ای' : 'آزمایشی'}`
    };

    const updatedLics = [newLic, ...licenses];
    const updatedSales = [newSale, ...sales];

    setLicenses(updatedLics);
    setSales(updatedSales);
    storageService.saveLicenses(updatedLics);
    storageService.saveSales(updatedSales);

    toast.success(`مجوز دسترسی برای ${licForm.orgName} صادر و کد فعال‌سازی تولید شد.`);
    setIsLicenseModalOpen(false);
    setLicForm({ orgName: '', type: 'PRO', maxUsers: 100, price: 5000000, expiryDate: '1404/01/01' });
  };

  const confirmDeleteLicense = () => {
    if (!deleteLicId) return;
    const updated = licenses.filter(l => l.id !== deleteLicId);
    setLicenses(updated);
    storageService.saveLicenses(updated);
    setDeleteLicId(null);
    toast.info('لایسنس با موفقیت ابطال و از شبکه خارج شد.');
  };

  const chartData = [
    { name: 'فروردین', revenue: 45000000 },
    { name: 'اردیبهشت', revenue: 52000000 },
    { name: 'خرداد', revenue: 48000000 },
    { name: 'تیر', revenue: 75000000 },
    { name: 'مرداد', revenue: 92000000 },
    { name: 'شهریور', revenue: 110000000 },
    { name: 'مهر', revenue: 145000000 },
  ];

  const pieData = [
    { name: 'سازمانی', value: 45, color: '#f59e0b' },
    { name: 'حرفه‌ای', value: 35, color: '#0ea5e9' },
    { name: 'آزمایشی', value: 20, color: '#64748b' },
  ];

  const MetricCard = ({ label, val, icon: Icon, color, trend }: any) => (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-[2.5rem] flex items-center gap-5 shadow-inner group hover:bg-white/10 transition-all">
       <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-white/5 ${color} shadow-lg group-hover:scale-110 transition-transform`}>
          <Icon size={28} />
       </div>
       <div>
          <div className="flex items-center gap-2">
            <p className="text-[9px] text-slate-500 font-black uppercase tracking-[0.2em]">{label}</p>
            {trend && <span className="text-[8px] text-emerald-400 font-bold">{trend}</span>}
          </div>
          <p className="text-2xl font-black text-white tracking-tighter">{val}</p>
       </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-32 bg-slate-950 -m-8 p-10 min-h-screen text-slate-100 font-sans selection:bg-amber-500/30 overflow-x-hidden" dir="rtl">
      
      {/* هدر فرماندهی استراتژیک */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-black p-12 rounded-[4rem] border border-white/5 shadow-[0_50px_100_rgba(0,0,0,0.5)] relative overflow-hidden">
         <div className="absolute top-0 right-0 w-full h-full opacity-5 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
         <div className="absolute -top-24 -left-24 w-[500px] h-[500px] bg-amber-500/10 rounded-full blur-[150px]"></div>
         
         <div className="relative z-10 flex flex-col xl:flex-row justify-between items-center gap-12 text-right">
            <div className="flex items-center gap-8">
               <motion.div 
                 animate={{ rotate: [0, 5, -5, 0] }}
                 transition={{ repeat: Infinity, duration: 6 }}
                 className="p-6 bg-amber-500 text-slate-950 rounded-[2.5rem] shadow-[0_0_50px_rgba(245,158,11,0.3)] border-4 border-amber-400/50"
               >
                  <Crown size={52} />
               </motion.div>
               <div>
                  <h1 className="text-5xl font-black tracking-tighter text-white uppercase">هسته مدیریت درآمد</h1>
                  <div className="flex items-center gap-4 mt-3">
                     <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20 text-[10px] font-black uppercase tracking-widest">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                        اتصال سراسری فعال
                     </div>
                     <span className="text-slate-600 font-black text-[10px] uppercase tracking-[0.4em]">دسترسی: مدیر ارشد سازمان</span>
                  </div>
               </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full xl:w-auto">
               <MetricCard label="درآمد ناخالص" val={`${stats.revenue} T`} icon={DollarSign} color="text-emerald-400" trend="۱۲٪+" />
               <MetricCard label="سازمان‌های فعال" val={stats.activeOrgs} icon={Globe} color="text-blue-400" />
               <MetricCard label="پایداری شبکه" val={stats.retention} icon={Activity} color="text-indigo-400" />
               <MetricCard label="وضعیت عملیاتی" val="بهینه" icon={Zap} color="text-amber-400" />
            </div>
         </div>
      </div>

      {/* ناوبری اصلی */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
         <div className="flex p-2 bg-white/5 backdrop-blur-xl rounded-[2.5rem] border border-white/10 shadow-2xl">
            {[
               { id: 'sales', label: 'تحلیل مالی و رشد', icon: BarChart3 },
               { id: 'licenses', label: 'مدیریت لایسنس‌ها', icon: Key },
               { id: 'system', label: 'زیرساخت و امنیت', icon: Server },
            ].map(tab => (
               <button 
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-10 py-5 rounded-[2rem] text-xs font-black transition-all flex items-center gap-3 ${activeTab === tab.id ? 'bg-amber-500 text-slate-950 shadow-[0_0_40px_rgba(245,158,11,0.3)] scale-105' : 'text-slate-500 hover:text-white'}`}
               >
                  <tab.icon size={18} /> {tab.label}
               </button>
            ))}
         </div>

         <div className="flex gap-3">
            <button className="p-4 bg-white/5 hover:bg-white/10 text-slate-400 rounded-2xl transition-all border border-white/5 shadow-xl"><RefreshCcw size={20}/></button>
            <button onClick={() => setIsLicenseModalOpen(true)} className="px-10 py-4 bg-white text-slate-950 rounded-[1.8rem] font-black text-sm flex items-center gap-3 shadow-[0_20px_40px_rgba(255,255,255,0.1)] hover:scale-105 active:scale-95 transition-all">
               <Plus size={24} /> صدور لایسنس استراتژیک
            </button>
         </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'sales' && (
          <motion.div key="sales" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-10">
             <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                <div className="lg:col-span-8 bg-white/5 backdrop-blur-md p-10 rounded-[3.5rem] border border-white/5 shadow-2xl">
                   <div className="flex justify-between items-center mb-12">
                      <h3 className="text-white font-black text-lg flex items-center gap-3 uppercase tracking-tighter">
                         <TrendingUp size={24} className="text-emerald-500" /> ماتریس جریان درآمدی
                      </h3>
                      <div className="flex gap-3">
                         <span className="text-[10px] font-black bg-white/5 px-4 py-2 rounded-full text-slate-400">دوره ۶ ماهه</span>
                         <button className="p-2 text-slate-500 hover:text-white transition-colors"><Download size={18}/></button>
                      </div>
                   </div>
                   <div className="h-96 w-full">
                     <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={chartData}>
                         <defs>
                            <linearGradient id="revColor" x1="0" y1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2}/><stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                            </linearGradient>
                         </defs>
                         <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                         <XAxis dataKey="name" fontSize={11} tick={{fill: '#475569'}} axisLine={false} />
                         <YAxis fontSize={11} tick={{fill: '#475569'}} axisLine={false} tickFormatter={(val) => `${(val/1000000)}M`} />
                         <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', color: '#fff', fontWeight: 'bold' }} />
                         <Area type="monotone" dataKey="revenue" stroke="#f59e0b" fill="url(#revColor)" strokeWidth={5} />
                       </AreaChart>
                     </ResponsiveContainer>
                   </div>
                </div>

                <div className="lg:col-span-4 space-y-8">
                   <div className="bg-white/5 backdrop-blur-md p-10 rounded-[3.5rem] border border-white/5 flex flex-col items-center justify-center shadow-2xl">
                      <h3 className="text-slate-400 font-black text-[10px] mb-10 uppercase tracking-[0.3em]">سهم بازار بر اساس سطح لایسنس</h3>
                      <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                           <PieChart>
                              <Pie data={pieData} innerRadius={70} outerRadius={90} paddingAngle={8} dataKey="value">
                                 {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />)}
                              </Pie>
                              <Tooltip />
                           </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="grid grid-cols-1 gap-4 w-full mt-10">
                         {pieData.map(d => (
                            <div key={d.name} className="flex items-center justify-between p-3 bg-white/2 rounded-2xl border border-white/5">
                               <div className="flex items-center gap-3">
                                  <div className="w-2.5 h-2.5 rounded-full shadow-lg" style={{backgroundColor: d.color}}></div>
                                  <span className="text-[10px] font-black text-slate-300 uppercase">{d.name}</span>
                               </div>
                               <span className="text-[10px] font-mono text-white font-black">{d.value}٪</span>
                            </div>
                         ))}
                      </div>
                   </div>

                   <div className="bg-amber-500 rounded-[3rem] p-10 text-slate-950 shadow-2xl shadow-amber-500/20 relative overflow-hidden group cursor-pointer">
                      <div className="absolute top-0 right-0 p-8 opacity-20 group-hover:rotate-12 transition-transform"><Activity size={100}/></div>
                      <h4 className="text-xl font-black mb-2">توزیع سود نمایندگان</h4>
                      <p className="text-xs font-bold opacity-70 leading-relaxed mb-6">تسویه حساب آنی با شرکای تجاری و نمایندگان استانی سیستم.</p>
                      <button className="w-full py-4 bg-slate-950 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-2xl">پردازش تراکنش‌های مالی</button>
                   </div>
                </div>
             </div>

             {/* جدول تراکنش‌ها */}
             <div className="bg-white/5 backdrop-blur-md rounded-[4rem] border border-white/5 overflow-hidden shadow-2xl">
                <div className="p-10 border-b border-white/5 flex justify-between items-center bg-white/2">
                   <div>
                      <h3 className="font-black text-2xl">آرشیو مالی قراردادها</h3>
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-2">جریان درآمدی سازمان‌های تحت شبکه</p>
                   </div>
                   <button className="px-6 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-black transition-all flex items-center gap-2 border border-white/10"><Download size={16}/> خروجی گزارش اکسل</button>
                </div>
                <div className="overflow-x-auto">
                   <table className="w-full text-right">
                      <thead>
                         <tr className="bg-white/2 text-[10px] font-black text-slate-500 uppercase tracking-widest border-b border-white/5">
                            <th className="px-10 py-8">نام سازمان / مشتری</th>
                            <th className="px-10 py-8">ارزش قرارداد (T)</th>
                            <th className="px-10 py-8">پلن عملیاتی</th>
                            <th className="px-10 py-8 text-center">تاریخ تایید</th>
                            <th className="px-10 py-8 text-center">وضعیت امنیت</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                         {sales.map(s => (
                           <tr key={s.id} className="hover:bg-white/5 transition-colors group">
                              <td className="px-10 py-6 font-black text-lg text-white">{s.orgName}</td>
                              <td className="px-10 py-6 font-black text-emerald-400 text-base">{s.amount.toLocaleString()}</td>
                              <td className="px-10 py-6"><span className="px-4 py-1.5 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20 text-[10px] font-black uppercase">{s.plan}</span></td>
                              <td className="px-10 py-6 text-center font-mono text-xs text-slate-400 font-bold">{s.date}</td>
                              <td className="px-10 py-6 text-center">
                                 <div className="flex items-center justify-center gap-2 text-emerald-500">
                                    <ShieldCheck size={16} />
                                    <span className="text-[10px] font-black uppercase">تایید شده</span>
                                 </div>
                              </td>
                           </tr>
                         ))}
                      </tbody>
                   </table>
                </div>
             </div>
          </motion.div>
        )}

        {activeTab === 'licenses' && (
          <motion.div key="licenses" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-10">
             <div className="bg-white/5 backdrop-blur-md p-8 rounded-[3rem] border border-white/5 flex flex-col md:flex-row items-center gap-6 shadow-2xl">
                <div className="relative flex-1 w-full">
                   <input type="text" placeholder="جستجو در لایسنس‌ها، کدهای رمزنگاری شده یا نام سازمان..." className="w-full pl-4 pr-12 py-5 bg-white/5 border-none rounded-3xl font-black text-sm outline-none text-white focus:ring-2 focus:ring-amber-500 shadow-inner" />
                   <Search className="absolute right-4 top-5 text-slate-500" size={24} />
                </div>
                <div className="flex gap-2">
                   <button className="px-8 py-5 bg-slate-800 text-white rounded-2xl font-black text-xs uppercase flex items-center gap-2 hover:bg-slate-700 transition-all">فیلتر پیشرفته</button>
                   <button className="px-8 py-5 bg-amber-500 text-slate-950 rounded-2xl font-black text-xs uppercase flex items-center gap-2 shadow-xl hover:scale-105 transition-all">همگام‌سازی شبکه</button>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {licenses.map(lic => (
                  <div key={lic.id} className="bg-slate-900 border border-white/5 rounded-[3.5rem] p-10 shadow-2xl relative overflow-hidden group hover:border-amber-500/30 transition-all">
                     <div className={`absolute top-0 right-0 w-full h-2 ${lic.status === 'ACTIVE' ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                     <div className="flex justify-between items-start mb-10">
                        <div className="p-4 bg-white/5 rounded-2xl shadow-inner group-hover:scale-110 transition-transform duration-500">
                           <Key size={32} className="text-amber-500" />
                        </div>
                        <div className="flex gap-2 opacity-30 group-hover:opacity-100 transition-all">
                           <button className="p-3 bg-white/5 hover:bg-blue-500 hover:text-white rounded-xl transition-colors"><Edit size={16}/></button>
                           <button onClick={() => setDeleteLicId(lic.id)} className="p-3 bg-white/5 hover:bg-rose-500 hover:text-white rounded-xl transition-colors"><Trash2 size={16}/></button>
                        </div>
                     </div>
                     <h3 className="text-2xl font-black text-white mb-3 leading-tight truncate">{lic.orgName}</h3>
                     <div className="flex items-center gap-3 mb-10">
                        <span className={`text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest ${lic.type === 'ENTERPRISE' ? 'bg-amber-500/20 text-amber-500 border border-amber-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'}`}>
                           {lic.type === 'ENTERPRISE' ? 'سازمانی' : 'حرفه‌ای'}
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{lic.maxUsers} کاربر مجاز</span>
                     </div>
                     
                     <div className="bg-white/2 p-6 rounded-3xl border border-white/5 mb-10 group-hover:bg-white/5 transition-all">
                        <div className="flex justify-between items-center mb-3">
                           <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest">کلید لایسنس رمزنگاری شده (RSA-256)</p>
                           <ShieldCheck size={14} className="text-emerald-500" />
                        </div>
                        <p className="text-[11px] font-mono font-black text-emerald-400 break-all select-all leading-relaxed tracking-wider">{lic.key}</p>
                     </div>

                     <div className="grid grid-cols-2 gap-6 pt-6 border-t border-white/5">
                        <div>
                           <p className="text-[9px] font-black text-slate-600 uppercase mb-2 tracking-widest">تاریخ صدور</p>
                           <div className="flex items-center gap-2">
                              <Clock size={14} className="text-slate-500" />
                              <p className="text-xs font-black text-slate-300">{lic.issueDate}</p>
                           </div>
                        </div>
                        <div>
                           <p className="text-[9px] font-black text-slate-600 uppercase mb-2 tracking-widest">پایان اعتبار</p>
                           <div className="flex items-center gap-2">
                              <ShieldAlert size={14} className="text-rose-500" />
                              <p className="text-xs font-black text-rose-400">{lic.expiryDate}</p>
                           </div>
                        </div>
                     </div>
                  </div>
                ))}
             </div>
          </motion.div>
        )}

        {activeTab === 'system' && (
           <motion.div key="system" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                 <div className="bg-white/5 backdrop-blur-md p-10 rounded-[3rem] border border-white/5 shadow-2xl">
                    <h3 className="text-white font-black text-sm mb-10 flex items-center gap-3 uppercase tracking-widest"><Cpu size={24} className="text-blue-400"/> بار پردازشی زیرساخت</h3>
                    <div className="space-y-8">
                       {[
                         { label: 'پردازشگر ابری (Core)', val: 18, color: 'bg-emerald-500' },
                         { label: 'پایگاه داده متمرکز', val: 42, color: 'bg-blue-500' },
                         { label: 'ترافیک سوکت‌های فعال', val: 65, color: 'bg-amber-500' }
                       ].map(m => (
                         <div key={m.label} className="space-y-3">
                            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                               <span className="text-slate-400">{m.label}</span>
                               <span className="text-white">{m.val}٪</span>
                            </div>
                            <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden shadow-inner">
                               <motion.div initial={{ width: 0 }} animate={{ width: `${m.val}%` }} transition={{ duration: 1.5 }} className={`h-full ${m.color}`} />
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>
                 
                 <div className="lg:col-span-2 bg-slate-900 rounded-[3rem] border border-white/5 p-10 relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 p-8 opacity-5"><Terminal size={150} /></div>
                    <h3 className="text-white font-black text-sm mb-10 flex items-center gap-3 uppercase tracking-widest"><Terminal size={24} className="text-emerald-400"/> گزارش وقایع امنیتی سیستم</h3>
                    <div className="space-y-4 font-mono text-[11px] leading-relaxed max-h-64 overflow-y-auto custom-scrollbar pr-4 text-right" dir="ltr">
                       <div className="text-emerald-500/60">[{new Date().toISOString()}] HANDSHAKE: Node [Alborz_H_01] connected.</div>
                       <div className="text-emerald-500/60">[{new Date().toISOString()}] AUTH: Admin session validated for UID: 10420.</div>
                       <div className="text-emerald-500/60">[{new Date().toISOString()}] REV_SYNC: Global revenue matrix updated.</div>
                       <div className="text-rose-500 font-black p-2 bg-rose-500/10 rounded-xl border border-rose-500/20">[{new Date().toISOString()}] ALERT: Brute-force block from IP: 45.18.2.190</div>
                       <div className="text-blue-400">[{new Date().toISOString()}] BACKUP: Automatic cloud snapshot completed.</div>
                       <div className="text-slate-500">[{new Date().toISOString()}] PING: 12ms latency to DB Cluster.</div>
                       <div className="text-emerald-500/60">[{new Date().toISOString()}] ALL SERVICES REPORTING HEALTHY STATE.</div>
                    </div>
                 </div>
              </div>
           </motion.div>
        )}
      </AnimatePresence>

      {/* مودال صدور لایسنس استراتژیک */}
      <Modal isOpen={isLicenseModalOpen} onClose={() => setIsLicenseModalOpen(false)} title="کنسول صدور لایسنس استراتژیک" maxWidth="max-w-3xl">
         <form onSubmit={handleCreateLicense} className="p-10 space-y-10 bg-slate-950 text-white rounded-b-[3rem]">
            <div className="flex flex-col items-center gap-4 text-center mb-6">
                <div className="w-20 h-20 bg-amber-500/10 rounded-3xl flex items-center justify-center text-amber-500 border border-amber-500/20 shadow-xl">
                   <ShieldCheck size={44} />
                </div>
                <h3 className="text-2xl font-black uppercase tracking-tight">صدور کلید دسترسی سراسری</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em]">احراز هویت سازمان و یکپارچه‌سازی تجاری</p>
            </div>

            <div className="space-y-8">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">نام رسمی سازمان یا مرکز آموزشی</label>
                  <input required className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl font-black text-lg outline-none focus:ring-2 focus:ring-amber-500 text-white transition-all shadow-inner" placeholder="مثال: دانشگاه صنعتی شریف" value={licForm.orgName} onChange={e => setLicForm({...licForm, orgName: e.target.value})} />
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">سطح اشتراک سرویس</label>
                    <select className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl font-black text-sm outline-none text-white focus:ring-2 focus:ring-amber-500" value={licForm.type} onChange={e => setLicForm({...licForm, type: e.target.value as any})}>
                       <option value="PRO" className="bg-slate-900 text-white">حرفه‌ای (سطح ۲)</option>
                       <option value="ENTERPRISE" className="bg-slate-900 text-white">سازمانی (سطح ۱)</option>
                       <option value="TRIAL" className="bg-slate-900 text-white">آزمایشی / سندباکس</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">ظرفیت کاربران فعال</label>
                    <input type="number" className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl font-black text-lg outline-none text-white focus:ring-2 focus:ring-amber-500 shadow-inner" value={licForm.maxUsers} onChange={e => setLicForm({...licForm, maxUsers: parseInt(e.target.value)})} />
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">ارزش قرارداد (تومان)</label>
                    <input type="number" className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl font-black text-lg outline-none text-white focus:ring-2 focus:ring-amber-500 shadow-inner" value={licForm.price} onChange={e => setLicForm({...licForm, price: parseInt(e.target.value)})} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">تاریخ انقضا (Kill-Switch)</label>
                    <input className="w-full p-6 bg-white/5 border border-white/10 rounded-3xl font-black text-lg outline-none text-white text-left dir-ltr transition-all focus:ring-2 focus:ring-rose-500" placeholder="1404/01/01" value={licForm.expiryDate} onChange={e => setLicForm({...licForm, expiryDate: e.target.value})} />
                  </div>
               </div>
            </div>

            <div className="p-8 bg-amber-500/5 border border-amber-500/20 rounded-[2.5rem] flex gap-5 items-center">
               <AlertCircle className="text-amber-500 shrink-0" size={32} />
               <p className="text-xs text-amber-200/80 font-bold leading-relaxed">
                  هشدار: تایید این فرم منجر به تولید کلید دسترسی ۲۵۶ بیتی و ثبت سند مالی در تراز کل سازمان خواهد شد.
               </p>
            </div>

            <button type="submit" className="w-full py-7 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-[2.2rem] font-black shadow-[0_0_60px_rgba(245,158,11,0.25)] transition-all flex items-center justify-center gap-4 text-xl uppercase tracking-tighter">
               <ShieldCheck size={32} /> تایید و صدور نهایی لایسنس
            </button>
         </form>
      </Modal>

      <ConfirmationModal 
        isOpen={!!deleteLicId}
        onClose={() => setDeleteLicId(null)}
        onConfirm={confirmDeleteLicense}
        title="ابطال دائمی لایسنس"
        description="با ابطال این مجوز، دسترسی تمامی کاربران سازمان مذکور به هسته مرکزی هوش مصنوعی و سرویس‌های تحت شبکه در لحظه قطع خواهد شد. آیا مطمئن هستید؟"
        confirmText="بله، ابطال و پاکسازی شود"
      />
    </div>
  );
};

export default SuperAdminDashboard;
