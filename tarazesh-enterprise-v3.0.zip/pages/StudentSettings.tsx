
import React, { useState, useRef } from 'react';
import { User, UserRole } from '../types';
import { storageService } from '../services/storageService';
import { 
  User as UserIcon, Camera, Save, Shield, KeyRound, 
  Mail, Smartphone, ShieldCheck, Lock, Settings as SettingsIcon,
  RefreshCw, CheckCircle, AlertTriangle
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import { compressImage } from '../utils/imageUtils';

interface StudentSettingsProps {
  currentUser: User;
  onRefreshUser?: () => void;
}

const StudentSettings: React.FC<StudentSettingsProps> = ({ currentUser, onRefreshUser }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security'>('profile');
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [profileData, setProfileData] = useState({
    email: currentUser.email || '',
    phoneNumber: currentUser.phoneNumber || '',
    avatar: currentUser.avatar || ''
  });

  const [passData, setPassData] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleProfileSave = async () => {
    setLoading(true);
    try {
      const updatedUser: User = { ...currentUser, ...profileData };
      await storageService.saveUser(updatedUser);
      localStorage.setItem('current_user', JSON.stringify(updatedUser));
      if (onRefreshUser) onRefreshUser();
      toast.success('پروفایل شما با موفقیت بروزرسانی شد.');
    } catch (err) {
      toast.error('خطا در ذخیره‌سازی اطلاعات پروفایل.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!passData.oldPassword || !passData.newPassword) {
      return toast.error('لطفاً تمامی فیلدها را پر کنید.');
    }

    if (passData.oldPassword !== currentUser.password) {
      return toast.error('رمز عبور فعلی اشتباه است.');
    }

    if (passData.newPassword.length < 4) {
      return toast.error('رمز عبور جدید باید حداقل ۴ کاراکتر باشد.');
    }

    if (passData.newPassword !== passData.confirmPassword) {
      return toast.error('تکرار رمز عبور جدید مطابقت ندارد.');
    }

    setLoading(true);
    try {
      // عملیات تغییر رمز در دیتابیس محلی
      const updatedUser = { ...currentUser, password: passData.newPassword };
      await storageService.saveUser(updatedUser);
      
      // بروزرسانی سشن فعلی
      localStorage.setItem('current_user', JSON.stringify(updatedUser));
      
      setPassData({ oldPassword: '', newPassword: '', confirmPassword: '' });
      toast.success('رمز عبور شما با موفقیت تغییر یافت.');
      if (onRefreshUser) onRefreshUser();
    } catch (err) {
      toast.error('اختلال در سیستم تغییر رمز عبور.');
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const compressed = await compressImage(file, 400, 0.8);
      setProfileData(prev => ({ ...prev, avatar: compressed }));
      toast.info('تصویر آماده ذخیره‌سازی است.');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-3">
            <SettingsIcon className="text-primary-600" size={32} />
            تنظیمات و امنیت حساب
          </h1>
          <p className="text-sm text-slate-500 font-bold mt-1">مدیریت اطلاعات بازیابی و هویت بصری دانش‌آموز در شبکه</p>
        </div>
      </div>

      <div className="flex gap-2 p-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-fit">
         <button onClick={() => setActiveTab('profile')} className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-sm transition-all ${activeTab === 'profile' ? 'bg-primary-600 text-white shadow-xl' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
            <UserIcon size={18} /> مشخصات و بازیابی
         </button>
         <button onClick={() => setActiveTab('security')} className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-sm transition-all ${activeTab === 'security' ? 'bg-rose-600 text-white shadow-xl' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
            <Shield size={18} /> تغییر رمز عبور
         </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'profile' && (
          <motion.div key="profile" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-10">
             <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                   <div className="w-32 h-32 rounded-[2.5rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-4xl text-slate-400 overflow-hidden border-4 border-white shadow-2xl">
                      {profileData.avatar ? <img src={profileData.avatar} className="w-full h-full object-cover" /> : currentUser.name.charAt(0)}
                   </div>
                   <div className="absolute inset-0 bg-black/40 rounded-[2.5rem] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                      <Camera className="text-white" size={32} />
                   </div>
                   <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarUpload} />
                </div>
                <div className="text-center md:text-right flex-1">
                   <h2 className="text-2xl font-black text-slate-800 dark:text-white">{currentUser.name}</h2>
                   <p className="text-slate-400 font-bold mt-1">دانش‌آموز پایه {currentUser.grade} | کدملی: {currentUser.studentId}</p>
                   <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800 flex items-center gap-3">
                      <ShieldCheck className="text-blue-600" size={24} />
                      <p className="text-xs text-blue-700 dark:text-blue-300 font-bold">اطلاعات تماس شما برای بازیابی گذرواژه توسط مدیریت استفاده می‌شود.</p>
                   </div>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-50 dark:border-slate-800">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">ایمیل شخصی</label>
                   <div className="relative">
                      <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-primary-500 dir-ltr text-left text-slate-900 dark:text-white shadow-inner" value={profileData.email} onChange={e => setProfileData({...profileData, email: e.target.value})} placeholder="example@email.com" />
                      <Mail className="absolute left-4 top-4 text-slate-300" size={20} />
                   </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">شماره همراه</label>
                   <div className="relative">
                      <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-primary-500 dir-ltr text-left text-slate-900 dark:text-white shadow-inner" value={profileData.phoneNumber} onChange={e => setProfileData({...profileData, phoneNumber: e.target.value})} placeholder="0912..." />
                      <Smartphone className="absolute left-4 top-4 text-slate-300" size={20} />
                   </div>
                </div>
             </div>

             <div className="flex justify-end pt-4">
                <button onClick={handleProfileSave} disabled={loading} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-4 rounded-2xl font-black shadow-2xl transition-all flex items-center gap-2">
                   {loading ? <RefreshCw size={20} className="animate-spin" /> : <Save size={20} />} ثبت و بروزرسانی نهایی
                </button>
             </div>
          </motion.div>
        )}

        {activeTab === 'security' && (
          <motion.div key="sec" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-10">
             <div className="bg-rose-50 dark:bg-rose-900/10 p-6 rounded-3xl flex items-start gap-4 border border-rose-100 dark:border-rose-900/30">
                <Lock className="text-rose-500 shrink-0" size={24} />
                <div>
                   <h3 className="font-black text-rose-900 dark:text-rose-200">تغییر گذرواژه امنیتی</h3>
                   <p className="text-xs text-rose-700/70 font-bold leading-relaxed mt-1">توصیه می‌شود برای حفظ امنیت حساب خود در شبکه، رمز عبور را به صورت دوره‌ای تغییر دهید.</p>
                </div>
             </div>

             <form onSubmit={handlePasswordChange} className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 block mr-2">رمز عبور فعلی</label>
                   <input type="password" required value={passData.oldPassword} onChange={e => setPassData({...passData, oldPassword: e.target.value})} placeholder="••••••••" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500 text-slate-900 dark:text-white shadow-inner" />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 block mr-2">رمز عبور جدید</label>
                   <input type="password" required value={passData.newPassword} onChange={e => setPassData({...passData, newPassword: e.target.value})} placeholder="••••••••" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500 text-slate-900 dark:text-white shadow-inner" />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 block mr-2">تکرار رمز جدید</label>
                   <input type="password" required value={passData.confirmPassword} onChange={e => setPassData({...passData, confirmPassword: e.target.value})} placeholder="••••••••" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500 text-slate-900 dark:text-white shadow-inner" />
                </div>
                
                <div className="md:col-span-3 pt-4">
                  <button type="submit" disabled={loading} className="bg-rose-600 hover:bg-rose-700 text-white px-10 py-4 rounded-2xl font-black shadow-xl flex items-center gap-2 transition-all">
                    {loading ? <RefreshCw className="animate-spin" size={20}/> : <Shield size={20} />} 
                    بروزرسانی گذرواژه امنیتی
                  </button>
                </div>
             </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default StudentSettings;
