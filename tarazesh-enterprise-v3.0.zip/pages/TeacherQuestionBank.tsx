
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { storageService } from '../services/storageService';
import { generateAIQuestions } from '../services/aiService';
import { Question, QuestionType, Major, Grade, Course } from '../types';
import { 
  Search, Plus, Edit, Trash2, Database, FileUp, 
  GraduationCap, Layers, Book, Filter, Hash, Loader2, Zap, X, Check, Save, Info,
  AlertCircle, Tag, ListChecks, FileQuestion, ChevronRight, ChevronDown, BookMarked,
  LayoutGrid, LayoutList, FileText, CheckCircle2, Sparkles, Map, Lightbulb, Image as ImageIcon,
  Camera, Upload, HelpCircle, Star, AlertTriangle, FolderOpen, ChevronLeft
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';
import { motion, AnimatePresence } from 'framer-motion';
import { compressImage } from '../utils/imageUtils';

// @ts-ignore
import mammoth from 'mammoth';

const TeacherQuestionBank: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [majors, setMajors] = useState<Major[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMajor, setFilterMajor] = useState('all');
  const [filterGrade, setFilterGrade] = useState('all');
  const [filterCourse, setFilterCourse] = useState('all');

  const [isWordModalOpen, setIsModalOpen] = useState(false);
  const [isReviewOpen, setIsReviewOpen] = useState(false);
  const [isAiCreateOpen, setIsAiCreateOpen] = useState(false);
  const [uploadedQuestions, setUploadedQuestions] = useState<Question[]>([]);
  const [batchCategory, setBatchCategory] = useState({ grade: '', major: '', courseId: '' });
  const [isTemplateGuideOpen, setIsTemplateGuideOpen] = useState(false);

  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [isImportLoading, setIsImportLoading] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  const toast = useToast();
  const wordInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const aiFileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<Partial<Question>>({
    text: '', type: QuestionType.MULTIPLE_CHOICE, options: ['', '', '', ''], 
    correctAnswer: 0, points: 1, grade: '', major: '', courseId: '', difficulty: 'medium', image: ''
  });

  const [aiConfig, setAiConfig] = useState({
      topic: '',
      count: 5,
      difficulty: 'medium' as any,
      file: null as File | null
  });

  useEffect(() => {
    setQuestions(storageService.getQuestions());
    setMajors(storageService.getMajors());
    setGrades(storageService.getGrades());
    setCourses(storageService.getCourses());
  }, []);

  const groupedQuestions = useMemo(() => {
    const filtered = questions.filter(q => {
      const matchSearch = q.text.toLowerCase().includes(searchTerm.toLowerCase());
      const matchMajor = filterMajor === 'all' || q.major === filterMajor;
      const matchGrade = filterGrade === 'all' || q.grade === filterGrade;
      const matchCourse = filterCourse === 'all' || q.courseId === filterCourse;
      return matchSearch && matchMajor && matchGrade && matchCourse;
    });

    const groups: Record<string, { label: string; items: Question[] }> = {};
    filtered.forEach(q => {
      const course = courses.find(c => c.id === q.courseId);
      const groupKey = q.courseId || 'uncategorized';
      const label = course ? `${course.title} (پایه ${q.grade} - ${q.major})` : 'دسته‌بندی نشده';
      if (!groups[groupKey]) groups[groupKey] = { label, items: [] };
      groups[groupKey].items.push(q);
    });
    return groups;
  }, [questions, searchTerm, filterMajor, filterGrade, filterCourse, courses]);

  const toggleGroup = (key: string) => {
    setExpandedGroups(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await compressImage(file, 400, 0.5);
      setFormData(prev => ({ ...prev, image: base64 }));
      toast.success("تصویر الحاق شد.");
    }
  };

  const handleSave = () => {
    if (!formData.text) return toast.error('متن سوال الزامی است.');
    const newQ = { ...formData, id: editingQuestion?.id || `q_${Date.now()}` } as Question;
    const updated = editingQuestion ? questions.map(q => q.id === editingQuestion.id ? newQ : q) : [newQ, ...questions];
    setQuestions(updated);
    storageService.saveQuestions(updated);
    setIsManualModalOpen(false);
    toast.success('بانک سوالات بروز شد.');
  };

  const handleAiBankCreate = async () => {
      if (!aiConfig.topic && !aiConfig.file) return toast.warning("موضوع یا فایل را مشخص کنید.");
      if (isImportLoading) return;
      setIsImportLoading(true);
      try {
          let fileData = undefined;
          let sourceText = undefined;

          if (aiConfig.file) {
              const ext = aiConfig.file.name.split('.').pop()?.toLowerCase();
              if (ext === 'docx') {
                  const arrayBuffer = await aiConfig.file.arrayBuffer();
                  const result = await mammoth.convertToHtml({ arrayBuffer });
                  sourceText = result.value.replace(/<[^>]*>?/gm, ' ').substring(0, 10000);
              } else if (ext === 'pdf') {
                  const reader = new FileReader();
                  const base64 = await new Promise<string>((resolve) => {
                      reader.onload = () => resolve((reader.result as string).split(',')[1]);
                      reader.readAsDataURL(aiConfig.file!);
                  });
                  fileData = { data: base64, mimeType: 'application/pdf' };
              }
          }

          const generated = await generateAIQuestions({
              topic: aiConfig.topic,
              count: aiConfig.count,
              difficulty: aiConfig.difficulty,
              types: [QuestionType.MULTIPLE_CHOICE],
              fileData,
              sourceText
          });
          
          if (generated && generated.length > 0) {
              setUploadedQuestions(generated);
              setIsAiCreateOpen(false);
              setIsReviewOpen(true);
              toast.success(`${generated.length} سوال هوشمند با موفقیت طراحی شد.`);
          }
      } catch(e) { toast.error("خطا در پردازش هوشمند."); }
      finally { setIsImportLoading(false); }
  };

  const handleWordImport = async () => {
    if (!importFile || isImportLoading) return;
    setIsImportLoading(true);
    try {
        const arrayBuffer = await importFile.arrayBuffer();
        const result = await mammoth.convertToHtml({ arrayBuffer });
        const cleanText = result.value.replace(/<[^>]*>?/gm, ' ').substring(0, 10000);
        const generated = await generateAIQuestions({
            sourceText: cleanText,
            count: 10,
            types: [QuestionType.MULTIPLE_CHOICE],
            difficulty: 'medium'
        });
        if (generated && generated.length > 0) {
            setUploadedQuestions(generated);
            setIsModalOpen(false);
            setIsReviewOpen(true);
            toast.success('سوالات استخراج شدند.');
        }
    } catch (e) { toast.error('خطا در خواندن فایل.'); }
    finally { setIsImportLoading(false); }
  };

  const handleFinalizeBatch = () => {
    if (!batchCategory.grade || !batchCategory.major) return toast.error("پایه و رشته الزامی است.");
    const categorized = uploadedQuestions.map(q => ({ ...q, grade: batchCategory.grade, major: batchCategory.major, courseId: batchCategory.courseId }));
    const updated = [...categorized, ...questions];
    setQuestions(updated);
    storageService.saveQuestions(updated);
    setIsReviewOpen(false);
    setUploadedQuestions([]);
    toast.success("سوالات به بانک منتقل شدند.");
  };

  const resetManualForm = () => {
    setFormData({ text: '', type: QuestionType.MULTIPLE_CHOICE, options: ['', '', '', ''], correctAnswer: 0, points: 1, grade: '', major: '', courseId: '', difficulty: 'medium', image: '' });
    setEditingQuestion(null);
  };

  return (
    <div className="space-y-6 pb-32 font-sans text-right" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-3"><Database className="text-primary-600" /> بانک سوالات مرکزی</h1>
          <p className="text-sm text-slate-500 font-bold mt-1">مدیریت دارایی‌های آموزشی و استخراج هوشمند بر اساس دسته‌بندی</p>
        </div>
        <div className="flex flex-wrap gap-2">
            <button onClick={() => setIsAiCreateOpen(true)} className="bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 px-6 py-3.5 rounded-2xl flex items-center gap-2 font-black border border-emerald-100 hover:bg-emerald-600 hover:text-white transition-all">
              <Sparkles size={18} /> طراحی با AI
            </button>
            <button onClick={() => setIsModalOpen(true)} className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 px-6 py-3.5 rounded-2xl flex items-center gap-2 font-black border border-indigo-100 hover:bg-indigo-600 hover:text-white transition-all">
              <FileUp size={18} /> آپلود Word
            </button>
            <button onClick={() => { resetManualForm(); setIsManualModalOpen(true); }} className="bg-primary-600 text-white px-8 py-3.5 rounded-2xl flex items-center gap-2 shadow-xl font-black hover:scale-105 transition-all">
              <Plus size={20} /> سوال دستی
            </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-4 gap-4">
         <div className="relative group md:col-span-1">
            <input type="text" placeholder="جستجو در متن سوالات..." className="w-full pl-4 pr-11 py-3.5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-xs text-slate-900 dark:text-white shadow-inner" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            <Search className="absolute right-4 top-4 text-slate-400 group-focus-within:text-primary-500 transition-colors" size={20} />
         </div>
         <select className="bg-slate-50 dark:bg-slate-800 p-3.5 rounded-2xl text-[10px] font-black text-slate-900 dark:text-white outline-none cursor-pointer" value={filterMajor} onChange={e => setFilterMajor(e.target.value)}>
            <option value="all">رشته: همه</option>
            {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
         </select>
         <select className="bg-slate-50 dark:bg-slate-800 p-3.5 rounded-2xl text-[10px] font-black text-slate-900 dark:text-white outline-none cursor-pointer" value={filterGrade} onChange={e => setFilterGrade(e.target.value)}>
            <option value="all">پایه: همه</option>
            {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
         </select>
         <select className="bg-slate-50 dark:bg-slate-800 p-3.5 rounded-2xl text-[10px] font-black text-slate-900 dark:text-white outline-none cursor-pointer" value={filterCourse} onChange={e => setFilterCourse(e.target.value)}>
            <option value="all">واحد درسی: همه</option>
            {courses.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
         </select>
      </div>

      <div className="space-y-6">
          {Object.entries(groupedQuestions).length === 0 ? (
            <div className="py-20 text-center text-slate-400 font-bold italic border-2 border-dashed rounded-[3rem]">داده‌ای یافت نشد.</div>
          ) : (
            // Fix: Added explicit type assertion for Object.entries results to ensure group properties are correctly typed
            (Object.entries(groupedQuestions) as [string, { label: string; items: Question[] }][]).map(([key, group]) => (
              <div key={key} className="space-y-3">
                <button onClick={() => toggleGroup(key)} className="w-full flex items-center justify-between p-6 bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:border-primary-400 transition-all group">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary-50 dark:bg-primary-900/30 text-primary-600 rounded-2xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform"><FolderOpen size={24} /></div>
                    <div className="text-right">
                      <h3 className="font-black text-slate-900 dark:text-white">{group.label}</h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{group.items.length} سوال</p>
                    </div>
                  </div>
                  {expandedGroups[key] ? <ChevronDown className="text-slate-400" /> : <ChevronLeft className="text-slate-400" />}
                </button>
                <AnimatePresence>
                  {expandedGroups[key] && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden space-y-3 pr-4 border-r-4 border-primary-500/20">
                      {group.items.map(q => (
                        <div key={q.id} className="bg-white/50 dark:bg-slate-900/50 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center group transition-all hover:bg-white dark:hover:bg-slate-900">
                          <div className="flex-1 pr-4 flex items-center gap-4">
                            {q.image && <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border border-slate-100"><img src={q.image} className="w-full h-full object-cover" /></div>}
                            <div>
                                <div className="flex gap-2 mb-2">
                                  <span className="text-[8px] font-black px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-md uppercase">{q.type}</span>
                                  <span className={`text-[8px] font-black px-2 py-0.5 rounded-md uppercase ${q.difficulty === 'hard' ? 'bg-rose-50 text-rose-600' : q.difficulty === 'medium' ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>{q.difficulty}</span>
                                </div>
                                <p className="text-sm font-black text-slate-800 dark:text-slate-200 leading-relaxed">{q.text}</p>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-4 md:mt-0 opacity-0 group-hover:opacity-100 transition-all">
                              <button onClick={() => { setEditingQuestion(q); setFormData({...q}); setIsManualModalOpen(true); }} className="p-3 text-blue-500 hover:bg-blue-50 rounded-xl transition-all"><Edit size={18}/></button>
                              <button onClick={() => setDeleteId(q.id)} className="p-3 text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><Trash2 size={18}/></button>
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))
          )}
      </div>

      <Modal isOpen={isManualModalOpen} onClose={() => setIsManualModalOpen(false)} title={editingQuestion ? "ویرایش سوال" : "افزودن سوال دستی"}>
          <div className="p-8 space-y-8 text-right">
              <textarea className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-lg outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white shadow-inner" rows={3} value={formData.text} onChange={e => setFormData({...formData, text: e.target.value})} placeholder="صورت سوال..." />
              <div className="grid grid-cols-2 gap-4">
                  <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-white" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as any})}>
                      <option value={QuestionType.MULTIPLE_CHOICE}>چهارگزینه‌ای</option>
                      <option value={QuestionType.TRUE_FALSE}>صحیح / غلط</option>
                      <option value={QuestionType.DESCRIPTIVE}>تشریحی</option>
                  </select>
                  <input type="number" step="0.25" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-black text-center text-slate-900 dark:text-white border-none shadow-sm" value={formData.points} onChange={e => setFormData({...formData, points: parseFloat(e.target.value)})} placeholder="نمره" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <select className="w-full p-4 bg-white dark:bg-slate-900 rounded-2xl text-xs font-black text-slate-900 dark:text-white border-none shadow-sm" value={formData.major} onChange={e => setFormData({...formData, major: e.target.value})}>
                      <option value="">رشته...</option>
                      {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                  </select>
                  <select className="w-full p-4 bg-white dark:bg-slate-900 rounded-2xl text-xs font-black text-slate-900 dark:text-white border-none shadow-sm" value={formData.grade} onChange={e => setFormData({...formData, grade: e.target.value})}>
                      <option value="">پایه...</option>
                      {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
                  </select>
              </div>
              <button onClick={handleSave} className="w-full py-5 bg-primary-600 text-white rounded-[2rem] font-black shadow-xl flex items-center justify-center gap-3"><Save size={24} /> ثبت نهایی</button>
          </div>
      </Modal>

      <Modal isOpen={isWordModalOpen} onClose={() => !isImportLoading && setIsModalOpen(false)} title="درج از Word">
         <div className="p-8 text-center space-y-8">
            <div className="border-4 border-dashed border-slate-100 dark:border-slate-800 p-16 rounded-[3rem] cursor-pointer hover:border-indigo-500 transition-all group" onClick={() => wordInputRef.current?.click()}>
                <FileUp size={64} className="mx-auto text-slate-200 group-hover:text-indigo-500" />
                <p className="mt-6 font-black text-slate-600">{importFile ? importFile.name : 'انتخاب فایل DOCX'}</p>
                <input type="file" ref={wordInputRef} className="hidden" accept=".docx" onChange={e => setImportFile(e.target.files?.[0] || null)} />
            </div>
            <button onClick={handleWordImport} disabled={!importFile || isImportLoading} className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-black flex items-center justify-center gap-3">
                {isImportLoading ? <Loader2 className="animate-spin" /> : 'استخراج سریع'}
            </button>
         </div>
      </Modal>

      <Modal isOpen={isAiCreateOpen} onClose={() => !isImportLoading && setIsAiCreateOpen(false)} title="طراحی سوال AI">
          <div className="p-8 space-y-6 text-right">
              <textarea className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-lg outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white shadow-inner" rows={3} value={aiConfig.topic} onChange={e => setAiConfig({...aiConfig, topic: e.target.value})} placeholder="موضوع تدریس..." />
              <div onClick={() => aiFileInputRef.current?.click()} className="border-2 border-dashed border-slate-100 p-8 rounded-[2rem] text-center cursor-pointer hover:border-emerald-500">
                  <Upload className="mx-auto text-slate-300" size={32} />
                  <p className="text-xs font-bold text-slate-500">{aiConfig.file ? aiConfig.file.name : 'بارگذاری فایل منبع'}</p>
                  <input type="file" ref={aiFileInputRef} className="hidden" accept=".pdf,.docx,image/*" onChange={e => setAiConfig({...aiConfig, file: e.target.files?.[0] || null})} />
              </div>
              <button onClick={handleAiBankCreate} disabled={isImportLoading} className="w-full py-5 bg-emerald-600 text-white rounded-3xl font-black flex items-center justify-center gap-3">
                  {isImportLoading ? <Loader2 className="animate-spin" /> : <><Sparkles size={20} /> طراحی آنی</>}
              </button>
          </div>
      </Modal>

      <Modal isOpen={isReviewOpen} onClose={() => setIsReviewOpen(false)} title="بازبینی سوالات طراحی شده">
          <div className="p-8 space-y-6 text-right">
              <div className="grid grid-cols-2 gap-4">
                  <select className="w-full p-4 bg-slate-50 rounded-2xl font-black text-xs" value={batchCategory.grade} onChange={e => setBatchCategory({...batchCategory, grade: e.target.value})}><option value="">پایه...</option>{grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}</select>
                  <select className="w-full p-4 bg-slate-50 rounded-2xl font-black text-xs" value={batchCategory.major} onChange={e => setBatchCategory({...batchCategory, major: e.target.value})}><option value="">رشته...</option>{majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}</select>
              </div>
              <div className="max-h-64 overflow-y-auto space-y-3">
                  {uploadedQuestions.map((q, idx) => (
                      <div key={idx} className="p-4 bg-slate-50 rounded-xl flex justify-between items-center"><p className="text-xs font-black truncate">{q.text}</p><button onClick={() => setUploadedQuestions(p => p.filter((_, i) => i !== idx))}><X size={16} className="text-rose-500"/></button></div>
                  ))}
              </div>
              <button onClick={handleFinalizeBatch} className="w-full py-5 bg-primary-600 text-white rounded-3xl font-black shadow-xl">تایید و درج در بانک</button>
          </div>
      </Modal>

      <ConfirmationModal isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={() => { setQuestions(questions.filter(q => q.id !== deleteId)); storageService.saveQuestions(questions.filter(q => q.id !== deleteId)); setDeleteId(null); }} title="حذف سوال" description="آیا مطمئن هستید؟" />
    </div>
  );
};

export default TeacherQuestionBank;
