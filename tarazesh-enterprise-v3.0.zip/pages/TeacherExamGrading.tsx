
import React, { useState, useEffect } from 'react';
import { Exam, ExamResult, NotificationType, QuestionType } from '../types';
import { storageService } from '../services/storageService';
import { gradeDescriptiveAnswer } from '../services/aiService';
import { 
  CheckCircle, Save, ArrowRight, Sparkles, Eye, Check, X, Lock, 
  WifiOff, Globe, MessageCircle, AlertTriangle, ListOrdered, User,
  TrendingUp, Award, Target, Activity, ShieldAlert
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import { motion, AnimatePresence } from 'framer-motion';

interface TeacherExamGradingProps {
  examId: string | null;
  onBack: () => void;
}

const ScoreRing: React.FC<{ score: number, max: number, size?: number, stroke?: number }> = ({ score, max, size = 120, stroke = 10 }) => {
  const percentage = max > 0 ? Math.min(Math.max((score / max) * 100, 0), 100) : 0;
  const radius = (size - stroke) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  const getColor = () => {
    if (max <= 0) return '#94a3b8';
    const ratio = score / max;
    if (ratio >= 0.85) return '#10b981';
    if (ratio >= 0.5) return '#0ea5e9';
    return '#f43f5e';
  };

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="currentColor" strokeWidth={stroke} fill="transparent" className="text-slate-100 dark:text-slate-800" />
        <motion.circle cx={size / 2} cy={size / 2} r={radius} stroke={getColor()} strokeWidth={stroke} fill="transparent" strokeDasharray={circumference} initial={{ strokeDashoffset: circumference }} animate={{ strokeDashoffset: offset }} transition={{ duration: 1.5, ease: "easeOut" }} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-black text-slate-900 dark:text-white leading-none">{score}</span>
        <span className="text-[9px] font-black text-slate-400 uppercase tracking-tighter mt-1">از {max}</span>
      </div>
    </div>
  );
};

const TeacherExamGrading: React.FC<TeacherExamGradingProps> = ({ examId, onBack }) => {
  const [results, setResults] = useState<ExamResult[]>([]);
  const [exam, setExam] = useState<Exam | undefined>(undefined);
  const toast = useToast();
  
  const [filterMode, setFilterMode] = useState<'all' | 'appeals'>('all');
  const [viewingResult, setViewingResult] = useState<ExamResult | null>(null);
  const [tempScore, setTempScore] = useState<number>(0);
  const [tempFeedback, setTempFeedback] = useState<string>('');
  const [teacherResponse, setTeacherResponse] = useState<string>('');
  const [isAiGrading, setIsAiGrading] = useState(false);

  useEffect(() => {
    if (examId) {
      const allResults = storageService.getResults();
      const allExams = storageService.getExams();
      setResults(allResults.filter(r => r.examId === examId));
      setExam(allExams.find(e => e.id === examId));
    }
  }, [examId]);

  if (!exam) return <div className="p-20 text-center text-slate-500 font-bold">در حال بارگذاری داده‌های شبکه...</div>;

  const filteredResults = results.filter(r => filterMode === 'all' ? true : r.appealStatus === 'pending');

  const handleAiGrade = async (result: ExamResult) => {
    setIsAiGrading(true);
    try {
      const descriptiveQuestions = exam.questions.filter(q => q.type === QuestionType.DESCRIPTIVE);
      let totalAiScore = 0;
      let aiFeedbackParts: string[] = [];

      for (const q of descriptiveQuestions) {
          const studentAns = result.answers[q.id];
          if (studentAns) {
              const aiRes = await gradeDescriptiveAnswer(q.text, studentAns, q.points, String(q.correctAnswer || ""));
              totalAiScore += aiRes.score;
              aiFeedbackParts.push(`[${q.text.substring(0, 10)}...]: ${aiRes.feedback}`);
          }
      }

      let objectiveScore = 0;
      exam.questions.forEach(q => {
          if (q.type !== QuestionType.DESCRIPTIVE && String(result.answers[q.id]) === String(q.correctAnswer)) objectiveScore += q.points;
      });

      setTempScore(Number((objectiveScore + totalAiScore).toFixed(2)));
      setTempFeedback(aiFeedbackParts.join('\n'));
      toast.success('تصحیح هوشمند با موفقیت تکمیل شد.');
    } catch (e) {
      toast.error('اختلال در موتور هوش مصنوعی.');
    } finally {
      setIsAiGrading(false);
    }
  };

  const handleSaveFinalScore = () => {
    if (!viewingResult) return;
    const updatedResults = results.map(r => r.id === viewingResult.id ? { ...r, score: tempScore, feedback: tempFeedback, appealStatus: r.appealStatus === 'pending' ? 'reviewed' : r.appealStatus, teacherResponse } : r);
    setResults(updatedResults);
    const all = storageService.getResults().filter(r => r.examId !== examId);
    storageService.saveResults([...all, ...updatedResults]);
    storageService.addNotification({ userId: viewingResult.studentId, type: NotificationType.EXAM_RESULT, title: 'بروزرسانی نمره', message: `نمره آزمون ${exam.title} شما به ${tempScore} تغییر یافت.` });
    setViewingResult(null);
    toast.success('تغییرات در پایگاه داده ثبت شد.');
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="flex flex-col md:flex-row justify-between items-center bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm gap-6">
         <div className="flex items-center gap-6">
            <button onClick={onBack} className="p-4 bg-slate-50 dark:bg-slate-800 text-slate-500 rounded-2xl hover:scale-105 transition-all shadow-sm border border-slate-100 dark:border-slate-700"><ArrowRight size={24} /></button>
            <div>
               <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100">ارزشیابی نهایی: {exam.title}</h1>
               <p className="text-sm text-slate-500 font-bold mt-1">مدیریت نمرات و پاسخگویی به درخواست‌های بازبینی</p>
            </div>
         </div>
         <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl border">
            <button onClick={() => setFilterMode('all')} className={`px-8 py-3 rounded-xl text-xs font-black transition-all ${filterMode === 'all' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>تمامی کارنامه‌ها</button>
            <button onClick={() => setFilterMode('appeals')} className={`px-8 py-3 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${filterMode === 'appeals' ? 'bg-white dark:bg-slate-700 text-rose-600 shadow-xl' : 'text-slate-500'}`}>
               <AlertTriangle size={16} /> اعتراضات ({results.filter(r => r.appealStatus === 'pending').length})
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
         {filteredResults.map(res => {
            const student = storageService.getUsers().find(u => u.id === res.studentId);
            const scaled = (res.score / (res.maxScore || 1)) * 20;
            return (
               <motion.div layout key={res.id} className={`bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border-2 flex flex-col md:flex-row justify-between items-center group transition-all ${res.appealStatus === 'pending' ? 'border-rose-400 bg-rose-50/10' : 'border-slate-100 dark:border-slate-800 hover:shadow-2xl'}`}>
                  <div className="flex items-center gap-6">
                     <div className="w-16 h-16 rounded-[1.5rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-2xl text-slate-400 overflow-hidden border">
                        {student?.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : <User size={32} />}
                     </div>
                     <div>
                        <p className="font-black text-xl text-slate-800 dark:text-white">{student?.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono font-bold mt-1">{student?.studentId} • پایه {student?.grade}</p>
                     </div>
                  </div>
                  <div className="flex items-center gap-12">
                     <div className="text-left border-r pr-12 border-slate-100">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">نمره نهایی</p>
                        <div className="flex items-baseline gap-1">
                           <span className={`text-4xl font-black ${scaled >= 10 ? 'text-emerald-500' : 'text-rose-500'}`}>{res.score}</span>
                           <span className="text-xs text-slate-400">/ {res.maxScore}</span>
                        </div>
                     </div>
                     <button onClick={() => { setViewingResult(res); setTempScore(res.score); setTempFeedback(res.feedback || ''); setTeacherResponse(res.teacherResponse || ''); }} className="px-10 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-xs font-black shadow-xl hover:bg-primary-600 hover:text-white transition-all">بازبینی و اصلاح</button>
                  </div>
               </motion.div>
            );
         })}
      </div>

      <Modal isOpen={!!viewingResult} onClose={() => setViewingResult(null)} title="میز کار تخصصی تصحیح" maxWidth="max-w-6xl">
         {viewingResult && (
           <div className="p-8 space-y-10">
              <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-800/50 p-10 rounded-[3rem] border">
                 <div className="flex items-center gap-8">
                    <ScoreRing score={tempScore} max={viewingResult.maxScore} />
                    <h3 className="text-2xl font-black">تحلیل جامع عملکرد</h3>
                 </div>
                 <button onClick={() => handleAiGrade(viewingResult)} disabled={isAiGrading} className="bg-primary-600 text-white px-8 py-4 rounded-2xl font-black text-xs shadow-2xl flex items-center gap-3 disabled:opacity-50">
                    {isAiGrading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <Sparkles size={18} />} تصحیح با هوش مصنوعی
                 </button>
              </div>

              <div className="space-y-6">
                 {exam.questions.map((q, idx) => {
                    const studentAns = viewingResult.answers[q.id];
                    const isCorrect = String(studentAns) === String(q.correctAnswer);
                    return (
                       <div key={q.id} className={`p-6 rounded-[2.5rem] border-2 ${isCorrect ? 'bg-white border-slate-100' : 'bg-rose-50/10 border-rose-100'}`}>
                          <div className="flex justify-between gap-6">
                             <div className="flex-1 space-y-4">
                                <div className="flex items-center gap-3">
                                   <span className="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center font-black text-xs text-slate-500">{idx+1}</span>
                                   <span className="text-[9px] font-black uppercase bg-slate-50 px-3 py-1 rounded-full text-slate-400">{q.type}</span>
                                </div>
                                <p className="font-black text-lg">{q.text}</p>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                   <div className={`p-4 rounded-2xl border-2 ${isCorrect ? 'border-emerald-100 bg-emerald-50/20' : 'border-rose-100 bg-rose-50/20'}`}>
                                      <p className="text-[9px] font-black text-slate-400 uppercase mb-2">پاسخ هنرجو</p>
                                      <p className="text-sm font-black">{String(studentAns || '-')}</p>
                                   </div>
                                   {!isCorrect && (
                                      <div className="p-4 rounded-2xl bg-slate-50 border-2 border-slate-100">
                                         <p className="text-[9px] font-black text-slate-400 uppercase mb-2">پاسخ مرجع</p>
                                         <p className="text-sm font-black text-slate-500">{String(q.correctAnswer)}</p>
                                      </div>
                                   )}
                                </div>
                             </div>
                             <div className="shrink-0 bg-slate-50 p-6 rounded-3xl min-w-[120px] flex flex-col items-center justify-center shadow-inner">
                                <p className="text-[9px] font-black text-slate-400 uppercase mb-2">امتیاز</p>
                                <div className="flex items-baseline gap-1">
                                   <span className={`text-3xl font-black ${isCorrect ? 'text-emerald-500' : 'text-slate-400'}`}>{isCorrect ? q.points : 0}</span>
                                   <span className="text-[10px] text-slate-300">/ {q.points}</span>
                                </div>
                             </div>
                          </div>
                       </div>
                    );
                 })}
              </div>
              
              <div className="bg-slate-900 p-10 rounded-[4rem] text-white space-y-10">
                 <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start">
                    <div className="md:col-span-4 flex flex-col items-center space-y-6">
                       <label className="text-[10px] font-black text-slate-500 uppercase">برآیند عددی نمره</label>
                       <ScoreRing score={tempScore} max={viewingResult.maxScore} size={150} stroke={12} />
                       <input type="number" step="0.25" value={tempScore} onChange={e => setTempScore(Number(e.target.value))} className="w-full p-6 bg-white/5 border-2 border-white/10 rounded-3xl text-center text-5xl font-black text-white" />
                    </div>
                    <div className="md:col-span-8 space-y-6">
                       <textarea value={tempFeedback} onChange={e => setTempFeedback(e.target.value)} className="w-full p-6 bg-white/5 border-2 border-white/10 rounded-3xl text-sm font-bold h-24 text-white" placeholder="بازخورد کیفی برای هنرجو..." />
                       {viewingResult.appealStatus === 'pending' && <textarea value={teacherResponse} onChange={e => setTeacherResponse(e.target.value)} className="w-full p-6 bg-amber-500/5 border-2 border-amber-500/20 rounded-3xl text-sm font-bold h-24 text-amber-100" placeholder="پاسخ به اعتراض هنرجو..." />}
                    </div>
                 </div>
                 <div className="pt-4 border-t border-white/5 flex gap-4">
                    <button onClick={() => setViewingResult(null)} className="flex-1 py-5 bg-white/5 hover:bg-white/10 rounded-2xl font-black text-white">انصراف</button>
                    <button onClick={handleSaveFinalScore} className="flex-[2] py-5 bg-emerald-600 hover:bg-emerald-500 rounded-2xl font-black text-white flex items-center justify-center gap-3"><Save size={24} /> ثبت نهایی و ابلاغ</button>
                 </div>
              </div>
           </div>
         )}
      </Modal>
    </div>
  );
};

export default TeacherExamGrading;
