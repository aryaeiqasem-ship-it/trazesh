
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { Grade } from '../types';
import { Search, Plus, Edit, Trash2, GraduationCap, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const AdminGrades: React.FC = () => {
  const [grades, setGrades] = useState<Grade[]>(() => storageService.getGrades());
  const [searchTerm, setSearchTerm] = useState('');
  const toast = useToast();
  
  useEffect(() => {
    storageService.saveGrades(grades);
  }, [grades]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGrade, setEditingGrade] = useState<Grade | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Partial<Grade>>({
    title: ''
  });

  const filteredGrades = grades.filter(g => g.title.includes(searchTerm));

  const handleOpenModal = (grade?: Grade) => {
    if (grade) {
      setEditingGrade(grade);
      setFormData({ ...grade });
    } else {
      setEditingGrade(null);
      setFormData({ title: '' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.title) {
      toast.error('عنوان پایه الزامی است.');
      return;
    }

    const newGrade: Grade = {
      id: editingGrade ? editingGrade.id : `g_${Date.now()}`,
      title: formData.title!
    };

    if (editingGrade) {
      setGrades(prev => prev.map(g => g.id === editingGrade.id ? newGrade : g));
      toast.success('پایه با موفقیت ویرایش شد.');
    } else {
      setGrades(prev => [...prev, newGrade]);
      toast.success('پایه جدید اضافه شد.');
    }
    setIsModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteId) {
      setGrades(prev => prev.filter(g => g.id !== deleteId));
      toast.info('پایه حذف شد.');
      setDeleteId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100">مدیریت پایه‌های تحصیلی</h1>
           <p className="text-sm text-slate-500">تعریف مقاطع آموزشی سامانه</p>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-primary-500/20 transition-all font-bold">
          <Plus size={18} />
          <span>افزودن پایه جدید</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative">
          <input
            type="text"
            placeholder="جستجو در پایه‌ها..."
            className="w-full pl-4 pr-10 py-3 bg-slate-50 dark:bg-slate-800 border-none rounded-xl outline-none focus:ring-2 focus:ring-primary-500 font-bold"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute right-3 top-3.5 text-slate-400" size={20} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {filteredGrades.map((grade) => (
            <motion.div 
              key={grade.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group"
            >
              <div className="flex justify-between items-start mb-4">
                 <div className="w-12 h-12 rounded-2xl bg-primary-50 dark:bg-primary-900/30 text-primary-600 flex items-center justify-center">
                    <GraduationCap size={24} />
                 </div>
                 <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleOpenModal(grade)} className="p-2 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"><Edit size={16} /></button>
                    <button onClick={() => setDeleteId(grade.id)} className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 size={16} /></button>
                 </div>
              </div>
              <h3 className="text-xl font-black text-slate-800 dark:text-white">{grade.title}</h3>
              <p className="text-xs text-slate-400 mt-1 font-mono">{grade.id}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingGrade ? 'ویرایش پایه' : 'افزودن پایه'}>
        <div className="p-6 space-y-4">
          <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">عنوان پایه تحصیلی</label>
              <input 
                type="text" 
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-primary-500 font-bold"
                placeholder="مثال: دوازدهم"
              />
          </div>
          <button onClick={handleSave} className="w-full py-4 bg-primary-600 text-white font-black rounded-2xl shadow-xl hover:bg-primary-700 transition-all flex items-center justify-center gap-2">
            <Save size={20} /> ذخیره پایه
          </button>
        </div>
      </Modal>

      <ConfirmationModal 
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={confirmDelete}
        title="حذف پایه تحصیلی"
        description="با حذف این پایه، تمامی دروس و کلاس‌های مرتبط با آن در وضعیت نامشخص قرار خواهند گرفت. آیا مطمئن هستید؟"
      />
    </div>
  );
};

export default AdminGrades;
