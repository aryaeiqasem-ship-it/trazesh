
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { UserRole, User, Major, Grade } from '../types';
import { Search, UserPlus, Edit, Trash2, Save, KeyRound, Loader2, Users as UsersIcon, GraduationCap, Layers, School, Mail, Phone } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import ConfirmationModal from '../components/ConfirmationModal';

const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [majors, setMajors] = useState<Major[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filterRole, setFilterRole] = useState<'ALL' | UserRole>('ALL');
  const [displaySearch, setDisplaySearch] = useState('');
  
  const toast = useToast();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<any>({
    name: '', role: UserRole.STUDENT, identifier: '', password: '', email: '', phoneNumber: '', grade: '', major: '', class: ''
  });

  const fetchUsersList = useCallback(async (isInitial = false) => {
    if (isInitial) setLoading(true);
    else setSearching(true);

    try {
      const result = await storageService.fetchUsers(page, 50, displaySearch, filterRole);
      const visibleUsers = (result.data as User[]).filter((u: User) => 
        u.role !== UserRole.DEVELOPER && u.role !== UserRole.SUPER_ADMIN
      );
      setUsers(visibleUsers);
      setTotalPages(result.pages || 1);
    } catch (err) {
      toast.error('خطا در دریافت لیست کاربران.');
    } finally {
      setLoading(false);
      setSearching(false);
    }
  }, [page, displaySearch, filterRole, toast]);

  useEffect(() => {
    fetchUsersList(page === 1 && displaySearch === '');
    setMajors(storageService.getMajors());
    setGrades(storageService.getGrades());
  }, [page, displaySearch, filterRole, fetchUsersList]);

  const handleOpenModal = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setFormData({
        name: user.name,
        role: user.role,
        identifier: user.role === UserRole.STUDENT ? (user.studentId || '') : (user.username || ''),
        grade: user.grade || '',
        major: user.major || '',
        class: user.class || '',
        email: user.email || '',
        phoneNumber: user.phoneNumber || '',
        password: '' 
      });
    } else {
      setEditingUser(null);
      setFormData({ name: '', role: UserRole.STUDENT, identifier: '', password: '', email: '', phoneNumber: '', grade: '', major: '', class: '' });
    }
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!formData.name || !formData.identifier) {
      toast.error('نام و شناسه کاربری الزامی است.');
      return;
    }

    try {
        const payload: Partial<User> = {
            id: editingUser?.id,
            name: formData.name,
            role: formData.role as UserRole,
            email: formData.email,
            phoneNumber: formData.phoneNumber,
            grade: formData.grade,
            major: formData.major,
            class: formData.class
        };
        
        if (formData.password) payload.password = formData.password;
        if (formData.role === UserRole.STUDENT) payload.studentId = formData.identifier;
        else payload.username = formData.identifier;

        const res = await storageService.saveUser(payload);
        if (res.ok) {
            toast.success(editingUser ? 'تغییرات حساب ثبت شد.' : 'کاربر جدید اضافه شد.');
            setIsModalOpen(false);
            fetchUsersList();
        }
    } catch (e) {
        toast.error('اختلال در ثبت اطلاعات.');
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
        const res = await storageService.deleteUser(deleteId);
        if (res.ok) {
            toast.success('حساب کاربری ابطال شد.');
            setDeleteId(null);
            fetchUsersList();
        }
    } catch (e) {
        toast.error('خطا در حذف کاربر.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-3">
             <UsersIcon className="text-primary-600" size={32} />
             مدیریت متمرکز کاربران
           </h1>
           <p className="text-sm text-slate-500 font-bold">کنترل سطوح دسترسی و نظارت بر حساب‌های شبکه</p>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3.5 rounded-2xl flex items-center gap-3 shadow-2xl transition-all font-black hover:scale-105 active:scale-95">
            <UserPlus size={20} /> <span>تعریف کاربر جدید</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border-4 border-slate-100 dark:border-slate-800 shadow-sm flex flex-col md:flex-row gap-4 items-center">
         <div className="relative flex-1 w-full group">
            <input
              type="text"
              placeholder="جستجوی سریع..."
              className="w-full pl-12 pr-6 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl focus:ring-4 focus:ring-primary-500/10 outline-none font-bold text-sm text-black"
              value={displaySearch}
              onChange={(e) => setDisplaySearch(e.target.value)}
            />
            <div className="absolute left-4 top-4 text-slate-300 group-focus-within:text-primary-500 transition-colors">
               {searching ? <Loader2 size={24} className="animate-spin text-primary-600" /> : <Search size={24} />}
            </div>
          </div>
          <div className="flex gap-2">
            <select 
              className="p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-xs text-black outline-none cursor-pointer"
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value as any)}
            >
              <option value="ALL">همه نقش‌ها</option>
              <option value={UserRole.STUDENT}>هنرجویان</option>
              <option value={UserRole.TEACHER}>مدرسین</option>
              <option value={UserRole.ADMIN}>مدیران سیستم</option>
            </select>
          </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[3rem] border-4 border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden relative min-h-[450px]">
        {loading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm z-10">
               <Loader2 className="animate-spin text-primary-600 mb-4" size={48} />
               <p className="text-slate-500 font-black text-xs uppercase tracking-[0.3em]">Synching...</p>
            </div>
        ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-400 text-[10px] font-black uppercase border-b">
                  <tr>
                    <th className="px-10 py-6">نام و اطلاعات پایه</th>
                    <th className="px-10 py-6 text-center">نقش سیستمی</th>
                    <th className="px-10 py-6 text-center">شناسه ورود</th>
                    <th className="px-10 py-6 text-center">عملیات</th>
                  </tr>
                </thead>
                <tbody className={`divide-y transition-opacity ${searching ? 'opacity-50' : 'opacity-100'}`}>
                  {users.map(user => (
                    <tr key={user.id} className="hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                      <td className="px-10 py-6 font-black text-slate-900 dark:text-white">
                         <div className="flex items-center gap-5">
                            <div className="w-12 h-12 rounded-[1.2rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-slate-500 overflow-hidden border shadow-sm">
                               {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : user.name.charAt(0)}
                            </div>
                            <div className="flex flex-col">
                               <span className="text-lg">{user.name}</span>
                               <span className="text-[10px] text-slate-400 font-black uppercase tracking-tighter mt-1">
                                 {user.role === UserRole.STUDENT ? `${user.grade || 'پایه نامشخص'} - ${user.major || ''}` : 'کادر آموزشی'}
                               </span>
                            </div>
                         </div>
                      </td>
                      <td className="px-10 py-6 text-center">
                        <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase border-2 ${
                          user.role === UserRole.ADMIN ? 'bg-rose-50 text-rose-600 border-rose-100' : 
                          user.role === UserRole.TEACHER ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 
                          'bg-emerald-50 text-emerald-600 border-emerald-100'
                        }`}>
                            {user.role}
                        </span>
                      </td>
                      <td className="px-10 py-6 font-mono text-xs text-slate-500 text-center">{user.studentId || user.username}</td>
                      <td className="px-10 py-6 text-center">
                         <div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => handleOpenModal(user)} className="p-3 text-blue-500 hover:bg-blue-50 rounded-xl transition-all"><Edit size={20}/></button>
                            <button onClick={() => setDeleteId(user.id)} className="p-3 text-red-500 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={20}/></button>
                         </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
        )}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingUser ? 'بروزرسانی کاربر' : 'تعریف کاربر جدید'} maxWidth="max-w-4xl">
         <div className="p-10 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">نام کامل</label>
                  <input className="w-full p-5 border-4 border-slate-100 dark:border-slate-800 rounded-[1.5rem] bg-white dark:bg-slate-900 text-black font-black outline-none focus:border-primary-500 transition-all" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="نام کامل" />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">نقش</label>
                  <select className="w-full p-5 border-4 border-slate-100 dark:border-slate-800 rounded-[1.5rem] bg-white dark:bg-slate-900 text-black font-black outline-none" value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})}>
                     <option value={UserRole.STUDENT}>دانش‌آموز</option>
                     <option value={UserRole.TEACHER}>مدرس</option>
                     <option value={UserRole.ADMIN}>مدیر سیستم</option>
                  </select>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">{formData.role === UserRole.STUDENT ? 'کدملی' : 'نام کاربری'}</label>
                  <div className="relative group">
                    <input className="w-full p-5 border-4 border-slate-100 dark:border-slate-800 rounded-[1.5rem] bg-white dark:bg-slate-900 text-black font-black outline-none focus:border-primary-500 transition-all" value={formData.identifier} onChange={e => setFormData({...formData, identifier: e.target.value})} />
                    <KeyRound className="absolute left-5 top-5 text-slate-300 group-focus-within:text-primary-500 transition-colors" size={24} />
                  </div>
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">گذرواژه</label>
                  <input type="password" className="w-full p-5 border-4 border-slate-100 dark:border-slate-800 rounded-[1.5rem] bg-white dark:bg-slate-900 text-black font-black outline-none focus:border-primary-500 transition-all" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="••••••••" />
               </div>
            </div>

            {formData.role === UserRole.STUDENT && (
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-8 bg-slate-50 dark:bg-slate-800/50 rounded-[2.5rem] border-4 border-slate-100">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase flex items-center gap-2"><GraduationCap size={14}/> پایه تحصیلی</label>
                    <select className="w-full p-4 border-2 border-slate-200 dark:border-slate-600 rounded-2xl bg-white dark:bg-slate-800 text-sm font-black text-black" value={formData.grade} onChange={e => setFormData({...formData, grade: e.target.value})}>
                        <option value="">انتخاب پایه...</option>
                        {grades.map(g => <option key={g.id} value={g.title}>{g.title}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase flex items-center gap-2"><Layers size={14}/> رشته تحصیلی</label>
                    <select className="w-full p-4 border-2 border-slate-200 dark:border-slate-600 rounded-2xl bg-white dark:bg-slate-800 text-sm font-black text-black" value={formData.major} onChange={e => setFormData({...formData, major: e.target.value})}>
                        <option value="">انتخاب رشته...</option>
                        {majors.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase flex items-center gap-2"><School size={14}/> کلاس</label>
                    <input className="w-full p-4 border-2 border-slate-200 dark:border-slate-600 rounded-2xl bg-white dark:bg-slate-800 text-sm font-black text-black" value={formData.class} onChange={e => setFormData({...formData, class: e.target.value})} placeholder="مثال: ۱۰۱" />
                  </div>
               </div>
            )}

            <div className="flex justify-end gap-3 pt-8 border-t-4 border-slate-50">
               <button onClick={() => setIsModalOpen(false)} className="px-8 py-4 text-slate-400 font-black uppercase text-xs">انصراف</button>
               <button onClick={handleSave} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-5 rounded-[2rem] font-black shadow-2xl flex items-center justify-center gap-3 transition-all hover:scale-[1.02]">
                  <Save size={24} /> ثبت نهایی
               </button>
            </div>
         </div>
      </Modal>

      <ConfirmationModal isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="ابطال حساب" description="آیا از حذف دسترسی این کاربر اطمینان دارید؟" confirmText="بله، ابطال شود" />
    </div>
  );
};

export default AdminUsers;
