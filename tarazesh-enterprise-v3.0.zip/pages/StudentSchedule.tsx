
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { ScheduleItem } from '../types';
import { Calendar, Clock, MapPin, User as UserIcon, Sun, Coffee } from 'lucide-react';
import { motion } from 'framer-motion';

const StudentSchedule: React.FC = () => {
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const days = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const persianDays: Record<string, string> = {
    'Saturday': 'شنبه',
    'Sunday': 'یکشنبه',
    'Monday': 'دوشنبه',
    'Tuesday': 'سه‌شنبه',
    'Wednesday': 'چهارشنبه',
    'Thursday': 'پنج‌شنبه',
    'Friday': 'جمعه'
  };

  useEffect(() => {
    // In a real app, filter by current user's class or teacher ID
    setSchedule(storageService.getSchedule());
  }, []);

  const getItemsForDay = (day: string) => {
    return schedule
      .filter(item => item.day === day)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
        <Calendar className="text-primary-600" />
        برنامه هفتگی کلاس‌ها
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {days.map((day, index) => {
          const items = getItemsForDay(day);
          const isHoliday = day === 'Friday'; // You can add more logic for specific dates here

          return (
            <motion.div 
              key={day}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`rounded-2xl border p-4 transition-all hover:shadow-md ${
                isHoliday
                  ? 'bg-rose-50 dark:bg-rose-900/10 border-rose-200 dark:border-rose-800 ring-1 ring-rose-100 dark:ring-rose-900/30'
                  : items.length > 0 
                    ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800' 
                    : 'bg-slate-50 dark:bg-slate-800/50 border-dashed border-slate-300 dark:border-slate-700'
              }`}
            >
              <div className={`flex justify-between items-center mb-4 pb-2 border-b ${isHoliday ? 'border-rose-100 dark:border-rose-800' : 'border-slate-100 dark:border-slate-800'}`}>
                <h3 className={`font-bold text-lg ${isHoliday ? 'text-rose-700 dark:text-rose-400' : 'text-slate-700 dark:text-slate-200'}`}>
                  {persianDays[day]}
                </h3>
                {isHoliday ? (
                   <span className="text-[10px] font-bold text-rose-600 bg-rose-100 dark:bg-rose-900/40 px-2 py-1 rounded-full flex items-center gap-1">
                      <Sun size={12} /> تعطیل رسمی
                   </span>
                ) : (
                   <span className="text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-full">
                     {items.length} کلاس
                   </span>
                )}
              </div>

              {isHoliday ? (
                <div className="flex flex-col items-center justify-center py-6 text-rose-300 dark:text-rose-700/50">
                   <Coffee size={48} className="mb-2 opacity-50" />
                   <p className="text-sm font-medium text-rose-400 dark:text-rose-500">روز استراحت و فراغت</p>
                </div>
              ) : items.length > 0 ? (
                <div className="space-y-3">
                  {items.map(item => (
                    <div key={item.id} className="relative pl-3 py-1 group">
                      <div className="absolute right-0 top-2 bottom-2 w-1 bg-gradient-to-b from-indigo-500 to-purple-500 rounded-full"></div>
                      <div className="pr-3">
                        <h4 className="font-bold text-slate-800 dark:text-slate-100">{item.courseTitle}</h4>
                        <div className="text-sm text-slate-500 dark:text-slate-400 mt-1 flex flex-col gap-1">
                          <span className="flex items-center gap-1">
                            <Clock size={14} /> {item.startTime} - {item.endTime}
                          </span>
                          <span className="flex items-center gap-1">
                            <UserIcon size={14} /> {item.teacherName}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-400 text-sm">
                  کلاسی تعریف نشده است
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default StudentSchedule;
