
import React from 'react';
import { MOCK_USERS } from '../services/mockData';
import { storageService } from '../services/storageService';
import { UserRole, Badge } from '../types';
import { Medal, Trophy, Star, Zap, Target, Lock, TrendingUp, Crown, Award } from 'lucide-react';
import { motion } from 'framer-motion';

const StudentAchievements: React.FC = () => {
  // Fetch logged in user data dynamically
  const users = storageService.getUsers();
  // For demo purposes, if mock login is used, find the mock user, otherwise find the first student
  const user = users.find(u => u.role === UserRole.STUDENT && u.gamification) || users.find(u => u.role === UserRole.STUDENT);
  
  if (!user || !user.gamification) return <div className="p-8 text-center text-slate-500">اطلاعات بازی‌سازی یافت نشد.</div>;

  const gamification = user.gamification;
  const progressPercent = (gamification.xp / gamification.nextLevelXp) * 100;
  const remainingXp = gamification.nextLevelXp - gamification.xp;

  // Split badges
  const earnedBadges = gamification.badges.filter(b => !b.isLocked);
  const lockedBadges = gamification.badges.filter(b => b.isLocked);

  const renderIcon = (iconName: string, className: string) => {
    switch (iconName) {
      case 'medal': return <Medal className={className} />;
      case 'trophy': return <Trophy className={className} />;
      case 'star': return <Star className={className} />;
      case 'zap': return <Zap className={className} />;
      case 'target': return <Target className={className} />;
      default: return <Medal className={className} />;
    }
  };

  const getBadgeStyle = (type: string) => {
    switch (type) {
      case 'gold': return 'bg-yellow-50 border-yellow-200 text-yellow-600 shadow-yellow-100 dark:bg-yellow-900/20 dark:border-yellow-700/50 dark:text-yellow-400 dark:shadow-none';
      case 'silver': return 'bg-slate-50 border-slate-300 text-slate-600 shadow-slate-200 dark:bg-slate-800 dark:border-slate-600 dark:text-slate-300 dark:shadow-none';
      case 'bronze': return 'bg-amber-50 border-amber-200 text-amber-700 shadow-amber-100 dark:bg-amber-900/20 dark:border-amber-700/50 dark:text-amber-400 dark:shadow-none';
      case 'platinum': return 'bg-cyan-50 border-cyan-200 text-cyan-600 shadow-cyan-100 dark:bg-cyan-900/20 dark:border-cyan-700/50 dark:text-cyan-400 dark:shadow-none';
      default: return 'bg-white border-slate-200 text-slate-600 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute right-0 top-0 w-64 h-64 bg-white rounded-full -mr-16 -mt-16 blur-3xl"></div>
          <div className="absolute left-0 bottom-0 w-48 h-48 bg-purple-300 rounded-full -ml-12 -mb-12 blur-3xl"></div>
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          {/* Level Circle */}
          <div className="relative">
            <div className="w-32 h-32 rounded-full border-4 border-white/30 flex items-center justify-center bg-white/10 backdrop-blur-sm shadow-inner">
               <div className="text-center">
                 <span className="block text-xs uppercase tracking-wider opacity-80">سطح</span>
                 <span className="block text-5xl font-black">{gamification.level}</span>
               </div>
            </div>
            <div className="absolute -bottom-2 -right-2 bg-yellow-400 text-yellow-900 w-10 h-10 rounded-full flex items-center justify-center border-2 border-white shadow-lg">
              <Crown size={20} fill="currentColor" />
            </div>
          </div>

          {/* XP Progress */}
          <div className="flex-1 w-full text-center md:text-right">
            <div className="flex justify-between items-end mb-2">
              <div>
                <h1 className="text-2xl font-bold">{user.name}</h1>
                <p className="text-indigo-200 text-sm">دانش‌آموز کوشا و پرتلاش</p>
              </div>
              <div className="text-right">
                <span className="text-3xl font-bold">{gamification.xp.toLocaleString()}</span>
                <span className="text-sm opacity-70 mr-1">XP</span>
              </div>
            </div>
            
            <div className="relative h-6 bg-black/20 rounded-full overflow-hidden backdrop-blur-sm border border-white/10">
              <div 
                className="absolute top-0 right-0 h-full bg-gradient-to-l from-yellow-400 to-orange-500 transition-all duration-1000 ease-out"
                style={{ width: `${progressPercent}%` }}
              >
                <div className="absolute top-0 right-0 w-full h-full bg-white/20 animate-pulse"></div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white drop-shadow-md">
                {progressPercent.toFixed(1)}% تا سطح بعدی
              </div>
            </div>
            
            <p className="mt-2 text-xs text-indigo-200 text-left dir-ltr">
              {remainingXp.toLocaleString()} XP needed for Level {gamification.level + 1}
            </p>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-3">
          <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400 rounded-lg">
             <Star size={24} fill="currentColor" />
          </div>
          <div>
            <p className="text-slate-500 dark:text-slate-400 text-xs">مدال‌های طلا</p>
            <p className="text-xl font-bold text-slate-800 dark:text-white">
              {gamification.badges.filter(b => b.type === 'gold' && !b.isLocked).length}
            </p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-3">
          <div className="p-3 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-lg">
             <Medal size={24} />
          </div>
          <div>
            <p className="text-slate-500 dark:text-slate-400 text-xs">مدال‌های نقره</p>
            <p className="text-xl font-bold text-slate-800 dark:text-white">
              {gamification.badges.filter(b => b.type === 'silver' && !b.isLocked).length}
            </p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-3">
          <div className="p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-500 rounded-lg">
             <Medal size={24} />
          </div>
          <div>
            <p className="text-slate-500 dark:text-slate-400 text-xs">مدال‌های برنز</p>
            <p className="text-xl font-bold text-slate-800 dark:text-white">
              {gamification.badges.filter(b => b.type === 'bronze' && !b.isLocked).length}
            </p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-3">
          <div className="p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
             <TrendingUp size={24} />
          </div>
          <div>
            <p className="text-slate-500 dark:text-slate-400 text-xs">رتبه در کلاس</p>
            <p className="text-xl font-bold text-slate-800 dark:text-white">#۳</p>
          </div>
        </div>
      </div>

      {/* Earned Badges Section (Prominent) */}
      {earnedBadges.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-sm relative overflow-hidden">
           <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-r from-yellow-400 to-amber-600"></div>
           <h2 className="text-xl font-black text-slate-800 dark:text-slate-100 mb-6 flex items-center gap-2">
             <Trophy className="text-amber-500" size={24} />
             گنجینه افتخارات
           </h2>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {earnedBadges.map((badge) => (
               <motion.div 
                 key={badge.id}
                 initial={{ opacity: 0, scale: 0.9 }}
                 animate={{ opacity: 1, scale: 1 }}
                 className={`relative p-6 rounded-2xl border-2 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${getBadgeStyle(badge.type)}`}
               >
                 <div className="flex items-start justify-between mb-4">
                   <div className="w-16 h-16 rounded-2xl bg-white/80 dark:bg-black/20 flex items-center justify-center text-4xl shadow-inner backdrop-blur-sm">
                     {renderIcon(badge.icon, "w-10 h-10")}
                   </div>
                   <span className="text-[10px] font-mono opacity-80 bg-white/50 dark:bg-black/20 px-2 py-1 rounded-md">
                     {badge.unlockedAt}
                   </span>
                 </div>
                 <h3 className="font-bold text-lg mb-1">{badge.title}</h3>
                 <p className="text-sm opacity-80 leading-relaxed">{badge.description}</p>
                 <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/20 to-transparent pointer-events-none rounded-2xl"></div>
               </motion.div>
             ))}
           </div>
        </div>
      )}

      {/* Locked Badges Section */}
      <div>
        <h2 className="text-lg font-bold text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-2 opacity-80">
          <Target className="text-slate-400" />
          نشان‌های قابل کسب
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {lockedBadges.map((badge) => (
            <div 
              key={badge.id} 
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 grayscale opacity-70 hover:opacity-100 hover:grayscale-0 transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                  {renderIcon(badge.icon, "w-5 h-5")}
                </div>
                <div>
                   <h3 className="font-bold text-sm text-slate-700 dark:text-slate-300">{badge.title}</h3>
                   <div className="flex items-center gap-1 text-[10px] text-slate-400">
                      <Lock size={10} /> قفل شده
                   </div>
                </div>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{badge.description}</p>
            </div>
          ))}
          {lockedBadges.length === 0 && (
             <div className="col-span-full p-8 text-center bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-dashed border-slate-300 dark:border-slate-700">
                <Award size={48} className="mx-auto text-green-500 mb-2 opacity-50"/>
                <p className="text-slate-500">تبریک! شما تمام نشان‌های فعلی را کسب کرده‌اید.</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentAchievements;
