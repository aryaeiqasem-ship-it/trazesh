
import React, { useMemo, useState } from 'react';
import { storageService } from '../services/storageService';
import { 
  BarChart3, Target, Activity, Calendar, ShieldCheck, 
  Award, TrendingUp, AlertCircle, FileText, CheckCircle2,
  Clock, Star, Heart, User as UserIcon, Trophy, Hash,
  History, Check, X, AlertTriangle, FileCheck, Globe, Database, Loader2,
  ClipboardList, PieChart as PieIcon, LineChart as LineIcon, Sparkles
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Radar, RadarChart, PolarGrid, 
  PolarAngleAxis, PieChart, Pie, Cell, BarChart, Bar
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { User, ExamResult, UserRole, Exam } from '../types';
import Modal from '../components/Modal';
import DigitalCertificate from '../components/DigitalCertificate';

interface ResultsProps {
  currentUser: User;
}

const StudentResults: React.FC<ResultsProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'exams' | 'attendance'>('overview');
  const [selectedExamForCert, setSelectedExamForCert] = useState<{res: ExamResult, exam: Exam} | null>(null);
  const [isVerifyingCert, setIsVerifyingCert] = useState(false);
  
  const allResults = storageService.getResults();
  const allUsers = storageService.getUsers();
  const results = allResults.filter(r => r.studentId === currentUser.id);
  const submissions = storageService.getSubmissions().filter(s => s.studentId === currentUser.id);
  const allAssignments = storageService.getAssignments();
  const exams = storageService.getExams();

  const studentAttendanceHistory = useMemo(() => {
      return storageService.getStudentAttendanceDetails(currentUser.id);
  }, [currentUser.id]);

  const metrics = useMemo(() => {
    const totalExams = results.length;
    const scores = results.map(r => (r.score / r.maxScore) * 20);
    const avgScore = totalExams ? (scores.reduce((acc, s) => acc + s, 0) / totalExams).toFixed(2) : '0';
    
    let presentCount = 0;
    let totalDays = studentAttendanceHistory.length;
    studentAttendanceHistory.forEach(rec => {
      if (rec.status === 'present' || rec.status === 'late') presentCount++;
    });
    const attendPercent = totalDays ? Math.round((presentCount / totalDays) * 100) : 100;

    const sameClassStudents = allUsers.filter(u => u.role === UserRole.STUDENT && u.class === currentUser.class);
    const rankings = sameClassStudents.map(student => {
      const studentResults = allResults.filter(r => r.studentId === student.id);
      const studentAvg = studentResults.length 
        ? studentResults.reduce((acc, r) => acc + (r.score / r.maxScore * 20), 0) / studentResults.length
        : 0;
      return { id: student.id, avg: studentAvg };
    }).sort((a, b) => b.avg - a.avg);

    const rank = rankings.findIndex(r => r.id === currentUser.id) + 1;

    return { 
        avgScore, 
        attendPercent, 
        totalExams, 
        assignmentsDone: submissions.length, 
        totalAssignments: allAssignments.length,
        rank, 
        totalInClass: rankings.length,
        participationScore: currentUser.gamification?.ipc || 0
    };
  }, [results, studentAttendanceHistory, submissions, allAssignments, currentUser, allResults, allUsers]);

  const handleOpenCertificate = (res: ExamResult, exam: Exam) => {
      setIsVerifyingCert(true);
      setTimeout(() => {
          setSelectedExamForCert({ res, exam });
          setIsVerifyingCert(false);
      }, 1500);
  };

  const radarData = [
    { subject: 'دقت', A: 85 },
    { subject: 'سرعت', A: 70 },
    { subject: 'انضباط', A: metrics.attendPercent },
    { subject: 'مشارکت', A: Math.min(metrics.participationScore * 2, 100) },
    { subject: 'تکالیف', A: Math.round((metrics.assignmentsDone / (metrics.totalAssignments || 1)) * 100) },
  ];

  const chartData = results.map((r, i) => ({ 
    name: `آزمون ${i+1}`, 
    score: (r.score / r.maxScore) * 20 
  }));

  return (
    <div className="space-y-8 pb-24 text-right" dir="rtl">
      <style>{`
        @media print {
          @page { size: A4; margin: 1cm; }
          body { background: white !important; }
          .no-print { display: none !important; }
          .print-area { display: block !important; box-shadow: none !important; border: none !important; padding: 0 !important; width: 100% !important; }
          .print-grid { grid-template-columns: repeat(2, 1fr) !important; }
          .recharts-responsive-container { height: 250px !important; }
        }
      `}</style>

      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-8 print:border-b print:rounded-none">
        <div className="flex items-center gap-6">
           <div className="w-20 h-20 bg-primary-600 rounded-[2rem] flex items-center justify-center text-white shadow-xl print:w-16 print:h-16">
              <BarChart3 size={40} />
           </div>
           <div className="text-right">
              <h1 className="text-3xl font-black text-slate-800 dark:text-white print:text-2xl">گزارش جامع پیشرفت تحصیلی</h1>
              <p className="text-sm text-slate-500 font-bold mt-1">هنرجو: {currentUser.name} | پایه {currentUser.grade} - {currentUser.major}</p>
           </div>
        </div>
        <div className="flex gap-4">
           <div className="text-center px-6 py-3 bg-slate-50 dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 print:bg-white">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">معدل کل</p>
              <p className="text-2xl font-black text-primary-600">{metrics.avgScore}</p>
           </div>
           <div className={`text-center px-6 py-3 rounded-3xl border print:bg-white ${metrics.rank <= 3 ? 'bg-amber-50 border-amber-200 text-amber-600' : 'bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700'}`}>
              <p className="text-[10px] font-black opacity-60 uppercase tracking-widest mb-1">رتبه کلاس</p>
              <div className="flex items-center justify-center gap-1">
                 <Trophy size={16} className={metrics.rank <= 3 ? 'block' : 'hidden'} />
                 <p className="text-2xl font-black">{metrics.rank} <span className="text-xs opacity-50">از {metrics.totalInClass}</span></p>
              </div>
           </div>
        </div>
      </div>

      <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit no-print">
         <button onClick={() => setActiveTab('overview')} className={`px-8 py-3 rounded-xl text-[11px] font-black transition-all ${activeTab === 'overview' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>نمای کلی</button>
         <button onClick={() => setActiveTab('exams')} className={`px-8 py-3 rounded-xl text-[11px] font-black transition-all ${activeTab === 'exams' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>ریز نمرات</button>
         <button onClick={() => setActiveTab('attendance')} className={`px-8 py-3 rounded-xl text-[11px] font-black transition-all ${activeTab === 'attendance' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>حضور و غیاب</button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'overview' && (
          <motion.div key="overview" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-8 print-area">
            <div className="bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl border border-white/5">
                <div className="absolute top-0 left-0 p-8 opacity-10"><Sparkles size={120}/></div>
                <div className="relative z-10 max-w-3xl">
                   <h3 className="text-xl font-black mb-4 flex items-center gap-3"><Activity className="text-amber-400" /> تحلیل هوشمند عملکرد (AI Insights)</h3>
                   <p className="text-sm font-bold leading-relaxed text-slate-300 italic">
                      « با تحلیل تلاقی نمرات آزمون‌ها و مشارکت کلاسی، هنرجو {currentUser.name} در مباحث نظری پایداری بالایی نشان داده است. رتبه {metrics.rank} کلاس نشان‌دهنده پتانسیل بالای وی در رقابت‌های تیمی است. پیشنهاد می‌شود در بخش تحویل به موقع تکالیف (نرخ فعلی {Math.round((metrics.assignmentsDone / (metrics.totalAssignments || 1)) * 100)}٪) تمرکز بیشتری اعمال گردد. »
                   </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 print-grid">
               <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="text-lg font-black mb-8 flex items-center gap-2 text-right">
                     <Target size={20} className="text-primary-600" /> رادار مهارت‌ها
                  </h3>
                  <div className="h-64">
                     <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                           <PolarGrid stroke="#e2e8f0" />
                           <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 'bold' }} />
                           <Radar name="Student" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.6} isAnimationActive={false} />
                        </RadarChart>
                     </ResponsiveContainer>
                  </div>
               </div>

               <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="text-lg font-black mb-8 flex items-center gap-2 text-right">
                     <TrendingUp size={20} className="text-emerald-500" /> نمودار رشد تحصیلی
                  </h3>
                  <div className="h-64">
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                           <XAxis dataKey="name" hide />
                           <YAxis domain={[0, 20]} fontSize={10} tick={{fill: '#94a3b8'}} axisLine={false} />
                           <Tooltip />
                           <Area type="monotone" dataKey="score" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.1} strokeWidth={4} isAnimationActive={false} />
                        </AreaChart>
                     </ResponsiveContainer>
                  </div>
               </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 print-grid">
               <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 rounded-2xl flex items-center justify-center shadow-inner"><ShieldCheck size={24}/></div>
                  <div>
                     <p className="text-[9px] font-black text-slate-400 uppercase mb-1">میزان حضور</p>
                     <p className="text-xl font-black">{metrics.attendPercent}%</p>
                  </div>
               </div>
               <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 rounded-2xl flex items-center justify-center shadow-inner"><ClipboardList size={24}/></div>
                  <div>
                     <p className="text-[9px] font-black text-slate-400 uppercase mb-1">تکالیف تحویلی</p>
                     <p className="text-xl font-black">{metrics.assignmentsDone} <span className="text-xs opacity-50">از {metrics.totalAssignments}</span></p>
                  </div>
               </div>
               <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                  <div className="w-12 h-12 bg-amber-50 dark:bg-amber-900/20 text-amber-600 rounded-2xl flex items-center justify-center shadow-inner"><Star size={24}/></div>
                  <div>
                     <p className="text-[9px] font-black text-slate-400 uppercase mb-1">امتیاز کلاسی</p>
                     <p className="text-xl font-black">{metrics.participationScore}</p>
                  </div>
               </div>
               <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                  <div className="w-12 h-12 bg-rose-50 dark:bg-rose-900/20 text-rose-600 rounded-2xl flex items-center justify-center shadow-inner"><Heart size={24}/></div>
                  <div>
                     <p className="text-[9px] font-black text-slate-400 uppercase mb-1">انضباط</p>
                     <p className="text-xl font-black text-emerald-500">عالی</p>
                  </div>
               </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden mt-8">
              <div className="p-8 border-b bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                 <h3 className="text-xl font-black flex items-center gap-3"><FileText className="text-primary-500"/> جزییات نتایج آزمون‌های ترم</h3>
                 <span className="text-[10px] font-black text-slate-400 uppercase">مجموع {results.length} مورد</span>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-right">
                    <thead>
                       <tr className="bg-slate-50 dark:bg-slate-950 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                          <th className="p-6">عنوان آزمون</th>
                          <th className="p-6 text-center">نمره (از ۲۰)</th>
                          <th className="p-6 text-center">تاریخ شرکت</th>
                          <th className="p-6 text-center">وضعیت نهایی</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                       {results.length === 0 ? (
                         <tr><td colSpan={4} className="p-10 text-center text-slate-400 font-bold italic">داده‌ای برای نمایش وجود ندارد.</td></tr>
                       ) : results.map(r => {
                          const exam = exams.find(e => e.id === r.examId);
                          const scaled = (r.score / (r.maxScore || 1)) * 20;
                          return (
                             <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                <td className="p-6 font-bold">{exam?.title || 'آزمون سیستمی'}</td>
                                <td className="p-6 text-center"><span className="text-lg font-black text-primary-600">{scaled.toFixed(1)}</span></td>
                                <td className="p-6 text-center text-xs font-bold text-slate-400">{new Date(r.submittedAt).toLocaleDateString('fa-IR')}</td>
                                <td className="p-6 text-center">
                                   <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase ${r.status === 'passed' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                                      {r.status === 'passed' ? 'قبول' : 'مردود'}
                                   </span>
                                </td>
                             </tr>
                          )
                       })}
                    </tbody>
                 </table>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'exams' && (
           <motion.div key="exams" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                 <h3 className="text-xl font-black">ریز نمرات آزمون‌ها</h3>
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{results.length} مورد</span>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-right">
                    <thead>
                       <tr className="bg-slate-50 dark:bg-slate-950 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                          <th className="p-6">عنوان آزمون</th>
                          <th className="p-6 text-center">نمره (از ۲۰)</th>
                          <th className="p-6 text-center">تاریخ</th>
                          <th className="p-6 text-center">مدرک نهایی</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                       {results.length === 0 ? (
                         <tr><td colSpan={4} className="p-10 text-center text-slate-400 font-bold">آزمونی ثبت نشده است.</td></tr>
                       ) : results.map(r => {
                          const exam = exams.find(e => e.id === r.examId);
                          const scaled = (r.score / r.maxScore) * 20;
                          const isPassed = r.status === 'passed';
                          return (
                             <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                                <td className="p-6 font-bold text-slate-700 dark:text-slate-200">{exam?.title || 'نامشخص'}</td>
                                <td className="p-6 text-center">
                                   <span className={`text-lg font-black ${isPassed ? 'text-emerald-600' : 'text-rose-600'}`}>{scaled.toFixed(1)}</span>
                                </td>
                                <td className="p-6 text-center text-xs font-bold text-slate-400 font-mono">
                                   {new Date(r.submittedAt).toLocaleDateString('fa-IR')}
                                </td>
                                <td className="p-6 text-center">
                                   {isPassed ? (
                                      <button 
                                        onClick={() => handleOpenCertificate(r, exam!)}
                                        disabled={isVerifyingCert}
                                        className="bg-amber-50 dark:bg-amber-900/20 text-amber-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center gap-2 mx-auto border border-amber-100 hover:bg-amber-500 hover:text-white transition-all shadow-sm disabled:opacity-50"
                                      >
                                         {isVerifyingCert ? <Loader2 size={14} className="animate-spin"/> : <FileCheck size={14}/>} مشاهده گواهینامه
                                      </button>
                                   ) : (
                                      <span className="text-[9px] font-bold text-slate-300">عدم احراز شرایط</span>
                                   )}
                                </td>
                             </tr>
                          )
                       })}
                    </tbody>
                 </table>
              </div>
           </motion.div>
        )}

        {activeTab === 'attendance' && (
           <motion.div key="attendance" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/30 dark:bg-slate-800/30">
                 <div className="flex items-center gap-3">
                    <History className="text-primary-500" />
                    <h3 className="text-xl font-black">تاریخچه حضور و غیاب تفصیلی</h3>
                 </div>
                 <div className="flex gap-4">
                    <span className="flex items-center gap-1.5 text-[10px] font-black text-emerald-600"><Check size={12}/> حاضر</span>
                    <span className="flex items-center gap-1.5 text-[10px] font-black text-amber-600"><Clock size={12}/> تاخیر</span>
                    <span className="flex items-center gap-1.5 text-[10px] font-black text-rose-600"><X size={12}/> غایب</span>
                 </div>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-right">
                    <thead>
                       <tr className="bg-slate-50 dark:bg-slate-950 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                          <th className="p-6">نام واحد آموزشی (کلاس)</th>
                          <th className="p-6 text-center">تاریخ جلسه</th>
                          <th className="p-6 text-center">وضعیت حضور</th>
                          <th className="p-6 text-center">امتیاز انضباطی</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                       {studentAttendanceHistory.length === 0 ? (
                         <tr><td colSpan={4} className="p-20 text-center text-slate-400 font-bold">هنوز سابقه‌ای در سیستم ثبت نشده است.</td></tr>
                       ) : studentAttendanceHistory.map((rec, idx) => (
                          <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                             <td className="p-6">
                                <div className="flex items-center gap-3">
                                   <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400"><History size={16}/></div>
                                   <span className="font-bold text-slate-700 dark:text-slate-200">{rec.className}</span>
                                </div>
                             </td>
                             <td className="p-6 text-center font-mono text-xs font-bold text-slate-500">
                                {new Date(rec.date).toLocaleDateString('fa-IR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                             </td>
                             <td className="p-6 text-center">
                                {rec.status === 'present' && <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase"><Check size={12}/> حاضر</span>}
                                {rec.status === 'late' && <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-[10px] font-black uppercase"><Clock size={12}/> تاخیر</span>}
                                {rec.status === 'absent' && <span className="inline-flex items-center gap-1 px-3 py-1 bg-rose-50 text-rose-600 rounded-full text-[10px] font-black uppercase"><X size={12}/> غایب</span>}
                             </td>
                             <td className="p-6 text-center">
                                <span className={`text-sm font-black ${rec.status === 'present' ? 'text-emerald-500' : rec.status === 'late' ? 'text-amber-500' : 'text-rose-500'}`}>
                                   {rec.status === 'present' ? '+۱' : rec.status === 'late' ? '۰' : '-۱'}
                                </span>
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </motion.div>
        )}
      </AnimatePresence>

      <Modal isOpen={!!selectedExamForCert} onClose={() => setSelectedExamForCert(null)} title="گواهینامه رسمی شایستگی" maxWidth="max-w-5xl">
          {selectedExamForCert && (
            <div className="p-4 flex flex-col items-center gap-8">
               <DigitalCertificate 
                  userName={currentUser.name} 
                  examTitle={selectedExamForCert.exam.title}
                  score={(selectedExamForCert.res.score / selectedExamForCert.res.maxScore) * 20}
                  date={new Date(selectedExamForCert.res.submittedAt).toLocaleDateString('fa-IR')}
                  securityHash={`TRZ-${selectedExamForCert.res.id.toUpperCase()}`}
               />
               <button onClick={() => window.print()} className="bg-primary-600 text-white px-12 py-4 rounded-2xl font-black text-sm shadow-2xl flex items-center gap-3 hover:scale-105 transition-all no-print">
                  <Globe size={20}/> چاپ یا ذخیره به عنوان PDF
               </button>
            </div>
          )}
      </Modal>

      <AnimatePresence>
        {isVerifyingCert && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[10005] bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center text-white no-print">
                <div className="relative w-24 h-24 mb-6">
                    <div className="absolute inset-0 border-4 border-primary-500/20 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-primary-500 rounded-full border-t-transparent animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center text-primary-500"><Database size={40} /></div>
                </div>
                <h3 className="text-xl font-black uppercase tracking-widest animate-pulse">Verifying Blockchain Record...</h3>
                <p className="text-slate-400 font-bold text-xs mt-2">Connecting to decentralized validation node</p>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default StudentResults;
