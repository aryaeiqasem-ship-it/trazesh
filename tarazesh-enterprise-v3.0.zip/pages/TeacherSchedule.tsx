
import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { ScheduleItem, User, ClassEntity, Course } from '../types';
import { 
  Calendar, Clock, Plus, Trash2, Save, Edit, 
  BookOpen, School, StickyNote, FileText, 
  ChevronLeft, ChevronRight, Hash, Info, 
  CheckCircle2, AlertCircle, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';

const TeacherSchedule: React.FC<{ currentUser: User }> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'calendar' | 'notes'>('calendar');
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [personalNotes, setPersonalNotes] = useState('');
  const [classes, setClasses] = useState<ClassEntity[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ScheduleItem | null>(null);
  const [formData, setFormData] = useState<Partial<ScheduleItem>>({
    day: 'Saturday', startTime: '08:00', endTime: '09:30', courseTitle: '', teacherName: currentUser.name
  });

  const toast = useToast();

  const days = [
    { id: 'Saturday', label: 'شنبه' },
    { id: 'Sunday', label: 'یکشنبه' },
    { id: 'Monday', label: 'دوشنبه' },
    { id: 'Tuesday', label: 'سه‌شنبه' },
    { id: 'Wednesday', label: 'چهارشنبه' },
    { id: 'Thursday', label: 'پنج‌شنبه' },
    { id: 'Friday', label: 'جمعه' }
  ];

  useEffect(() => {
    const allSchedule = storageService.getSchedule();
    setSchedule(allSchedule.filter(s => s.teacherName === currentUser.name));
    setClasses(storageService.getClasses());
    setCourses(storageService.getCourses());
    setPersonalNotes(storageService.getTeacherNotes(currentUser.id));
  }, [currentUser]);

  const handleSaveNotes = () => {
    storageService.saveTeacherNotes(currentUser.id, personalNotes);
    toast.success('یادداشت‌های شما در هسته مرکزی ذخیره شد.');
  };

  const handleOpenModal = (item?: ScheduleItem) => {
    if (item) {
      setEditingItem(item);
      setFormData({ ...item });
    } else {
      setEditingItem(null);
      setFormData({ day: 'Saturday', startTime: '08:00', endTime: '09:30', courseTitle: '', teacherName: currentUser.name });
    }
    setIsModalOpen(true);
  };

  const handleSaveItem = () => {
    if (!formData.courseTitle || !formData.day) return toast.error('لطفا مشخصات کلاس را تکمیل کنید.');
    
    let updatedSchedule: ScheduleItem[];
    if (editingItem) {
      updatedSchedule = schedule.map(s => s.id === editingItem.id ? { ...s, ...formData } as ScheduleItem : s);
    } else {
      const newItem: ScheduleItem = {
        ...formData,
        id: `sch_${Date.now()}`,
        teacherName: currentUser.name
      } as ScheduleItem;
      updatedSchedule = [...schedule, newItem];
    }

    setSchedule(updatedSchedule);
    const globalSchedule = storageService.getSchedule();
    const otherTeachersItems = globalSchedule.filter(s => s.teacherName !== currentUser.name);
    storageService.saveSchedule([...otherTeachersItems, ...updatedSchedule]);
    
    setIsModalOpen(false);
    toast.success('برنامه زمانی با موفقیت بروزرسانی شد.');
  };

  const handleDeleteItem = (id: string) => {
    const updated = schedule.filter(s => s.id !== id);
    setSchedule(updated);
    const globalSchedule = storageService.getSchedule();
    const others = globalSchedule.filter(s => s.teacherName !== currentUser.name);
    storageService.saveSchedule([...others, ...updated]);
    toast.info('زمان‌بندی از برنامه حذف شد.');
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-5">
           <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-3xl flex items-center justify-center text-primary-600 shadow-inner">
             <Calendar size={36} />
           </div>
           <div>
              <h1 className="text-3xl font-black text-slate-950 dark:text-slate-50 tracking-tight">برنامه‌ریزی و مدیریت زمان</h1>
              <p className="text-sm text-slate-500 font-bold mt-1">تنظیم ساعات تدریس و یادداشت‌های شخصی مدرس</p>
           </div>
        </div>
        <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl border">
           <button onClick={() => setActiveTab('calendar')} className={`px-8 py-3 rounded-xl text-xs font-black transition-all ${activeTab === 'calendar' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>برنامه هفتگی</button>
           <button onClick={() => setActiveTab('notes')} className={`px-8 py-3 rounded-xl text-xs font-black transition-all ${activeTab === 'notes' ? 'bg-white dark:bg-slate-700 text-primary-600 shadow-xl' : 'text-slate-500'}`}>یادداشت‌های من</button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'calendar' ? (
          <motion.div key="calendar" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6">
            <div className="flex justify-end">
               <button onClick={() => handleOpenModal()} className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 rounded-2xl flex items-center gap-2 shadow-xl font-black transition-all hover:scale-105">
                  <Plus size={20}/> افزودن شیفت تدریس
               </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
               {days.map(day => {
                  const dayItems = schedule.filter(s => s.day === day.id).sort((a,b) => a.startTime.localeCompare(b.startTime));
                  return (
                    <div key={day.id} className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col h-full">
                       <div className="bg-slate-50 dark:bg-slate-800/50 p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                          <h3 className="font-black text-slate-950 dark:text-slate-50">{day.label}</h3>
                          <span className="text-[10px] font-black text-slate-500 bg-white dark:bg-slate-900 px-3 py-1 rounded-full border">{dayItems.length} کلاس</span>
                       </div>
                       <div className="p-4 space-y-3 flex-1">
                          {dayItems.length === 0 ? (
                            <div className="py-10 text-center opacity-40 italic text-xs font-black text-slate-400">کلاسی ثبت نشده است</div>
                          ) : dayItems.map(item => (
                            <div key={item.id} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border-2 border-transparent hover:border-primary-200 transition-all group">
                               <div className="flex justify-between items-start mb-2">
                                  <div className="flex items-center gap-2 min-w-0">
                                     <div className="w-2 h-2 rounded-full bg-primary-500 shrink-0"></div>
                                     <h4 className="font-black text-sm text-slate-900 dark:text-slate-100 truncate">{item.courseTitle}</h4>
                                  </div>
                                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                     <button onClick={() => handleOpenModal(item)} className="p-1 text-blue-600 hover:bg-blue-50 rounded-md"><Edit size={14}/></button>
                                     <button onClick={() => handleDeleteItem(item.id)} className="p-1 text-rose-600 hover:bg-rose-50 rounded-md"><Trash2 size={14}/></button>
                                  </div>
                               </div>
                               <div className="flex items-center gap-4 text-[11px] font-black text-slate-600 dark:text-slate-400">
                                  <span className="flex items-center gap-1.5"><Clock size={13} className="text-primary-500"/> {item.startTime} تا {item.endTime}</span>
                               </div>
                            </div>
                          ))}
                       </div>
                    </div>
                  );
               })}
            </div>
          </motion.div>
        ) : (
          <motion.div key="notes" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
               <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none text-slate-900 dark:text-white"><StickyNote size={200}/></div>
               <div className="relative z-10 space-y-6">
                  <div className="flex items-center gap-4 mb-4">
                     <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 shadow-inner"><StickyNote size={28}/></div>
                     <h3 className="text-2xl font-black text-slate-900 dark:text-slate-50">دفترچه یادداشت دیجیتال</h3>
                  </div>
                  <textarea 
                    className="w-full p-8 bg-slate-50 dark:bg-slate-800/50 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-[2.5rem] min-h-[400px] outline-none focus:border-primary-500 font-bold text-lg leading-relaxed text-slate-900 dark:text-slate-100 shadow-inner"
                    placeholder="نکات مهم کلاسی، ایده‌های تدریس یا پیگیری‌های هنرجویان را اینجا یادداشت کنید..."
                    value={personalNotes}
                    onChange={e => setPersonalNotes(e.target.value)}
                  />
                  <div className="flex justify-end">
                     <button onClick={handleSaveNotes} className="bg-primary-600 hover:bg-primary-700 text-white px-12 py-4 rounded-2xl font-black shadow-2xl flex items-center gap-3 transition-all hover:scale-105 active:scale-95">
                        <Save size={24}/> ذخیره یادداشت‌ها
                     </button>
                  </div>
               </div>
            </div>
            <div className="bg-blue-50 dark:bg-primary-900/10 p-6 rounded-3xl border border-blue-100 dark:border-primary-800 flex items-center gap-4">
               <Sparkles className="text-primary-600" size={24}/>
               <p className="text-sm font-black text-primary-900 dark:text-primary-100">یادداشت‌های شما کاملاً شخصی است و فقط در پنل کاربری شما قابل رویت می‌باشد.</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={<span className="font-black text-slate-900 dark:text-slate-50">{editingItem ? 'ویرایش کلاس در برنامه' : 'افزودن کلاس جدید به برنامه'}</span>}>
         <div className="p-8 space-y-6">
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-2 text-right">
                  <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest mr-2">روز هفته</label>
                  <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-primary-500" value={formData.day} onChange={e => setFormData({...formData, day: e.target.value})}>
                     {days.map(d => <option key={d.id} value={d.id} className="text-slate-900">{d.label}</option>)}
                  </select>
               </div>
               <div className="space-y-2 text-right">
                  <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest mr-2">نام واحد درسی</label>
                  <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-primary-500" value={formData.courseTitle} onChange={e => setFormData({...formData, courseTitle: e.target.value})}>
                     <option value="" className="text-slate-900">انتخاب درس...</option>
                     {courses.map(c => <option key={c.id} value={c.title} className="text-slate-900">{c.title}</option>)}
                  </select>
               </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-2 text-right">
                  <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest mr-2">ساعت شروع</label>
                  <input type="time" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-primary-500" value={formData.startTime} onChange={e => setFormData({...formData, startTime: e.target.value})} />
               </div>
               <div className="space-y-2 text-right">
                  <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest mr-2">ساعت پایان</label>
                  <input type="time" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-primary-500" value={formData.endTime} onChange={e => setFormData({...formData, endTime: e.target.value})} />
               </div>
            </div>
            <button onClick={handleSaveItem} className="w-full py-5 bg-primary-600 hover:bg-primary-700 text-white rounded-[2rem] font-black shadow-xl flex items-center justify-center gap-3 transition-all active:scale-95">
               <Save size={24}/> ثبت در برنامه هفتگی
            </button>
         </div>
      </Modal>
    </div>
  );
};

export default TeacherSchedule;
