
import React, { useState, useEffect, useCallback } from 'react';
import Layout from '../components/Layout';
import LoginPage from './LoginPage';
import ForgotPasswordPage from './ForgotPasswordPage';
import StudentHome from './StudentHome';
import StudentDashboard from './StudentDashboard';
import StudentResults from './StudentResults';
import StudentAssignments from './StudentAssignments'; 
import StudentAchievements from './StudentAchievements';
import StudentMarket from './StudentMarket';
import StudentSettings from './StudentSettings';
import StudentResources from './StudentResources';
import StudentLearningPath from './StudentLearningPath';
import TeacherDashboard from './TeacherDashboard';
import TeacherExams from './TeacherExams';
import TeacherStudents from './TeacherStudents';
import TeacherReports from './TeacherReports';
import TeacherQuestionBank from './TeacherQuestionBank';
import TeacherExamGrading from './TeacherExamGrading';
import TeacherLiveMonitor from './TeacherLiveMonitor';
import TeacherClassManagement from './TeacherClassManagement'; 
import TeacherAssignments from './TeacherAssignments';
import TeacherSettings from './TeacherSettings';
import TeacherResources from './TeacherResources';
import TeacherSchedule from './TeacherSchedule';
import AdminDashboard from './AdminDashboard';
import AdminUsers from './AdminUsers';
import AdminSettings from './AdminSettings';
import AdminCourses from './AdminCourses';
import AdminEducationStructure from './AdminEducationStructure';
import AdminClasses from './AdminClasses';
import AdminReports from './AdminReports';
import AdminSubscription from './AdminSubscription';
import ParentDashboard from './ParentDashboard';
import DeveloperDashboard from './DeveloperDashboard';
import SuperAdminDashboard from './SuperAdminDashboard';
import Messenger from './Messenger';
import PageTransition from '../components/PageTransition';
import Modal from '../components/Modal';
import { User, UserRole, Exam } from '../types';
import { storageService } from '../services/storageService'; 
import { ThemeProvider } from '../contexts/ThemeContext';
import { ToastProvider, useToast } from '../contexts/ToastContext';
import { AnimatePresence, motion } from 'framer-motion';
import { School, ShieldAlert, Lock, Cpu, ArrowLeft, Terminal, ShieldCheck } from 'lucide-react';

const AppContent: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<string>('');
  const [isInitializing, setIsInitializing] = useState(true);
  const [navData, setNavData] = useState<any>(null);
  const [devModeActive, setDevModeActive] = useState(false);
  const [superModeActive, setSuperModeActive] = useState(false);
  const [showStrategicLogin, setShowStrategicLogin] = useState(false);
  const toast = useToast();

  const [strategicUser, setStrategicUser] = useState('');
  const [strategicPass, setStrategicPass] = useState('');

  const handleLogout = useCallback(() => { 
    localStorage.removeItem('auth_token');
    localStorage.removeItem('current_user');
    setUser(null); 
    setCurrentView(''); 
    setDevModeActive(false);
    setSuperModeActive(false);
  }, []);

  const refreshUser = useCallback(() => {
    const latestUser = storageService.getCurrentUser();
    if (latestUser) setUser(latestUser);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isLKey = e.code === 'KeyL' || e.key.toLowerCase() === 'l';
      if (e.ctrlKey && e.altKey && e.shiftKey && isLKey) {
        e.preventDefault();
        if (user?.role === UserRole.SUPER_ADMIN) {
          const nextSuperMode = !superModeActive;
          setSuperModeActive(nextSuperMode);
          if (nextSuperMode) {
            setCurrentView('super_admin_dashboard');
            toast.success('پنل استراتژیک فعال شد.');
          } else setCurrentView('student_home');
        } else if (!user) {
          setShowStrategicLogin(true);
          toast.info('درگاه دسترسی استراتژیک فراخوانی شد.');
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [user, superModeActive, toast]);

  const handleStrategicLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const allUsers = storageService.getUsers();
    const found = allUsers.find((u: User) => u.role === UserRole.SUPER_ADMIN && u.username === strategicUser && u.password === strategicPass);

    if (found) {
        localStorage.setItem('auth_token', 'SUPER_ADMIN_SECURE_TOKEN_' + Date.now());
        localStorage.setItem('current_user', JSON.stringify(found));
        setUser(found);
        setSuperModeActive(true);
        setCurrentView('super_admin_dashboard');
        setShowStrategicLogin(false);
        setStrategicUser('');
        setStrategicPass('');
        toast.success('تایید هویت حاکمیتی موفقیت‌آمیز بود.');
    } else {
        toast.error('کد دسترسی یا امضای دیجیتال نامعتبر است.');
    }
  };

  useEffect(() => {
    const initApp = async () => {
      await storageService.initializeFromServer();
      const savedUser = localStorage.getItem('current_user');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        if (parsed.role === UserRole.DEVELOPER) setDevModeActive(true);
        if (parsed.role === UserRole.SUPER_ADMIN) setSuperModeActive(true);
      }
      setTimeout(() => setIsInitializing(false), 500);
    };
    initApp();
  }, []);

  useEffect(() => {
    if (user && !currentView) {
      if (user.role === UserRole.STUDENT) setCurrentView('student_home'); 
      else if (user.role === UserRole.TEACHER) setCurrentView('teacher_dashboard');
      else if (user.role === UserRole.ADMIN) setCurrentView('admin_dashboard');
      else if (user.role === UserRole.PARENT) setCurrentView('parent_dashboard');
      else if (user.role === UserRole.DEVELOPER) setCurrentView('developer_dashboard');
      else if (user.role === UserRole.SUPER_ADMIN) setCurrentView('super_admin_dashboard');
    }
  }, [user, currentView]);

  const handleLogin = (userData: any, token: string) => {
    localStorage.setItem('auth_token', token);
    const allUsers = storageService.getUsers();
    const fullUser = allUsers.find((u: User) => u.id === userData.id || u.studentId === userData.id || u.username === userData.id) || userData;
    localStorage.setItem('current_user', JSON.stringify(fullUser));
    setUser(fullUser);
    if (fullUser.role === UserRole.DEVELOPER) setDevModeActive(true);
    if (fullUser.role === UserRole.SUPER_ADMIN) setSuperModeActive(true);
    toast.success(`خوش آمدید، ${fullUser.name}`);
  };

  const handleNavigation = (view: string, data?: any) => {
    setNavData(data || null);
    setCurrentView(view);
  };

  const renderContent = () => {
    if (!user) return null;
    let content;
    switch (currentView) {
      case 'student_home': content = <StudentHome currentUser={user} onNavigate={handleNavigation} />; break;
      case 'student_learning_path': content = <StudentLearningPath currentUser={user} />; break;
      case 'student_exams': content = <StudentDashboard availableExams={storageService.getExams()} currentUser={user} onNavigate={handleNavigation} />; break;
      case 'student_exam_preview': content = <StudentDashboard isPreview={true} availableExams={[navData]} currentUser={user} onNavigate={handleNavigation} />; break;
      case 'student_results': content = <StudentResults currentUser={user} />; break;
      case 'student_assignments': content = <StudentAssignments />; break;
      case 'student_achievements': content = <StudentAchievements />; break;
      case 'student_market': content = <StudentMarket currentUser={user} onRefreshUser={refreshUser} />; break;
      case 'student_resources': content = <StudentResources />; break;
      case 'student_settings': content = <StudentSettings currentUser={user} onRefreshUser={refreshUser} />; break;
      case 'teacher_dashboard': content = <TeacherDashboard currentUser={user} onNavigate={handleNavigation} />; break;
      case 'teacher_schedule': content = <TeacherSchedule currentUser={user} />; break;
      case 'teacher_exams': content = <TeacherExams onNavigate={handleNavigation} />; break;
      case 'teacher_question_bank': content = <TeacherQuestionBank />; break;
      case 'teacher_grading': content = <TeacherExamGrading examId={navData} onBack={() => setCurrentView('teacher_exams')} />; break;
      case 'teacher_live_monitor': content = <TeacherLiveMonitor examId={navData} onBack={() => setCurrentView('teacher_exams')} />; break;
      case 'teacher_classes': content = <TeacherClassManagement />; break;
      case 'teacher_assignments': content = <TeacherAssignments />; break;
      case 'teacher_students': content = <TeacherStudents onNavigate={handleNavigation} />; break;
      case 'teacher_resources': content = <TeacherResources />; break;
      case 'teacher_reports': content = <TeacherReports />; break;
      case 'teacher_settings': content = <TeacherSettings currentUser={user} onRefreshUser={refreshUser} />; break;
      case 'admin_dashboard': content = <AdminDashboard onNavigate={handleNavigation} />; break;
      case 'admin_reports': content = <AdminReports />; break;
      case 'admin_users': content = <AdminUsers />; break;
      case 'admin_settings': content = <AdminSettings />; break;
      case 'admin_courses': content = <AdminCourses />; break;
      case 'admin_education_structure': content = <AdminEducationStructure />; break;
      case 'admin_classes': content = <AdminClasses />; break;
      case 'admin_subscription': content = <AdminSubscription onRefreshUser={refreshUser} />; break;
      case 'parent_dashboard': content = <ParentDashboard currentUser={user} onNavigate={handleNavigation} />; break;
      case 'developer_dashboard': content = <DeveloperDashboard />; break;
      case 'super_admin_dashboard': content = <SuperAdminDashboard />; break;
      case 'messenger': content = <Messenger currentUser={user} initialUserId={navData} />; break;
      default: content = <div className="p-10 text-center text-slate-500 font-bold">پایانه یافت نشد.</div>;
    }
    return <PageTransition key={currentView}>{content}</PageTransition>;
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center">
           <School size={48} className="text-primary-500 animate-bounce mb-4" />
           <h2 className="text-lg font-black text-slate-800 font-sans">در حال اتصال به هسته مرکزی...</h2>
      </div>
    );
  }

  return (
    <Layout user={user} onLogout={handleLogout} currentView={currentView} onNavigate={handleNavigation} devModeActive={devModeActive} superModeActive={superModeActive}>
      {!user ? (
        <>
          {currentView === 'forgot_password' 
            ? <ForgotPasswordPage onBack={() => setCurrentView('')} /> 
            : <LoginPage onLogin={handleLogin} onForgotPassword={() => setCurrentView('forgot_password')} />}
          
          <AnimatePresence>
            {showStrategicLogin && (
               <Modal isOpen={showStrategicLogin} onClose={() => setShowStrategicLogin(false)} title="درگاه دسترسی استراتژیک سازمان" maxWidth="max-w-md">
                  <div className="p-8 space-y-8 bg-slate-950 text-white rounded-b-[2rem] text-right">
                     <div className="flex flex-col items-center text-center gap-4">
                        <div className="w-20 h-20 bg-amber-500/10 rounded-3xl flex items-center justify-center text-amber-500 border border-amber-500/30 shadow-[0_0_40px_rgba(245,158,11,0.2)]">
                           <ShieldAlert size={48} className="animate-pulse" />
                        </div>
                        <h3 className="text-2xl font-black uppercase tracking-tighter">ورود به هسته مرکزی</h3>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em]">فقط پرسنل مجاز و دارای تاییدیه سطح ۱</p>
                     </div>
                     <form onSubmit={handleStrategicLogin} className="space-y-6">
                        <div className="space-y-4">
                           <div className="space-y-1">
                              <label className="text-[9px] font-black text-slate-500 uppercase mr-4">کلید دسترسی</label>
                              <input type="text" className="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-amber-500 text-center font-mono tracking-widest text-white" value={strategicUser} onChange={e => setStrategicUser(e.target.value)} placeholder="ROOT_ID" />
                           </div>
                           <div className="space-y-1">
                              <label className="text-[9px] font-black text-slate-500 uppercase mr-4">توکن امنیتی</label>
                              <input type="password" className="w-full p-4 bg-white/5 border border-white/10 rounded-2xl outline-none focus:border-amber-500 text-center font-mono tracking-widest text-white" value={strategicPass} onChange={e => setStrategicPass(e.target.value)} placeholder="••••••••" />
                           </div>
                        </div>
                        <button type="submit" className="w-full py-5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-2xl shadow-[0_0_30px_rgba(245,158,11,0.3)] transition-all flex items-center justify-center gap-3">
                           <ShieldCheck size={20} /> تایید امضا و ورود
                        </button>
                     </form>
                  </div>
               </Modal>
            )}
          </AnimatePresence>
        </>
      ) : (
        <AnimatePresence mode="wait">{renderContent()}</AnimatePresence>
      )}
    </Layout>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </ThemeProvider>
  );
};

export default App;
