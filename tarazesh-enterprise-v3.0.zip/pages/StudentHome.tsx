
import React, { useMemo } from 'react';
import { User, UserRole } from '../types';
import { storageService } from '../services/storageService';
import { 
  Trophy, Target, Medal, Zap, ChevronLeft, Sparkles, Activity, Timer, ArrowLeft, FileText
} from 'lucide-react';
import { motion } from 'framer-motion';
import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';

interface StudentHomeProps {
  currentUser: User;
  onNavigate: (view: string, data?: any) => void;
}

const StudentHome: React.FC<StudentHomeProps> = ({ currentUser, onNavigate }) => {
  const exams = storageService.getExams();
  const assignments = storageService.getAssignments();
  const allUsers = storageService.getUsers();
  const results = storageService.getResults().filter(r => r.studentId === currentUser.id);
  
  const activeExams = useMemo(() => {
    const takenExamIds = new Set(results.map(r => r.examId));
    return exams.filter(e => e.status === 'active' && !takenExamIds.has(e.id));
  }, [exams, results]);

  const pendingAssignments = assignments.filter(asg => {
    const sub = storageService.getSubmissions().find(s => s.assignmentId === asg.id && s.studentId === currentUser.id);
    return !sub;
  });

  const recentResults = useMemo(() => {
    return [...results]
      .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime())
      .slice(0, 3);
  }, [results]);

  const classLeaderboard = useMemo(() => {
    return allUsers
      .filter(u => u.role === UserRole.STUDENT && u.class === currentUser.class)
      .sort((a, b) => (b.gamification?.xp || 0) - (a.gamification?.xp || 0))
      .slice(0, 5);
  }, [allUsers, currentUser.class]);

  const chartData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toLocaleDateString('fa-IR', { weekday: 'narrow' });
    });

    return last7Days.map((day, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      const dateStr = date.toISOString().split('T')[0];
      const dayXP = results
        .filter(r => r.submittedAt.split('T')[0] === dateStr)
        .reduce((sum, r) => sum + (r.earnedXp || 0), 0);
      return { day, xp: dayXP || (i * 100) }; 
    });
  }, [results]);

  const avgScore = useMemo(() => {
    if (results.length === 0) return '0.0';
    const sum = results.reduce((acc, r) => acc + (r.score / r.maxScore * 20), 0);
    return (sum / results.length).toFixed(1);
  }, [results]);

  const userRank = useMemo(() => {
    const sameClass = allUsers.filter(u => u.role === UserRole.STUDENT && u.class === currentUser.class);
    const sorted = sameClass.sort((a, b) => (b.gamification?.xp || 0) - (a.gamification?.xp || 0));
    return sorted.findIndex(u => u.id === currentUser.id) + 1;
  }, [allUsers, currentUser]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 pb-12">
      <div className="grid grid-cols-1 gap-6">
           <div className="relative overflow-hidden bg-slate-900 rounded-[2.5rem] p-10 text-white shadow-2xl">
              <div className="absolute top-0 right-0 w-full h-full opacity-5 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
              
              <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
                 <div className="flex-1 text-center md:text-right">
                    <div className="flex items-center gap-2 justify-center md:justify-start mb-2">
                       <Sparkles className="text-amber-400" size={24} />
                       <h1 className="text-3xl font-black tracking-tight">سلام {currentUser.name.split(' ')[0]} عزیز!</h1>
                    </div>
                    <p className="text-slate-400 font-bold mb-8">شما {activeExams.length} آزمون جدید و {pendingAssignments.length} تکلیف معلق دارید.</p>
                    
                    <div className="grid grid-cols-3 gap-4 max-w-2xl">
                       {[
                         { label: 'رتبه کلاس', val: `#${userRank || '-'}`, icon: Trophy, color: 'text-amber-400' },
                         { label: 'معدل کل', val: avgScore, icon: Target, color: 'text-emerald-400' },
                         { label: 'نشان‌ها', val: currentUser.gamification?.badges.length || 0, icon: Medal, color: 'text-indigo-400' }
                       ].map((stat, i) => (
                         <div key={i} className="bg-white/5 backdrop-blur-md p-4 rounded-3xl border border-white/5 text-center">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">{stat.label}</p>
                            <p className="text-xl font-black">{stat.val}</p>
                         </div>
                       ))}
                    </div>
                 </div>

                 <div className="w-full md:w-72 bg-white/5 backdrop-blur-xl rounded-[2rem] border border-white/10 p-6">
                    <div className="flex justify-between items-center mb-4">
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">تراکم فعالیت</span>
                       <span className="text-[11px] font-black text-primary-400">Level {currentUser.gamification?.level}</span>
                    </div>
                    <div className="h-28">
                       <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={chartData}>
                             <Area type="monotone" dataKey="xp" stroke="#38bdf8" fillOpacity={0.3} fill="#0ea5e9" strokeWidth={3} isAnimationActive={false} />
                          </AreaChart>
                       </ResponsiveContainer>
                    </div>
                    <p className="text-center mt-3 text-sm font-black text-slate-200">{currentUser.gamification?.xp.toLocaleString()} <span className="opacity-50 text-[10px] font-bold">XP TOTAL</span></p>
                 </div>
              </div>
           </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
         <div className="lg:col-span-8 space-y-6">
            <section className="space-y-4">
               <div className="flex justify-between items-center px-4">
                  <h3 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-2 tracking-tight">
                     <Timer size={22} className="text-rose-500" /> آزمون‌های پیش‌رو
                  </h3>
                  <button onClick={() => onNavigate('student_exams')} className="text-[10px] font-black text-primary-600 flex items-center gap-1 hover:underline">مشاهده همه <ArrowLeft size={14}/></button>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activeExams.length === 0 ? (
                    <div className="col-span-full p-10 text-center bg-white dark:bg-slate-900 rounded-3xl border-2 border-dashed border-slate-100 dark:border-slate-800 text-slate-400 font-bold">آزمون فعالی یافت نشد.</div>
                  ) : activeExams.slice(0, 2).map(exam => (
                     <div key={exam.id} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group cursor-pointer" onClick={() => onNavigate('student_exams')}>
                        <div className="flex justify-between items-start mb-6">
                           <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-all">
                              <Zap size={24}/>
                           </div>
                           <span className="text-[9px] font-black bg-rose-50 text-rose-600 px-3 py-1 rounded-full uppercase tracking-tighter">{exam.durationMinutes} MIN</span>
                        </div>
                        <h4 className="text-base font-black text-slate-800 dark:text-white mb-8 truncate">{exam.title}</h4>
                        <button className="w-full py-3.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-[10px] uppercase shadow-lg transition-all group-hover:bg-primary-600 group-hover:text-white">ورود به جلسه</button>
                     </div>
                  ))}
               </div>
            </section>
         </div>

         <div className="lg:col-span-4 space-y-6">
            <section className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
               <h3 className="text-sm font-black text-slate-800 dark:text-white mb-8 flex items-center gap-2">
                  <Activity size={18} className="text-emerald-500" /> مانیتورینگ فعالیت
               </h3>
               <div className="space-y-5">
                  {recentResults.length === 0 ? (
                    <p className="text-xs text-slate-400 italic">فعالیتی ثبت نشده است.</p>
                  ) : recentResults.map((res, i) => {
                     const exam = exams.find(e => e.id === res.examId);
                     return (
                        <div key={i} className="flex gap-4 group cursor-pointer border-b border-slate-50 dark:border-slate-800 pb-5 last:border-0 last:pb-0" onClick={() => onNavigate('student_results')}>
                           <div className={`w-2 h-2 rounded-full mt-2 shrink-0 ${res.status === 'passed' ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                           <div className="flex-1 min-w-0">
                              <h5 className="text-xs font-black text-slate-800 dark:text-white truncate group-hover:text-primary-600 transition-colors">{exam?.title}</h5>
                              <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase">SCORE: {res.score} <span className="opacity-40">/ {res.maxScore}</span></p>
                           </div>
                        </div>
                     )
                  })}
               </div>
            </section>
         </div>
      </div>
    </motion.div>
  );
};

export default StudentHome;
