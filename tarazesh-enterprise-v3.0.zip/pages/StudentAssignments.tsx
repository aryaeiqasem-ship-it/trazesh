import React, { useState, useEffect, useRef, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { gamificationService } from '../services/gamificationService';
import { Assignment, AssignmentSubmission } from '../types';
import { 
  FileText, Clock, Upload, CheckCircle, AlertCircle, Calendar, 
  Download, File, X, Loader2, Paperclip, Award, ArrowUpDown,
  ListFilter, ChevronDown, Timer, AlertTriangle, MessageSquare, Mic
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import Modal from '../components/Modal';
import VoiceRecorder from '../components/VoiceRecorder';

type SortOption = 'date_asc' | 'date_desc' | 'status_pending' | 'status_done' | 'graded_first';

const ScoreRing: React.FC<{ score: number, max: number, size?: number, stroke?: number }> = ({ score, max, size = 100, stroke = 8 }) => {
  const percentage = Math.min(Math.max((score / (max || 1)) * 100, 0), 100);
  const radius = (size - stroke) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  const getColor = () => {
    const ratio = score / (max || 1);
    if (ratio >= 0.85) return '#10b981';
    if (ratio >= 0.5) return '#0ea5e9';
    return '#f43f5e';
  };

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={stroke}
          fill="transparent"
          className="text-slate-100 dark:text-slate-800"
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={getColor()}
          strokeWidth={stroke}
          fill="transparent"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-black text-slate-900 dark:text-white leading-none">{score}</span>
        <span className="text-[8px] font-black text-slate-400 uppercase tracking-tighter mt-0.5">از {max}</span>
      </div>
    </div>
  );
};

const StudentAssignments: React.FC = () => {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>([]);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [responseText, setResponseText] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [fileDetails, setFileDetails] = useState<{name: string, size: string} | null>(null);
  const [voiceBase64, setVoiceBase64] = useState<string | null>(null);
  const [sortOption, setSortOption] = useState<SortOption>('date_asc');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const toast = useToast();

  const studentId = '3'; 

  useEffect(() => {
    setAssignments(storageService.getAssignments());
    setSubmissions(storageService.getSubmissions());
  }, []);

  const getSubmission = (assignmentId: string) => {
    return submissions.find(s => s.assignmentId === assignmentId && s.studentId === studentId);
  };

  const sortedAssignments = useMemo(() => {
    const list = [...assignments];
    return list.sort((a, b) => {
      const subA = getSubmission(a.id);
      const subB = getSubmission(b.id);
      const isDoneA = !!subA;
      const isDoneB = !!subB;
      const isGradedA = subA?.status === 'graded';
      const isGradedB = subB?.status === 'graded';

      switch (sortOption) {
        case 'date_asc': return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        case 'date_desc': return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
        case 'status_pending': return isDoneA === isDoneB ? 0 : (isDoneA ? 1 : -1);
        case 'status_done': return isDoneA === isDoneB ? 0 : (isDoneA ? -1 : 1);
        case 'graded_first': return isGradedA === isGradedB ? 0 : (isGradedA ? -1 : 1);
        default: return 0;
      }
    });
  }, [assignments, submissions, sortOption]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
      if (parseFloat(sizeMB) > 10) {
        toast.error('حجم فایل نباید بیشتر از ۱۰ مگابایت باشد.');
        return;
      }
      setAttachedFile(file);
      setFileDetails({ name: file.name, size: `${sizeMB} MB` });
    }
  };

  const handleVoiceComplete = (blob: Blob, base64: string) => {
    setVoiceBase64(base64);
    toast.success("صدا با موفقیت ضبط شد.");
  };

  const handleSubmit = async () => {
    if (!selectedAssignment) return;
    setUploading(true);
    setUploadProgress(10);
    
    try {
        let finalFileUrl = undefined;
        if (attachedFile) {
            const uploadRes = await storageService.uploadFile(attachedFile);
            finalFileUrl = uploadRes.url;
        }

        const newSubmission: AssignmentSubmission = {
          id: `sub_${Date.now()}`,
          assignmentId: selectedAssignment.id,
          studentId: studentId,
          submittedAt: new Date().toISOString(),
          textResponse: responseText,
          fileUrl: finalFileUrl,
          status: 'pending'
        };
        
        // In a real app, we'd also send voiceBase64 to the server
        const newSubmissions = [...submissions.filter(s => s.assignmentId !== selectedAssignment.id), newSubmission];
        storageService.saveSubmissions(newSubmissions);
        setSubmissions(newSubmissions);
        
        setUploadProgress(100);
        gamificationService.awardXP(studentId, 25, `ارسال تکلیف: ${selectedAssignment.title}`);
        toast.success(`تکلیف با موفقیت ارسال شد.`);

        setTimeout(() => {
            setUploading(false);
            setSelectedAssignment(null);
            setResponseText('');
            setAttachedFile(null);
            setFileDetails(null);
            setVoiceBase64(null);
        }, 500);

    } catch (err) {
        toast.error('خطا در ارسال. لطفا مجدد تلاش کنید.');
        setUploading(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
         <div>
            <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-3">
               <FileText className="text-primary-600" /> تکالیف درسی
            </h1>
            <p className="text-sm text-slate-500 font-bold mt-1">مدیریت و ارسال پاسخ به تکالیف محول شده</p>
         </div>
         <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
               <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 rounded-2xl border border-slate-100 dark:border-slate-800">
                  <ListFilter size={16} className="text-slate-400" />
                  <select 
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value as SortOption)}
                    className="bg-transparent text-xs font-black text-slate-600 dark:text-slate-300 outline-none appearance-none cursor-pointer pr-6"
                  >
                    <option value="date_asc">تاریخ (نزدیک‌ترین)</option>
                    <option value="date_desc">تاریخ (دورترین)</option>
                    <option value="status_pending">انجام نشده‌ها اول</option>
                  </select>
                  <ChevronDown size={14} className="absolute left-3 top-3.5 text-slate-400 pointer-events-none" />
               </div>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {sortedAssignments.map(assignment => {
            const submission = getSubmission(assignment.id);
            const isDone = !!submission;
            const isOverdue = !isDone && new Date() > new Date(assignment.dueDate);
            const isGraded = submission?.status === 'graded';
            
            const state = isGraded ? { accent: 'bg-emerald-500', label: 'تصحیح شده' } :
                          isOverdue ? { accent: 'bg-rose-500', label: 'منقضی شده' } :
                          isDone ? { accent: 'bg-indigo-500', label: 'در صف تصحیح' } :
                          { accent: 'bg-amber-400', label: 'در حال انجام' };

            return (
              <motion.div 
                key={assignment.id} layout initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                className={`bg-white dark:bg-slate-900 rounded-[2.5rem] border p-6 flex flex-col shadow-sm transition-all hover:shadow-xl relative overflow-hidden`}
              >
                <div className={`absolute top-0 right-0 left-0 h-1.5 ${state.accent}`} />
                <div className="flex justify-between items-start mb-4 pt-2">
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800"><FileText className="text-slate-400" /></div>
                  <span className={`text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-widest text-white ${state.accent}`}>{state.label}</span>
                </div>
                <h3 className="font-black text-lg text-slate-800 dark:text-slate-100 mb-2">{assignment.title}</h3>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-6">{assignment.description}</p>
                <div className="mt-auto space-y-4">
                  <div className="flex items-center justify-between text-[10px] font-black uppercase">
                    <span className="flex items-center gap-1.5"><Calendar size={14}/> مهلت:</span>
                    <span className="text-slate-700 dark:text-slate-300">{new Date(assignment.dueDate).toLocaleDateString('fa-IR')}</span>
                  </div>
                  <button onClick={() => setSelectedAssignment(assignment)} className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-xs uppercase shadow-lg">مشاهده و ارسال</button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      <Modal isOpen={!!selectedAssignment} onClose={() => !uploading && setSelectedAssignment(null)} title="جزئیات و ارسال تکلیف">
        <div className="p-8 space-y-6">
           {selectedAssignment && (
             <>
               <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-[2rem] border">
                 <h3 className="font-black text-lg mb-2">{selectedAssignment.title}</h3>
                 <p className="text-xs font-bold leading-relaxed">{selectedAssignment.description}</p>
               </div>

               {getSubmission(selectedAssignment.id) ? (
                 <div className="p-6 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 flex items-center gap-4">
                    <CheckCircle className="text-emerald-500" size={32} />
                    <p className="text-sm font-black">پاسخ شما با موفقیت ثبت شده و در انتظار تصحیح مدرس می‌باشد.</p>
                 </div>
               ) : (
                 <div className="space-y-6">
                   <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">متن پاسخ</label>
                     <textarea 
                       rows={4} className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 dark:text-white"
                       placeholder="پاسخ خود را بنویسید..." value={responseText} onChange={(e) => setResponseText(e.target.value)} disabled={uploading}
                     />
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">پاسخ صوتی</label>
                        <VoiceRecorder onRecordingComplete={handleVoiceComplete} onClear={() => setVoiceBase64(null)} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">پیوست فایل</label>
                        <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center cursor-pointer hover:border-primary-500 transition-all group">
                           {fileDetails ? (
                             <div className="flex flex-col items-center gap-1">
                               <p className="text-[10px] font-black truncate max-w-[150px]">{fileDetails.name}</p>
                               <button onClick={(e) => {e.stopPropagation(); setAttachedFile(null); setFileDetails(null);}} className="text-[10px] text-rose-500 font-bold">حذف فایل</button>
                             </div>
                           ) : (
                             <>
                               <Upload className="mx-auto text-slate-300 group-hover:text-primary-500 transition-colors mb-2" size={24} />
                               <p className="text-[9px] font-black text-slate-400">انتخاب فایل</p>
                             </>
                           )}
                           <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} />
                        </div>
                      </div>
                   </div>

                   {uploading && (
                      <div className="space-y-2">
                         <div className="flex justify-between text-[10px] font-black text-primary-600">
                            <span>در حال ارسال...</span>
                            <span>{uploadProgress}%</span>
                         </div>
                         <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${uploadProgress}%` }} className="h-full bg-primary-600" />
                         </div>
                      </div>
                   )}
                 </div>
               )}
             </>
           )}
        </div>
        {!getSubmission(selectedAssignment?.id || '') && (
          <div className="p-8 border-t flex justify-end gap-3 bg-slate-50 dark:bg-slate-800/50">
             <button onClick={() => setSelectedAssignment(null)} disabled={uploading} className="px-8 py-3 text-slate-400 font-black">انصراف</button>
             <button onClick={handleSubmit} disabled={uploading || (!responseText && !attachedFile && !voiceBase64)} className="px-12 py-3 bg-primary-600 text-white rounded-2xl font-black shadow-xl shadow-primary-500/20 hover:bg-primary-700 transition-all flex items-center gap-2">
                {uploading ? 'ارسال...' : 'ارسال نهایی پاسخ'}
             </button>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default StudentAssignments;