
import React, { useState, useRef } from 'react';
import { User, UserRole } from '../types';
import { storageService } from '../services/storageService';
import { 
  User as UserIcon, Camera, Save, Shield, KeyRound, 
  Mail, Smartphone, ShieldCheck, Lock, Settings as SettingsIcon,
  HelpCircle, ChevronLeft, Bell, Monitor
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import { compressImage } from '../utils/imageUtils';

interface TeacherSettingsProps {
  currentUser: User;
  onRefreshUser?: () => void;
}

const TeacherSettings: React.FC<TeacherSettingsProps> = ({ currentUser, onRefreshUser }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'preferences'>('profile');
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [profileData, setProfileData] = useState({
    email: currentUser.email || '',
    phoneNumber: currentUser.phoneNumber || '',
    avatar: currentUser.avatar || ''
  });

  const handleProfileSave = async () => {
    setLoading(true);
    try {
      const updatedUser: User = { ...currentUser, ...profileData };
      const allUsers = storageService.getUsers();
      const newUsersList = allUsers.map(u => u.id === currentUser.id ? updatedUser : u);
      storageService.saveUsers(newUsersList);
      
      localStorage.setItem('current_user', JSON.stringify(updatedUser));
      if (onRefreshUser) onRefreshUser();
      
      toast.success('مشخصات فردی شما با موفقیت بروزرسانی شد.');
    } catch (err) {
      toast.error('خطا در ذخیره‌سازی اطلاعات.');
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const compressed = await compressImage(file, 400, 0.8);
      setProfileData(prev => ({ ...prev, avatar: compressed }));
      toast.info('تصویر آماده ذخیره‌سازی است.');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-3">
            <SettingsIcon className="text-primary-600" size={32} />
            تنظیمات پنل مدرس
          </h1>
          <p className="text-sm text-slate-500 font-bold mt-1">مدیریت هویت بصری و امنیت حساب کاربری کادر آموزشی</p>
        </div>
      </div>

      <div className="flex gap-2 p-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 w-fit">
         <button onClick={() => setActiveTab('profile')} className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-sm transition-all ${activeTab === 'profile' ? 'bg-primary-600 text-white shadow-xl' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
            <UserIcon size={18} /> مشخصات فردی
         </button>
         <button onClick={() => setActiveTab('security')} className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-sm transition-all ${activeTab === 'security' ? 'bg-rose-600 text-white shadow-xl' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
            <Shield size={18} /> امنیت حساب
         </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'profile' && (
          <motion.div key="profile" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-10">
             <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                   <div className="w-32 h-32 rounded-[2.5rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-4xl text-slate-400 overflow-hidden border-4 border-white shadow-2xl">
                      {profileData.avatar ? <img src={profileData.avatar} className="w-full h-full object-cover" /> : currentUser.name.charAt(0)}
                   </div>
                   <div className="absolute inset-0 bg-black/40 rounded-[2.5rem] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                      <Camera className="text-white" size={32} />
                   </div>
                   <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarUpload} />
                </div>
                <div className="text-center md:text-right flex-1">
                   <h2 className="text-2xl font-black text-slate-800 dark:text-white">{currentUser.name}</h2>
                   <p className="text-slate-400 font-bold mt-1">مدرس رسمی سامانه | کد پرسنلی: {currentUser.username}</p>
                   <div className="mt-4 p-4 bg-primary-50 dark:bg-primary-900/20 rounded-2xl border border-primary-100 dark:border-primary-800 flex items-center gap-3">
                      <ShieldCheck className="text-primary-600" size={24} />
                      <p className="text-xs text-primary-700 dark:text-primary-300 font-bold">حساب کاربری شما توسط واحد فناوری تایید شده است.</p>
                   </div>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-50 dark:border-slate-800">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">ایمیل سازمانی</label>
                   <div className="relative">
                      <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-primary-500 dir-ltr text-left text-black" value={profileData.email} onChange={e => setProfileData({...profileData, email: e.target.value})} placeholder="example@email.com" />
                      <Mail className="absolute left-4 top-4 text-slate-300" size={20} />
                   </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mr-2">شماره تماس (بازیابی)</label>
                   <div className="relative">
                      <input className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-primary-500 dir-ltr text-left text-black" value={profileData.phoneNumber} onChange={e => setProfileData({...profileData, phoneNumber: e.target.value})} placeholder="0912..." />
                      <Smartphone className="absolute left-4 top-4 text-slate-300" size={20} />
                   </div>
                </div>
             </div>

             <div className="flex justify-end pt-4">
                <button onClick={handleProfileSave} disabled={loading} className="bg-primary-600 hover:bg-primary-700 text-white px-10 py-4 rounded-2xl font-black shadow-2xl transition-all flex items-center gap-2">
                   <Save size={20} /> ذخیره تغییرات نهایی
                </button>
             </div>
          </motion.div>
        )}

        {activeTab === 'security' && (
          <motion.div key="sec" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-10">
             <div className="bg-rose-50 dark:bg-rose-900/10 p-6 rounded-3xl flex items-start gap-4 border border-rose-100 dark:border-rose-900/30">
                <Lock className="text-rose-500 shrink-0" size={24} />
                <div>
                   <h3 className="font-black text-rose-900 dark:text-rose-200">تغییر کلمه عبور</h3>
                   <p className="text-xs text-rose-700/70 font-bold leading-relaxed mt-1">رمز عبور جدید باید ترکیبی از حروف بزرگ، کوچک و اعداد باشد.</p>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 block mr-2">رمز فعلی</label>
                   <input type="password" placeholder="••••••••" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500 text-black" />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 block mr-2">رمز جدید</label>
                   <input type="password" placeholder="••••••••" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500 text-black" />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 block mr-2">تکرار رمز جدید</label>
                   <input type="password" placeholder="••••••••" className="w-full p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500 text-black" />
                </div>
             </div>

             <button className="bg-rose-600 text-white px-10 py-4 rounded-2xl font-black shadow-xl">بروزرسانی کلمه عبور</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default TeacherSettings;
