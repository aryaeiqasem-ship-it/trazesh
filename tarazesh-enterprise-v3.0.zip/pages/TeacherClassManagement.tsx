
import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storageService';
import { User, ClassEntity, UserRole, AttendanceRecord, Course } from '../types';
import { 
  Check, X, Clock, Calendar, Save, Shuffle, Grid, List, 
  ThumbsUp, ThumbsDown, Users, Search, Activity, Zap, History, 
  ChevronLeft, ChevronDown, BookOpen, UserCheck, AlertCircle,
  BarChart3, LayoutPanelLeft, MoreVertical, Star, CalendarDays,
  Target, Info, ArrowUpRight, GraduationCap
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import Modal from '../components/Modal';
import confetti from 'canvas-confetti';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

const TeacherClassManagement: React.FC = () => {
  const [classes, setClasses] = useState<ClassEntity[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [availableCourses, setAvailableCourses] = useState<Course[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [students, setStudents] = useState<User[]>([]);
  const [attendanceDate, setAttendanceDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [searchTerm, setSearchTerm] = useState('');
  
  const [attendanceStatus, setAttendanceStatus] = useState<Record<string, 'present' | 'absent' | 'late'>>({});
  const [participationScore, setParticipationScore] = useState<Record<string, number>>({});
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [pickedStudent, setPickedStudent] = useState<User | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);

  const toast = useToast();

  useEffect(() => {
    setClasses(storageService.getClasses());
  }, []);

  useEffect(() => {
    if (selectedClassId) {
      const cls = classes.find(c => c.id === selectedClassId);
      const allCourses = storageService.getCourses();
      
      if (cls) {
        setAvailableCourses(allCourses.filter(c => cls.courseIds.includes(c.id)));
      }

      const classStudents = storageService.getUsers().filter(u => u.role === UserRole.STUDENT && u.class === cls?.title);
      setStudents(classStudents);
      
      const initialStatus: Record<string, 'present' | 'absent' | 'late'> = {};
      const initialScores: Record<string, number> = {};
      classStudents.forEach(s => {
        initialStatus[s.id] = 'present';
        initialScores[s.id] = 0;
      });
      setAttendanceStatus(initialStatus);
      setParticipationScore(initialScores);
    }
  }, [selectedClassId, classes]);

  const filteredStudents = useMemo(() => {
    return students.filter(s => s.name.includes(searchTerm) || s.studentId?.includes(searchTerm));
  }, [students, searchTerm]);

  const stats = useMemo(() => {
    const total = students.length;
    if (total === 0) return { present: 0, late: 0, absent: 0, percent: 0, avgScore: 0 };
    const presentCount = Object.values(attendanceStatus).filter(s => s === 'present').length;
    const lateCount = Object.values(attendanceStatus).filter(s => s === 'late').length;
    const absentCount = Object.values(attendanceStatus).filter(s => s === 'absent').length;
    const totalScore = (Object.values(participationScore) as number[]).reduce((a, b) => a + b, 0);
    return { present: presentCount, late: lateCount, absent: absentCount, percent: Math.round(((presentCount + lateCount) / total) * 100), avgScore: parseFloat((totalScore / total).toFixed(1)) };
  }, [attendanceStatus, students, participationScore]);

  const historyRecords = useMemo(() => {
    if (!selectedClassId) return [];
    return storageService.getAttendance().filter(r => r.classId === selectedClassId);
  }, [selectedClassId, isHistoryModalOpen]);

  const chartData = [
    { name: 'حاضر', value: stats.present, color: '#10b981' },
    { name: 'تاخیر', value: stats.late, color: '#f59e0b' },
    { name: 'غایب', value: stats.absent, color: '#f43f5e' },
  ];

  const handleStatusChange = (id: string, status: 'present' | 'absent' | 'late') => {
    setAttendanceStatus(prev => ({ ...prev, [id]: status }));
  };

  const handleScoreChange = (id: string, delta: number) => {
    setParticipationScore(prev => ({ ...prev, [id]: (prev[id] || 0) + delta }));
    if (delta > 0) toast.success('امتیاز مثبت ثبت شد');
  };

  const startRandomPicker = () => {
    const activeOnes = students.filter(s => attendanceStatus[s.id] !== 'absent');
    if (activeOnes.length === 0) return toast.error('هیچ هنرجوی حاضری برای انتخاب وجود ندارد.');
    
    setIsPickerOpen(true);
    setIsSpinning(true);
    setPickedStudent(null);

    let count = 0;
    const interval = setInterval(() => {
      setPickedStudent(activeOnes[Math.floor(Math.random() * activeOnes.length)]);
      count++;
      if (count > 20) {
        clearInterval(interval);
        setIsSpinning(false);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      }
    }, 100);
  };

  const saveAll = () => {
    if (!selectedClassId || !selectedCourseId) return toast.error('انتخاب کلاس و درس الزامی است.');
    const record: AttendanceRecord = {
      id: `att_${Date.now()}`,
      classId: selectedClassId,
      courseId: selectedCourseId,
      date: attendanceDate,
      presentStudentIds: students.filter(s => attendanceStatus[s.id] === 'present').map(s => s.id),
      absentStudentIds: students.filter(s => attendanceStatus[s.id] === 'absent').map(s => s.id),
      lateStudentIds: students.filter(s => attendanceStatus[s.id] === 'late').map(s => s.id),
    };
    storageService.saveAttendance([...storageService.getAttendance(), record]);
    toast.success('گزارش جلسه با موفقیت در هسته مرکزی ثبت شد.');
  };

  return (
    <div className="space-y-8 pb-40 font-sans" dir="rtl">
      {/* Strategic Header */}
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col lg:flex-row justify-between items-center gap-10 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-l from-primary-500 to-indigo-500 opacity-50"></div>
        <div className="flex flex-col md:flex-row items-center gap-6 flex-1 w-full text-right z-10">
           <div className="w-20 h-20 bg-primary-600 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-primary-500/30 shrink-0 transform -rotate-3 hover:rotate-0 transition-transform">
              <UserCheck size={40} />
           </div>
           <div className="flex-1 space-y-4 w-full">
              <div>
                 <h1 className="text-3xl font-black text-slate-950 dark:text-white tracking-tight">مرکز پایش و حضور و غیاب</h1>
                 <p className="text-sm text-slate-500 font-bold mt-1">مدیریت لحظه‌ای گره‌های آموزشی و مشارکت کلاسی</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="relative group">
                    <select className="w-full p-4 pr-12 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white appearance-none" value={selectedClassId} onChange={e => setSelectedClassId(e.target.value)}>
                       <option value="">انتخاب واحد آموزشی (کلاس)...</option>
                       {classes.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                    </select>
                    <Users className="absolute right-4 top-4 text-slate-400 group-focus-within:text-primary-500" size={20} />
                    <ChevronDown className="absolute left-4 top-4.5 text-slate-400 pointer-events-none" size={16} />
                  </div>
                  <div className="relative group">
                    <select className="w-full p-4 pr-12 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl font-black text-sm outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white appearance-none" value={selectedCourseId} onChange={e => setSelectedCourseId(e.target.value)}>
                       <option value="">تخصیص واحد درسی...</option>
                       {availableCourses.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                    </select>
                    <BookOpen className="absolute right-4 top-4 text-slate-400 group-focus-within:text-primary-500" size={20} />
                    <ChevronDown className="absolute left-4 top-4.5 text-slate-400 pointer-events-none" size={16} />
                  </div>
              </div>
           </div>
        </div>
        
        <div className="flex items-center gap-8 bg-slate-50 dark:bg-white/5 p-8 rounded-[3rem] border border-slate-100 dark:border-white/5 shrink-0 z-10">
            <div className="w-24 h-24 relative">
               <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={chartData} innerRadius={25} outerRadius={42} paddingAngle={2} dataKey="value" stroke="none">
                        {chartData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                    </Pie>
                  </PieChart>
               </ResponsiveContainer>
               <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-black text-slate-400">{stats.percent}%</span>
               </div>
            </div>
            <div className="space-y-4">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 rounded-xl flex items-center justify-center shadow-inner"><Activity size={20}/></div>
                   <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">تراکم حضور</p>
                      <p className="text-xl font-black text-slate-800 dark:text-white">{stats.percent}%</p>
                   </div>
                </div>
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900/20 text-amber-600 rounded-xl flex items-center justify-center shadow-inner"><Star size={20}/></div>
                   <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">میانگین امتیاز</p>
                      <p className="text-xl font-black text-slate-800 dark:text-white">{stats.avgScore}</p>
                   </div>
                </div>
            </div>
        </div>
      </div>

      {/* Tools & Search */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row gap-6 items-center">
         <div className="relative flex-1 w-full group">
            <input 
              type="text" 
              placeholder="جستجوی سریع در لیست هنرجویان..." 
              className="w-full pr-14 pl-4 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-sm text-slate-900 dark:text-white focus:ring-4 focus:ring-primary-500/10 transition-all shadow-inner" 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
            />
            <Search className="absolute right-5 top-4.5 text-slate-400 group-focus-within:text-primary-500" size={24} />
         </div>
         
         <div className="flex gap-3">
            <button onClick={() => setIsHistoryModalOpen(true)} className="p-4 bg-slate-50 dark:bg-slate-800 text-slate-500 hover:text-indigo-600 rounded-2xl transition-all border border-slate-100 dark:border-slate-700 shadow-sm" title="تاریخچه حضور و غیاب"><History size={24}/></button>
            <button onClick={startRandomPicker} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase flex items-center gap-3 shadow-xl shadow-indigo-500/20 hover:scale-105 active:scale-95 transition-all">
               <Shuffle size={20}/> پرسش تصادفی
            </button>
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
               <button onClick={() => setViewMode('grid')} className={`p-3 rounded-xl transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-slate-700 shadow-md text-primary-600' : 'text-slate-400'}`}><Grid size={20}/></button>
               <button onClick={() => setViewMode('list')} className={`p-3 rounded-xl transition-all ${viewMode === 'list' ? 'bg-white dark:bg-slate-700 shadow-md text-primary-600' : 'text-slate-400'}`}><List size={20}/></button>
            </div>
         </div>
      </div>

      <div className="min-h-[400px]">
        {!selectedClassId ? (
           <div className="py-40 text-center bg-white dark:bg-slate-900 rounded-[4rem] border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center">
              <LayoutPanelLeft size={80} className="text-slate-100 dark:text-slate-800 mb-6" />
              <p className="text-slate-400 font-black text-2xl tracking-tight">ابتدا کلاس مورد نظر را انتخاب کنید.</p>
           </div>
        ) : filteredStudents.length === 0 ? (
           <div className="py-20 text-center text-slate-400 font-bold italic">هنرجویی با این مشخصات یافت نشد.</div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            <AnimatePresence>
               {filteredStudents.map(student => {
                  const status = attendanceStatus[student.id];
                  return (
                    <motion.div 
                      layout initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                      key={student.id}
                      className={`bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border-2 transition-all group relative overflow-hidden flex flex-col h-full ${
                        status === 'present' ? 'border-emerald-500 shadow-[0_20px_40px_rgba(16,185,129,0.1)]' : 
                        status === 'late' ? 'border-amber-500 shadow-[0_20px_40px_rgba(245,158,11,0.1)]' : 
                        'border-slate-100 dark:border-slate-800 shadow-sm opacity-60 grayscale-[0.5]'
                      }`}
                    >
                      <div className="flex items-center gap-4 mb-6">
                        <div className="relative">
                           <div className="w-16 h-16 rounded-[1.5rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-2xl text-slate-300 overflow-hidden border-4 border-white dark:border-slate-800 shadow-xl group-hover:scale-110 transition-transform">
                              {student.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : student.name.charAt(0)}
                           </div>
                           <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-4 border-white dark:border-slate-900 flex items-center justify-center ${
                             status === 'present' ? 'bg-emerald-500' : status === 'late' ? 'bg-amber-500' : 'bg-rose-500'
                           }`}>
                              {status === 'present' ? <Check size={12} className="text-white"/> : status === 'late' ? <Clock size={12} className="text-white"/> : <X size={12} className="text-white"/>}
                           </div>
                        </div>
                        <div className="min-w-0 flex-1">
                           <h4 className="font-black text-[15px] text-slate-900 dark:text-white truncate">{student.name}</h4>
                           <p className="text-[10px] text-slate-400 font-mono font-bold uppercase mt-0.5">ID: {student.studentId}</p>
                        </div>
                        <div className="flex flex-col items-center">
                           <span className={`text-xl font-black ${participationScore[student.id] > 0 ? 'text-indigo-600' : 'text-slate-300'}`}>{participationScore[student.id]}</span>
                           <span className="text-[8px] font-black text-slate-400 uppercase">Score</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 dark:bg-white/5 rounded-2xl mb-6">
                        <button onClick={() => handleStatusChange(student.id, 'present')} className={`py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${status === 'present' ? 'bg-emerald-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}>حاضر</button>
                        <button onClick={() => handleStatusChange(student.id, 'late')} className={`py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${status === 'late' ? 'bg-amber-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}>تاخیر</button>
                        <button onClick={() => handleStatusChange(student.id, 'absent')} className={`py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${status === 'absent' ? 'bg-rose-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}>غایب</button>
                      </div>

                      <div className="mt-auto flex gap-2 pt-4 border-t border-slate-50 dark:border-white/5">
                        <button onClick={() => handleScoreChange(student.id, 1)} className="flex-1 py-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2 hover:bg-indigo-600 hover:text-white transition-all"><ThumbsUp size={14}/> مثبت</button>
                        <button onClick={() => handleScoreChange(student.id, -1)} className="p-3 bg-rose-50 dark:bg-rose-900/20 text-rose-500 rounded-xl hover:bg-rose-500 hover:text-white transition-all"><ThumbsDown size={16}/></button>
                      </div>
                    </motion.div>
                  );
               })}
            </AnimatePresence>
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-900 rounded-[3rem] border shadow-sm overflow-hidden">
            <table className="w-full text-right">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                  <th className="px-10 py-6">نام و اطلاعات هنرجو</th>
                  <th className="px-10 py-6 text-center">تغییر وضعیت نهایی</th>
                  <th className="px-10 py-6 text-center">ارزشیابی کلاسی</th>
                  <th className="px-10 py-6 text-center">تراز نمره</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filteredStudents.map(student => (
                  <tr key={student.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-10 py-5">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center font-black text-slate-500 overflow-hidden shadow-sm">{student.avatar ? <img src={student.avatar} className="w-full h-full object-cover" /> : student.name.charAt(0)}</div>
                          <span className="font-black text-[15px]">{student.name}</span>
                       </div>
                    </td>
                    <td className="px-10 py-5">
                      <div className="flex justify-center gap-2 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl w-fit mx-auto shadow-inner">
                        <button onClick={() => handleStatusChange(student.id, 'present')} className={`px-6 py-2 rounded-xl text-[10px] font-black transition-all ${attendanceStatus[student.id] === 'present' ? 'bg-emerald-500 text-white shadow-md' : 'text-slate-400'}`}>حاضر</button>
                        <button onClick={() => handleStatusChange(student.id, 'late')} className={`px-6 py-2 rounded-xl text-[10px] font-black transition-all ${attendanceStatus[student.id] === 'late' ? 'bg-amber-500 text-white shadow-md' : 'text-slate-400'}`}>تاخیر</button>
                        <button onClick={() => handleStatusChange(student.id, 'absent')} className={`px-6 py-2 rounded-xl text-[10px] font-black transition-all ${attendanceStatus[student.id] === 'absent' ? 'bg-rose-500 text-white shadow-md' : 'text-slate-400'}`}>غایب</button>
                      </div>
                    </td>
                    <td className="px-10 py-5">
                      <div className="flex items-center justify-center gap-4">
                        <button onClick={() => handleScoreChange(student.id, -1)} className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all border border-transparent hover:border-rose-100"><ThumbsDown size={18}/></button>
                        <button onClick={() => handleScoreChange(student.id, 1)} className="px-6 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-[10px] font-black flex items-center gap-2 hover:bg-indigo-600 hover:text-white transition-all"><ThumbsUp size={16}/> ثبت امتیاز</button>
                      </div>
                    </td>
                    <td className="px-10 py-5 text-center">
                       <span className="text-2xl font-black text-slate-700 dark:text-white tracking-tighter">{participationScore[student.id]}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Floating Action Bar */}
      <AnimatePresence>
        {selectedClassId && (
          <motion.div initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }} className="fixed bottom-10 right-10 left-10 md:right-80 z-40">
             <div className="max-w-4xl mx-auto bg-slate-950/90 backdrop-blur-xl p-6 rounded-[3rem] shadow-[0_30px_70px_rgba(0,0,0,0.5)] flex justify-between items-center text-white border border-white/10">
                <div className="flex gap-10 pr-6 items-center">
                    <div className="flex flex-col">
                       <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">مجموع هنرجویان</span>
                       <span className="text-xl font-black">{students.length} نفر</span>
                    </div>
                    <div className="flex gap-4">
                        <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_#10b981]"/> <span className="text-xs font-bold">{stats.present} حاضر</span></div>
                        <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_10px_#f59e0b]"/> <span className="text-xs font-bold">{stats.late} تاخیر</span></div>
                        <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_10px_#f43f5e]"/> <span className="text-xs font-bold">{stats.absent} غایب</span></div>
                    </div>
                </div>
                <div className="flex gap-3">
                   <input type="date" value={attendanceDate} onChange={e => setAttendanceDate(e.target.value)} className="bg-white/5 border border-white/10 rounded-2xl px-6 font-mono text-xs font-black outline-none focus:ring-2 focus:ring-primary-500" />
                   <button onClick={saveAll} className="bg-primary-600 px-12 py-5 rounded-[1.8rem] font-black text-sm flex items-center gap-3 shadow-2xl shadow-primary-500/40 hover:bg-primary-500 transition-all uppercase tracking-widest active:scale-95">
                      <Save size={24}/> تایید و ثبت نهایی جلسه
                   </button>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* History Modal */}
      <Modal isOpen={isHistoryModalOpen} onClose={() => setIsHistoryModalOpen(false)} title="تاریخچه حضور و غیاب کلاس" maxWidth="max-w-4xl">
         <div className="p-8 space-y-6">
            {historyRecords.length === 0 ? (
               <div className="py-20 text-center opacity-30 flex flex-col items-center">
                  <CalendarDays size={64} className="mb-4" />
                  <p className="font-black text-xl">هنوز سابقه‌ای برای این کلاس ثبت نشده است.</p>
               </div>
            ) : (
               <div className="grid grid-cols-1 gap-4 max-h-[500px] overflow-y-auto custom-scrollbar">
                  {historyRecords.map(rec => (
                     <div key={rec.id} className="p-6 bg-slate-50 dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 flex justify-between items-center group hover:bg-white transition-all">
                        <div className="flex items-center gap-5">
                           <div className="w-12 h-12 bg-white dark:bg-slate-900 rounded-2xl flex items-center justify-center text-primary-600 shadow-sm"><Calendar size={24}/></div>
                           <div className="text-right">
                              <h4 className="font-black text-lg text-slate-900 dark:text-white">{new Date(rec.date).toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' })}</h4>
                              <p className="text-[10px] text-slate-400 font-black uppercase mt-0.5">ثبت شده در: {new Date(rec.date).toLocaleTimeString('fa-IR', {hour:'2-digit', minute:'2-digit'})}</p>
                           </div>
                        </div>
                        <div className="flex gap-8 items-center">
                           <div className="flex gap-4">
                              <div className="text-center"><p className="text-[8px] font-black text-slate-400 uppercase mb-1">حاضر</p><p className="text-lg font-black text-emerald-500">{rec.presentStudentIds.length}</p></div>
                              <div className="text-center"><p className="text-[8px] font-black text-slate-400 uppercase mb-1">غایب</p><p className="text-lg font-black text-rose-500">{rec.absentStudentIds.length}</p></div>
                           </div>
                           <button className="p-3 bg-white dark:bg-slate-900 text-slate-400 rounded-xl hover:text-primary-600 transition-colors shadow-sm opacity-0 group-hover:opacity-100"><ArrowUpRight size={18}/></button>
                        </div>
                     </div>
                  ))}
               </div>
            )}
         </div>
      </Modal>

      {/* Random Picker Modal */}
      <Modal isOpen={isPickerOpen} onClose={() => !isSpinning && setIsPickerOpen(false)} title="گردونه پرسش و پاسخ تصادفی" maxWidth="max-w-md">
         <div className="p-10 flex flex-col items-center justify-center text-center min-h-[400px]">
            {isSpinning ? (
               <div className="space-y-10 relative">
                  <div className="relative w-48 h-48 mx-auto">
                     <div className="absolute inset-0 border-[12px] border-slate-100 dark:border-slate-800 rounded-full"></div>
                     <div className="absolute inset-0 border-[12px] border-primary-500 rounded-full border-t-transparent animate-spin"></div>
                     <div className="absolute inset-0 flex items-center justify-center">
                        <Zap size={64} className="text-primary-200 animate-pulse" />
                     </div>
                  </div>
                  <div>
                     <h3 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight animate-pulse">در حال فراخوانی هنرجو...</h3>
                     <p className="text-slate-400 font-bold text-xs mt-3 uppercase tracking-[0.4em]">Selecting from active nodes</p>
                  </div>
               </div>
            ) : pickedStudent ? (
               <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="space-y-10 w-full">
                  <div className="relative inline-block">
                     <div className="w-48 h-48 bg-gradient-to-br from-primary-500 to-indigo-600 rounded-[3rem] flex items-center justify-center text-6xl font-black text-white shadow-[0_30px_60px_rgba(14,165,233,0.3)] mx-auto border-8 border-white dark:border-slate-800 transform rotate-3">
                        {pickedStudent.avatar ? <img src={pickedStudent.avatar} className="w-full h-full object-cover" /> : pickedStudent.name.charAt(0)}
                     </div>
                     <div className="absolute -top-4 -right-4 bg-amber-400 text-slate-950 p-4 rounded-[1.5rem] shadow-2xl border-4 border-white animate-bounce">
                        <Target size={32} />
                     </div>
                  </div>
                  <div>
                     <h2 className="text-4xl font-black text-slate-950 dark:text-white tracking-tighter mb-2">{pickedStudent.name}</h2>
                     <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">منتخب برای ارائه و پرسش کلاسی</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                     <button onClick={() => { setIsPickerOpen(false); handleScoreChange(pickedStudent.id, 1); }} className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 py-5 rounded-[1.8rem] font-black text-xs uppercase flex items-center justify-center gap-3 hover:bg-emerald-500 hover:text-white transition-all shadow-lg border border-emerald-200">
                        <ThumbsUp size={20} /> پاسخ صحیح (+XP)
                     </button>
                     <button onClick={() => { setIsPickerOpen(false); handleScoreChange(pickedStudent.id, -1); }} className="bg-rose-50 dark:bg-rose-900/10 text-rose-500 py-5 rounded-[1.8rem] font-black text-xs uppercase flex items-center justify-center gap-3 hover:bg-rose-500 hover:text-white transition-all shadow-lg border border-rose-100">
                        <ThumbsDown size={20} /> عدم پاسخگویی
                     </button>
                  </div>
               </motion.div>
            ) : null}
         </div>
      </Modal>
    </div>
  );
};

export default TeacherClassManagement;
