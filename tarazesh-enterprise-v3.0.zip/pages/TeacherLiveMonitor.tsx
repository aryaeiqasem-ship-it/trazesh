
import React, { useState, useEffect, useMemo } from 'react';
import { Exam, LiveExamSession, UserRole } from '../types';
import { storageService } from '../services/storageService';
import { 
  ShieldCheck, ShieldAlert, Wifi, WifiOff, Timer, Users, 
  Search, ArrowRight, Zap, Activity, Monitor, Globe,
  Eye, Bell, MoreVertical, LayoutGrid, List, AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';

interface Props {
  examId: string | null;
  onBack: () => void;
}

const TeacherLiveMonitor: React.FC<Props> = ({ examId, onBack }) => {
  const [exam, setExam] = useState<Exam | undefined>(undefined);
  const [sessions, setSessions] = useState<LiveExamSession[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const toast = useToast();

  useEffect(() => {
    if (examId) {
      setExam(storageService.getExams().find(e => e.id === examId));
    }
  }, [examId]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (examId) {
        setSessions(storageService.getLiveSessions(examId));
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [examId]);

  const filteredSessions = useMemo(() => {
    return sessions.filter(s => s.studentName.includes(searchTerm));
  }, [sessions, searchTerm]);

  if (!exam) return <div className="p-20 text-center text-slate-500 font-black">در حال راه‌اندازی مرکز کنترل...</div>;

  return (
    <div className="space-y-8 pb-32 font-sans" dir="rtl">
      {/* هدر استراتژیک فرماندهی */}
      <div className="bg-slate-950 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-[0_30px_70px_rgba(0,0,0,0.5)] border border-white/5">
         <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
         <div className="absolute -top-24 -left-24 w-80 h-80 bg-primary-600/10 rounded-full blur-[100px]"></div>
         
         <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-10">
            <div className="flex items-center gap-6">
               <button onClick={onBack} className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-white transition-all border border-white/10 shadow-xl">
                  <ArrowRight size={24} />
               </button>
               <div>
                  <div className="flex items-center gap-3 mb-1">
                     <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]"></div>
                     <h1 className="text-3xl font-black tracking-tighter uppercase">اتاق کنترل آزمون</h1>
                  </div>
                  <p className="text-slate-500 font-bold text-xs uppercase tracking-[0.3em]">{exam.title} <span className="mx-2 opacity-30">•</span> کلاس: {exam.forClass}</p>
               </div>
            </div>
            
            <div className="flex gap-4">
               <div className="bg-white/5 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 text-center min-w-[120px]">
                  <p className="text-[9px] font-black text-slate-500 uppercase mb-1">گره‌های فعال</p>
                  <p className="text-2xl font-black text-emerald-400">{sessions.length}</p>
               </div>
               <div className="bg-white/5 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 text-center min-w-[120px]">
                  <p className="text-[9px] font-black text-slate-500 uppercase mb-1">هشدارها</p>
                  <p className="text-2xl font-black text-rose-500">{sessions.reduce((acc, s) => acc + s.alerts.length, 0)}</p>
               </div>
            </div>
         </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-200 dark:border-white/5 shadow-sm flex flex-col md:flex-row gap-6 items-center">
         <div className="relative flex-1 w-full group">
            <input 
               type="text" 
               placeholder="جستجوی لحظه‌ای هنرجو..." 
               className="w-full pl-4 pr-14 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl outline-none font-bold text-sm text-slate-900 dark:text-white transition-all shadow-inner"
               value={searchTerm}
               onChange={e => setSearchTerm(e.target.value)}
            />
            <Search className="absolute right-5 top-4.5 text-slate-400 group-focus-within:text-primary-500" size={24} />
         </div>
         <div className="flex items-center gap-3 px-6 py-4 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 rounded-2xl border border-indigo-100 dark:border-indigo-800">
            <Activity size={20} className="animate-pulse" />
            <span className="text-xs font-black uppercase tracking-widest">همگام‌سازی شبکه: ۱۰۰٪</span>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
         <AnimatePresence mode="popLayout">
            {filteredSessions.map(session => (
               <motion.div 
                  layout initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
                  key={session.studentId}
                  className={`bg-white dark:bg-slate-900 rounded-[3rem] border-2 p-8 transition-all group relative overflow-hidden flex flex-col h-full ${
                    session.alerts.length > 0 ? 'border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.2)]' : 'border-slate-100 dark:border-white/5 shadow-sm'
                  }`}
               >
                  <div className="flex items-center gap-5 mb-8 relative z-10">
                     <div className="relative">
                        <div className="w-16 h-16 rounded-[1.5rem] bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-2xl text-slate-300 overflow-hidden border-4 border-white dark:border-slate-800 shadow-xl">
                           {session.studentName.charAt(0)}
                        </div>
                        <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-4 border-white dark:border-slate-900 flex items-center justify-center ${session.status === 'online' ? 'bg-emerald-500' : 'bg-rose-500'}`}>
                           {session.status === 'online' ? <Wifi size={12} className="text-white"/> : <WifiOff size={12} className="text-white"/>}
                        </div>
                     </div>
                     <div className="min-w-0">
                        <h4 className="font-black text-[16px] text-slate-800 dark:text-white truncate">{session.studentName}</h4>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">وضعیت: {session.status === 'online' ? 'متصل' : 'قطع شده'}</p>
                     </div>
                  </div>

                  <div className="space-y-5 mb-8 relative z-10">
                     <div className="space-y-2">
                        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                           <span className="text-slate-400">پیشرفت آزمون</span>
                           <span className="text-primary-600">{session.progress}%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                           <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${session.progress}%` }}
                              className="h-full bg-primary-500"
                           />
                        </div>
                     </div>

                     <div className="grid grid-cols-2 gap-3">
                        <div className="bg-slate-50 dark:bg-white/2 p-3 rounded-2xl border border-slate-100 dark:border-white/5">
                           <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">زمان سپری شده</p>
                           <p className="text-sm font-black text-slate-700 dark:text-slate-200">14:02</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-white/2 p-3 rounded-2xl border border-slate-100 dark:border-white/5">
                           <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">میانگین سرعت</p>
                           <p className="text-sm font-black text-slate-700 dark:text-slate-200">45ث/س</p>
                        </div>
                     </div>
                  </div>

                  {session.alerts.length > 0 && (
                     <div className="mb-6 p-4 bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-900/30 rounded-2xl animate-pulse">
                        <div className="flex items-center gap-2 text-rose-600 mb-2">
                           <ShieldAlert size={16} />
                           <span className="text-[10px] font-black uppercase">هشدار امنیتی</span>
                        </div>
                        <p className="text-[10px] font-bold text-rose-800 dark:text-rose-300 leading-relaxed">{session.alerts[session.alerts.length-1]}</p>
                     </div>
                  )}

                  <div className="mt-auto flex gap-2 relative z-10 pt-4 border-t border-slate-50 dark:border-white/5">
                     <button onClick={() => toast.info(`پیام مستقیم برای ${session.studentName} ارسال شد.`)} className="flex-1 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 hover:text-white transition-all">ارسال پیام</button>
                     <button className="p-3 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><MoreVertical size={18}/></button>
                  </div>
               </motion.div>
            ))}
         </AnimatePresence>
         
         {sessions.length === 0 && (
            <div className="col-span-full py-48 text-center border-4 border-dashed border-slate-100 dark:border-white/5 bg-slate-50/30 dark:bg-white/2 rounded-[4rem]">
               <Activity size={100} className="mx-auto text-slate-200 dark:text-slate-800 mb-8" />
               <h3 className="text-slate-400 font-black text-2xl tracking-tight">در حال انتظار برای ورود هنرجویان...</h3>
               <p className="text-slate-400 font-bold text-xs mt-3 uppercase tracking-[0.4em]">در حال شنود سیگنال‌های ورودی</p>
            </div>
         )}
      </div>
    </div>
  );
};

export default TeacherLiveMonitor;
