
import React, { useState } from 'react';
import { ArrowLeft, ShieldAlert, UserCheck, RefreshCw, Send, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '../contexts/ToastContext';
import { storageService } from '../services/storageService';

interface ForgotPasswordProps {
  onBack: () => void;
}

const ForgotPasswordPage: React.FC<ForgotPasswordProps> = ({ onBack }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [identifier, setIdentifier] = useState('');
  const [requestData, setRequestData] = useState<any>(null);
  const toast = useToast();

  const handleRequestReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier) return toast.error('شناسه کاربری را وارد کنید.');

    setLoading(true);
    try {
      // شبیه‌سازی تاخیر عملیاتی
      await new Promise(r => setTimeout(r, 1200));
      const req = storageService.requestPasswordReset(identifier);
      setRequestData(req);
      setStep(2);
      toast.success('درخواست شما برای مدرس ارسال شد و در پنل وی قابل رویت است.');
    } catch (err: any) {
      toast.error(err.message || 'خطا در یافتن حساب کاربری.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[85vh] w-full p-4 font-sans" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden relative"
      >
        <div className="p-12">
          <button onClick={onBack} className="absolute top-10 left-10 p-2 text-slate-400 hover:text-primary-600 transition-colors">
            <ArrowLeft size={24} />
          </button>

          <div className="text-center mb-12">
            <div className="w-24 h-24 bg-primary-50 dark:bg-primary-900/30 rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 text-primary-600 shadow-inner">
              {step === 1 ? <ShieldAlert size={48} /> : <UserCheck size={48} className="animate-pulse" />}
            </div>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-3">
              {step === 1 ? 'فراموشی رمز عبور' : 'در انتظار تایید مدرس'}
            </h2>
            <p className="text-sm text-slate-500 font-bold leading-relaxed px-6">
              {step === 1 
                ? 'درخواست بازنشانی رمز شما مستقیماً برای مدرس کلاس ارسال شده و توسط وی تایید می‌گردد.' 
                : 'درخواست شما در "مرکز پایش امنیتی" مدرس قرار گرفت. پس از تایید، رمز شما به ۱۲۳۴۵۶ تغییر می‌یابد.'}
            </p>
          </div>

          <AnimatePresence mode="wait">
            {step === 1 ? (
              <motion.form key="s1" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} onSubmit={handleRequestReset} className="space-y-8">
                <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase mr-2 tracking-widest">شماره دانش‌آموزی / کدملی</label>
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    className="w-full p-5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white border-2 border-transparent focus:border-primary-500 rounded-3xl outline-none font-black text-lg text-center tracking-widest transition-all"
                    placeholder="990101..."
                  />
                </div>
                <button type="submit" disabled={loading} className="w-full py-5 bg-primary-600 hover:bg-primary-700 text-white font-black rounded-3xl shadow-2xl shadow-primary-500/30 transition-all flex items-center justify-center gap-3">
                  {loading ? <RefreshCw className="animate-spin" /> : <>ثبت درخواست رسمی بازیابی <Send size={20} /></>}
                </button>
              </motion.form>
            ) : (
              <motion.div key="s2" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="space-y-8">
                <div className="bg-slate-50 dark:bg-slate-800/50 p-8 rounded-[2.5rem] border-2 border-dashed border-primary-200 dark:border-primary-900/50 text-center">
                   <div className="text-[10px] font-black text-slate-400 uppercase mb-2">کد رهگیری امنیتی</div>
                   <div className="text-4xl font-black text-primary-600 tracking-tighter">{requestData?.id.split('_')[1]}</div>
                </div>
                
                <div className="flex items-center gap-3 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                   <CheckCircle2 className="text-emerald-600 shrink-0" size={20} />
                   <p className="text-xs text-emerald-800 dark:text-emerald-300 font-bold">درخواست شما در صف انتظار مدرس قرار دارد.</p>
                </div>

                <button onClick={onBack} className="w-full py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-black rounded-3xl shadow-xl transition-all">بازگشت به صفحه ورود</button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

export default ForgotPasswordPage;
