
import React, { createContext, useContext, useState, useCallback } from 'react';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  addToast: (message: string, type: ToastType) => void;
  removeToast: (id: number) => void;
  success: (message: string) => void;
  error: (message: string) => void;
  warning: (message: string) => void;
  info: (message: string) => void;
}

const ToastContext = createContext<ToastContextType>({ 
  addToast: () => {}, 
  removeToast: () => {},
  success: () => {},
  error: () => {},
  warning: () => {},
  info: () => {}
});

export const useToast = () => useContext(ToastContext);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const removeToast = useCallback((id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const addToast = useCallback((message: string, type: ToastType) => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    
    // Auto dismiss
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  }, [removeToast]);

  const success = (msg: string) => addToast(msg, 'success');
  const error = (msg: string) => addToast(msg, 'error');
  const warning = (msg: string) => addToast(msg, 'warning');
  const info = (msg: string) => addToast(msg, 'info');

  const getIcon = (type: ToastType) => {
    switch (type) {
      case 'success': return <CheckCircle size={20} className="text-green-500" />;
      case 'error': return <AlertCircle size={20} className="text-red-500" />;
      case 'warning': return <AlertTriangle size={20} className="text-amber-500" />;
      case 'info': return <Info size={20} className="text-blue-500" />;
    }
  };

  const getStyles = (type: ToastType) => {
    switch (type) {
      case 'success': return 'border-green-500 bg-green-50 dark:bg-green-900/20 dark:border-green-500/50';
      case 'error': return 'border-red-500 bg-red-50 dark:bg-red-900/20 dark:border-red-500/50';
      case 'warning': return 'border-amber-500 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-500/50';
      case 'info': return 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-500/50';
    }
  };

  return (
    <ToastContext.Provider value={{ addToast, removeToast, success, error, warning, info }}>
      {children}
      <div className="fixed top-6 left-6 z-[10001] flex flex-col gap-3 pointer-events-none">
        {toasts.map(toast => (
          <div 
            key={toast.id} 
            className={`pointer-events-auto min-w-[300px] max-w-sm flex items-start gap-3 p-4 rounded-xl border-l-4 shadow-2xl backdrop-blur-md animate-fade-in-right transition-all ${getStyles(toast.type)}`}
          >
            <div className="mt-0.5 shrink-0">{getIcon(toast.type)}</div>
            <div className="flex-1">
              <p className={`text-sm font-black leading-relaxed dark:text-slate-100 ${
                  toast.type === 'success' ? 'text-green-800' : 
                  toast.type === 'error' ? 'text-red-800' :
                  toast.type === 'warning' ? 'text-amber-800' : 'text-blue-800'
              }`}>
                {toast.message}
              </p>
            </div>
            <button 
              onClick={() => removeToast(toast.id)}
              className="opacity-50 hover:opacity-100 transition-opacity dark:text-slate-400"
            >
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};
