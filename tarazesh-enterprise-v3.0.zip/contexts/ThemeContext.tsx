
import React, { createContext, useContext, useEffect, useState } from 'react';
import { storageService } from '../services/storageService';

type Theme = 'light' | 'dark' | 'gold';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  refreshBranding: () => void;
}

const ThemeContext = createContext<ThemeContextType>({ 
  theme: 'light', 
  setTheme: () => {}, 
  toggleTheme: () => {},
  refreshBranding: () => {}
});

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    const saved = localStorage.getItem('theme');
    return (saved as Theme) || 'light';
  });

  const applyBranding = () => {
    const settings = storageService.getSettings();
    if (settings?.branding?.primaryColor) {
      const primary = settings.branding.primaryColor;
      
      // Inject CSS Variables to Root
      document.documentElement.style.setProperty('--primary-hex', primary);
      
      // Force update Tailwind-like dynamic classes via a style tag
      const styleId = 'dynamic-branding-engine';
      let styleEl = document.getElementById(styleId) as HTMLStyleElement;
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = styleId;
        document.head.appendChild(styleEl);
      }
      
      styleEl.innerHTML = `
        :root { 
          --primary-color: ${primary};
          --primary-hover: ${primary}dd;
        }
        .bg-primary-600 { background-color: ${primary} !important; }
        .text-primary-600 { color: ${primary} !important; }
        .border-primary-600 { border-color: ${primary} !important; }
        .hover\\:bg-primary-700:hover { background-color: ${primary}ee !important; }
        .focus\\:ring-primary-500:focus { --tw-ring-color: ${primary}88 !important; }
        .bg-primary-50 { background-color: ${primary}15 !important; }
        .text-primary-500 { color: ${primary} !important; }
        .dark .bg-primary-900\\/20 { background-color: ${primary}33 !important; }
      `;
    }
  };

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark', 'gold');
    root.classList.add(theme);
    localStorage.setItem('theme', theme);
    applyBranding();
  }, [theme]);

  const toggleTheme = () => {
    setThemeState(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, refreshBranding: applyBranding }}>
      {children}
    </ThemeContext.Provider>
  );
};
