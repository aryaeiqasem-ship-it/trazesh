
/**
 * بر اساس کد رنگ هگز، تشخیص می‌دهد که آیا رنگ روشن است یا تیره
 * تا رنگ متن مناسب (سفید یا سیاه) انتخاب شود.
 */
export const getContrastColor = (hexcolor: string): 'text-white' | 'text-slate-900' => {
  if (!hexcolor) return 'text-white';
  
  // حذف # در صورت وجود
  const hex = hexcolor.replace('#', '');
  
  // تبدیل به RGB
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  
  // محاسبه درخشندگی (YIQ)
  const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
  
  // اگر درخشندگی بیشتر از 128 باشد رنگ روشن است و متن باید تیره باشد
  return (yiq >= 150) ? 'text-slate-900' : 'text-white';
};
